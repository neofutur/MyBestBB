<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Temes',
'Moderators'			=>  'Moderadors',
'Link to'				=>	'Enlla� a',	// As in "Link to http://www.punbb.org/"
'Empty board'		=>	'El F�rum est� buit.',
'Newest user'			=>	'�ltim usuari registrat',
'Users online'			=>	'Usuaris registrats connectats',
'Guests online'			=>	'Visitants connectats',
'No of users'			=>	'Nombre total d\'usuaris registrats',
'No of topics'			=>	'Nombre total de temes',
'No of posts'			=>	'Nombre total de missatges',
'Online'				=>	'Connectats',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informaci� del f�rum',
'Board stats'			=>	'Estad�stiques del f�rum',
'User info'				=>	'Informaci� de l\'usuari'

);
