<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Zaslat p��sp�vek',
'Topic closed'		=>	'T�ma zav�eno',
'From'			=>	'M�sto',				// User location
'Note'			=>	'Pozn�mka',				// Admin note
'Website'			=>	'Web',
'Guest'			=>	'Host',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Editoval',
'Report'			=>	'Nahl�sit',
'Delete'			=>	'Smazat',
'Edit'			=>	'Editovat',
'Quote'			=>	'Citace',
'Is subscribed'		=>	'Nyn� jste p�ihl�en k odb�ru p��sp�vk� v tomto t�matu.',
'Unsubscribe'		=>	'Odhl�sit z odb�ru.',
'Subscribe'			=>	'P�ihl�sit k odb�ru p��sp�vk� v tomto t�matu.',
'Quick post'		=>	'Rychl� odpov��',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Moder�torsk� ovl�d�n�'
);
