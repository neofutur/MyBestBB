<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Hapus posting',
'Warning'				=>	'Perhatian! Jika ini posting pertama dalam topik ini, maka seluruh topik akan dihapus.',
'Delete'				=>	'Hapus',	// The submit button
'Post del redirect'		=>	'Posting terhapus. Sedang diarahkan ke halaman yang dituju &hellip;',
'Topic del redirect'	=>	'Topik terhapus. Sedang diarahkan ke halaman yang dituju &hellip;'

);
