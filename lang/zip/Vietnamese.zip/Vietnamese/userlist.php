<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Tìm kiếm và sắp xếp người dùng',
'User search info'		=>	'Nhập vào tên người dùng để tìm kiếm và/hoặc một nhóm để lọc. Tên có thể bỏ qua. Dùng các kí tự đại diện * để tìm kiếm. Sắp xếp người dùng theo tên, ngày đăng ký hoặc số bài theo thứ tự tăng/giảm.',
'User group'			=>	'Nhóm người dùng',
'No of posts'			=>	'Số bài',//No. of posts',
'All users' => 'Tất cả',
);
