<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Teme',
'Moderators'			=>  'Moderatori',
'Link to'				=>	'Link ka',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Forum je prazan.',
'Newest user'			=>	'Najnovihi registrovan �lan',
'Users online'			=>	'Registrovani �lanovi online',
'Guests online'			=>	'Gosti online',
'No of users'			=>	'Ukupno registrovanih �lanova',
'No of topics'			=>	'Ukupan broj tema',
'No of posts'			=>	'Ukupan broj poruka',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informacija o Forumu',
'Board stats'			=>	'Forum statistike',
'User info'				=>	'Informacija o �lanu'

);
