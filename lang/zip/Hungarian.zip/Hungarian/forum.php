<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'�j t�ma',
'Views'			=>	'Olvasva',
'Moved'			=>	'�thelyezve',
'Sticky'		=>	'Kiemelt',
'Empty forum'	=>	'A f�rum �res.'

);
