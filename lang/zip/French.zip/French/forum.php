<?php

// Language definitions used in viewforum.php
$lang_forum = array(
 
'Post topic'	=>	'Nouvelle discussion',
'Views'			=>	'Vues',
'Moved'			=>	'D�plac�',
'Sticky'		=>	'�pingl�',
'Empty forum'	=>	'Le forum est vide.'
 
);
