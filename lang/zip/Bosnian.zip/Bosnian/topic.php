<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Upi�ite odgovor',
'Topic closed'		=>	'Zatvorena tema',
'From'				=>	'Od',				// User location
'Note'				=>	'Nick',				// Admin note
'Website'			=>	'Web',
'Guest'				=>	'Gost',
'Online'			=>	'Tu!',
'Offline'			=>	'Jock tu!',
'Last edit'			=>	'Zadnja izmjena od',
'Report'			=>	'Reportuj',
'Delete'			=>	'Obri�i',
'Edit'				=>	'Izmjeni',
'Quote'				=>	'Citiraj',
'Is subscribed'		=>	'Za ovu temu ste prijavljeni',
'Unsubscribe'		=>	'Odjavite se',
'Subscribe'			=>	'Prijavite se na ovu temu',
'Quick post'		=>	'Na brzaka',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Opcije moderatora'

);
