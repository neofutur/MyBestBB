<?php
/******************************************************************************************************
		Reputation Plugin for PunBB
		----------------------------
-- Version 2.2.0
-- Created by hcs on 25-04-2006  hcs@mail.ru

-- GPL:
  This software is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published
  by the Free Software Foundation; either version 2 of the License,
  or (at your option) any later version.

  This software is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
  MA  02111-1307  USA
******************************************************************************************************/
// Language definitions used by the Reputation System mod
$lang_reputation = array(
  'Reputation' 						=> 	'Reputace',
  'Disabled' 						=> 	'Systém reputace je nyní vypnutý',
  'Invalid voice value' 			=> 	'Hodnota hlasu byla špatná, prosím jděte zpět a opravte jí.',
  'Silly user' 						=> 	'Nemůžete dát hlas sami sobě',
  'No user'							=>	'Špatné ID uživatele, uživatel s tímto ID neexistuje',
  'Timeout 1'						=>	'Další hlasování můžete provést až za ',
  'Timeout 2'       				=>  ' minut.',
  'Plus'							=>	'Zvýšení reputace',
  'Minus'							=>	'Snížení reputace',
  'Form header'						=>	'Přidání reputace',
  'Form your name'					=>	'Váše přezdívka',
  'Form to name'					=>	'Komu',
  'Form reason'						=>	'Důvod',
  'Form method'						=>	'Akce',
  'Redirect Message'				=>	'Reputace byla úspěšně změněna. Přesměrovávám&hellip;',
  'User reputation' 				=>	'Reputace uživatele ',
  'From user'						=>	'Od uživatele',
  'For topic'						=>	'Téma',
  'Reason'							=>	'Důvod',
  'Estimation'						=>	'Akce',
  'Date'							=>	'Datum',
  'No reputation'					=>	'Není žádná reputace',
  'No message'						=>	'Důvod je povinný',
  'Too long message' 				=> 	'Příliš dlouhá zpráva',
  'Max length of message' 			=>  'Maximální délka zprávy:',
  'You already of use' 				=>	'Už jste použili',
  'Of symbol'						=>	'znaků',
  'Profile deleted'					=>	'Profil byl smazán',
  'Delete'							=>	'Odstranit',
  'Are you sure'					=>	'Jste si jistý?',
  'Deleted redirect'				=>	'Odstraněno. Přesměrovávám&hellip;',
  'Reputation mod'					=>	'Reputace',
  'Plugin description'				=>	'Toto rozšíření je určeno k nastavení a povolení reputace uživatelů.',
  'Removed or deleted'				=>	'Odstraněno nebo vymazáno',
  'Group Disabled'					=> 	'Pro tuto skupinu, do které vstoupíte, je použití reputace zakázáno',
  'Individual Disabled'				=> 	'Administrátor vám zakázal používání reputace',
  'User Disable'					=>	'Uživatel nedovolil použití reputace',  
  'Your Disabled'					=>	'Nemůžete užívat systém hodnocení reputace',
  'Small Number of post'			=>	'Nedostatečné množství zpráv pro vyhodnocení reputace ',
  'Manage reputation'				=>	'Ukázat reputaci',
  'Description Manage reputation'	=>	'Pokud zakážete systém reputace, nikdo vaši reputaci nemůže hodnotit. Zároveň však nesmíte hodnotit ani zhlédnout reputaci ostatních uživatelů.' 
);
