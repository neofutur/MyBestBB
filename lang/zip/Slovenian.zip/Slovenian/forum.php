<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Nova tema',
'Views'			=>	'Ogledov',
'Moved'			=>	'Prestavljen',
'Sticky'		=>	'Lepljiv',
'Empty forum'	=>	'Forum je prazen.'

);
