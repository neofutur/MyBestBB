﻿<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'جواب لکھیں',
'Topic closed'		=>	'موضوع بند',
'From'				=>	'منجانب',				// User location
'Note'				=>	'نوٹ',				// Admin note
'Website'			=>	'ویب سائٹ',
'Guest'				=>	'مہمان',
'Online'			=>	'آن لائن',
'Offline'			=>	'آف لائن',
'Last edit'			=>	'آخری رد و بدل منجانب',
'Report'			=>	'رپورٹ',
'Delete'			=>	'ختم کریں',
'Edit'				=>	'رد و بدل',
'Quote'				=>	'اقتباس',
'Is subscribed'		=>	'آپ فی الحال اس موضوع کی فہرست میں ہیں',
'Unsubscribe'		=>	'فہرست سے ہٹیں',
'Subscribe'			=>	'موضوع کی فہرست میں شامل ہوں',
'Quick post'		=>	'تیز جواب',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'ماڈریٹر کے کنٹرولز'

);
