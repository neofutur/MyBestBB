<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Uus teema',
'Views'			=>	'Vaadatud',
'Moved'			=>	'Liigutatud',
'Sticky'		=>	'P�siv',
'Empty forum'	=>	'Foorum on t�hi.'

);
