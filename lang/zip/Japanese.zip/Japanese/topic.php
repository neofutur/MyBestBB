<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'返事を投稿',
'Topic closed'		=>	'閉じられたトピック',
'From'				=>	'From',				// User location
'Note'				=>	'管理者メモ',				// Admin note
'Website'			=>	'ウェブサイト',
'Guest'				=>	'ゲスト',
'Online'			=>	'オンライン',
'Offline'			=>	'オフライン',
'Last edit'			=>	'最終編集 by',
'Report'			=>	'報告',
'Delete'			=>	'削除',
'Edit'				=>	'編集',
'Quote'				=>	'引用',
'Is subscribed'		=>	'このトピックにメール通知を設定しています',
'Unsubscribe'		=>	'メール通知解除',
'Subscribe'			=>	'このトピックにメール通知を設定する',
'Quick post'		=>	'クイック投稿',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'モデレータ管理'

);
