<?php

// Language definitions used in register.php
$lang_register = array(

// Miscellaneous
'No new regs'				=>	'Die forum laat geen verdere registrasies toe nie.',
'Reg cancel redirect'			=>	'Registrasie gekanseleer. Besig met nastuuring &hellip;',
'Forum rules'				=>	'Reels van die forum',
'Rules legend'				=>	'Jy moet instem met die volgende om te kan registreer',
'Agree'					=>	'Ek stem in',
'Cancel'				=>	'Kanseleer',
'Register'				=>	'Registreer',

// Form validation stuff (some of these are also used in post.php)
'Username censor'			=>	'Die gebruikersnaam wat jy ingetik het bevat een of meer gesensorde woorde kies asb `n ander een.',
'Username dupe 1'			=>	'Daar is al iemand wat die naam gerigestreer het',
'Username dupe 2'			=>	'Die gebruikersnaam lyk te veel na `n bestaande gebruikersnaam. Die gebruikersnaam moet verskil met tenminste 1 alfanumeriese karakter (a-z of 0-9). Kies `n ander gebruikersnaam.',
'E-mail not match'			=>	'Die e-pos adresse stem nie ooreen. Gaan terug en maak dit reg.',

// Registration e-mail stuff
'Reg e-mail'				=>	'Dankie dat jy gerigestreer het. Jou wagwoord is gestuur na die gespesifiseerde adres. As dit nie by jou uit kom nie, kontak die forum beheerder by',
'Reg complete'				=>	'Registrasie voltooi. Besig met inlog en nastuuring &hellip;',

// Register info
'Desc 1'				=>	'As jy registreer kry jy `n paar voordele bo gaste. Jy kan "post" jou "posts" verander ens. As jy vrae het vra forum beheerder.',
'Desc 2'				=>	'Hieronder is `n vorm wat jy moet invul om te kan registreer. Wanneer jy gerigestreer het kan jy na jou profiel blad toe gaan vir nog veranderinge. Die velde hier onder maak net `n klein gedeelte uit van al die opsies wat wat daar is.',
'Username legend'			=>	'Vul `n gebruikersnaam in met `n lengte van 2 tot 25 karakters',
'Pass legend 1'				=>	'Vul jou gekiesde wagwoord in en bevestig dit',
'Pass legend 2'				=>	'Lees die onderstaande aanwysiging',
'Pass info'				=>	'Jou wagwoord kan tussen 4 tot 16 karakters lank wees. Alle wagwoorde ondersky tussen hoofletters en kleinletters.',
'E-mail info'				=>	'Jy moet `n geldige e-pos adres verskaf, omdat jou gegenereerde wagwoord na daar die adres toe gestuur word.',
'Confirm e-mail'			=>	'Bevestig jou e-pos adres',

);
