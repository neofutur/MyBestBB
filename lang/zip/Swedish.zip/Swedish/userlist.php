<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'S�k efter och sortera anv�ndare',
'User search info'		=>	'Ange ett anv�ndarnamn att s�ka efter. F�ltet kan l�mnas tomt. Anv�nd * som "wildcard" f�r ofullst�ndiga ord. Sortera resultaten efter namn, registreringsdatum eller antal skrivna inl�gg och i stigande eller fallande ordning.',
'User group'			=>	'Anv�ndargrupp',
'No of posts'			=>	'Antal inl�gg',
'All users'				=>	'Alla'

);
