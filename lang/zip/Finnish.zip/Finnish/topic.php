<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Vastaa',
'Topic closed'		=>	'Aihe loppuunk�sitelty',
'From'		        =>	'Mist�',		// User location
'Note'			=>	'Huomautus',		// Admin note
'Website'		=>	'Weppi-saitti',
'Guest'			=>	'Vieras',
'Online'		=>	'Roikkuu langoilla',
'Offline'		=>	'Kirjautunut ulos',
'Last edit'		=>	'Viimeksi muokattu',
'Report'		=>	'Raportti',
'Delete'		=>	'Poista',
'Edit'			=>	'Muokkaa',
'Quote'			=>	'Lainaa',
'Is subscribed'		=>	'Tilattu',
'Unsubscribe'		=>	'Lopeta tilaus',
'Subscribe'		=>	'Tilaa',
'Quick post'		=>	'Pikainen viesti',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Mod kontrollit'

);
