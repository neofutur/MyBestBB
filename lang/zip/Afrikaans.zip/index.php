<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'			=>	'Onderwerpe',
'Moderators'			=>	'Moderators',
'Link to'			=>	'Skakel na',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Die bord is leeg.',
'Newest user'			=>	'Nuutste geregistreerde gebruiker',
'Users online'			=>	'Geregistreerde gebruikers in die omgewing',
'Guests online'			=>	'Gaste in die omgewing',
'No of users'			=>	'Totale aantal geregistreerde gebruikers',
'No of topics'			=>	'Totale aantal onderwerpe',
'No of posts'			=>	'Totale aantal bydrae',
'Online'			=>	'In die omgewing',	// As in "Online: User A, User B etc."
'Board info'			=>	'Bord informasie',
'Board stats'			=>	'Bord statistieke',
'User info'			=>	'Gebruikersinformasie'

);
