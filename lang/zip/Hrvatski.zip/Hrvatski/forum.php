<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Pokreni novu temu',
'Views'			=>	'Pogledano',
'Moved'			=>	'Pomaknuto',
'Sticky'		=>	'Ljepljivo',
'Empty forum'	=>	'Forum je prazan.'

);
