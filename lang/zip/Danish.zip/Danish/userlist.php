<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Find og sorter brugere',
'User search info'		=>	'Indtast et brugernavn at s�ge efter og/eller en gruppe at filtrere p�. Feltet "Brugernavn" kan efterlades tomt. Brug \'wildcard\' tegnet * for at finde delvise navne (i.e. fred* finder frederik og frederikke). Sort�r brugere efter navn, registreringsdato eller antal indl�g og i stigende/faldende orden.',
'User group'			=>	'Brugergruppe',
'No of posts'			=>	'Antal indl�g',
'All users'				=>	'Alle'

);
