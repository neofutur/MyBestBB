<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'删除帖子',
'Warning'				=>	'警告！如果这是本主题的第一篇帖子，整个主题都会被删除！',
'Delete'				=>	'删除',	// The submit button
'Post del redirect'		=>	'帖子已删除，跳转中 &hellip;',
'Topic del redirect'	=>	'主题已删除，跳转中 &hellip;'

);
