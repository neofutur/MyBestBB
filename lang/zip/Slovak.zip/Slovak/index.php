<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'T�my',
'Moderators'			=>  'Moder�tori',
'Link to'				=>	'Odkaz na',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'F�rum je pr�znde.',
'Newest user'			=>	'Najnov�� registrovan� u��vate�',
'Users online'			=>	'Registrovan� u��vatelia online',
'Guests online'			=>	'N�v�tevn�kov online',
'No of users'			=>	'Registrovan�ch u��vate�ov celkom',
'No of topics'			=>	'Celkov� po�et t�m',
'No of posts'			=>	'Celkov� po�et pr�spevkov',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Inform�cie boardu',
'Board stats'			=>	'�tatistika boardu',
'User info'				=>	'Info o u��vate�ovi'

);
