<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Zalo�it nov� t�ma',
'Views'		=>	'Zobrazen�',
'Moved'		=>	'P�esunuto',
'Sticky'		=>	'Zv�razn�no',
'Empty forum'	=>	'F�rum je pr�zdn�'

);
