<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Usu�rio e/ou senha inv�lidos.',
'Forgotten pass'		=>	'Esqueceu a senha?',
'Login redirect'		=>	'Logado com sucesso. Redirecionando &hellip;',
'Logout redirect'		=>	'Deslogado. Redirecionando &hellip;',
'No e-mail match'		=>	'N�o existe usu�rio cadastrado com este email',
'Request pass'			=>	'Solicitar senha',
'Request pass legend'	=>	'Entre com o email que voc� se cadastrou',
'Request pass info'		=>	'Uma nova senha e um link para ativa��o da nova senha ser� enviado para o email informado.',
'Not registered'		=>	'Cadastre-se',
'Login legend'			=>	'Entre como o seu nome de usu�rio e senha abaixo',
'Login info'			=>	'Se voc� ainda n�o se cadastrou ou esqueceu a senha, clique no link correspondente abaixo.',

// Forget password mail stuff
'Forget mail'			=>	'Um email foi enviado para o endere�o informado com as instru��es para altera��o da senha. Se o email n�o chegar, voc� pode contactar o administrador em '

);
