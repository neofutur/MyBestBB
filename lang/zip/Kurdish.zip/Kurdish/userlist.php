﻿<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'دۆزینه‌وه‌ و ڕیزكردنی ئه‌ندامان',
'User search info'		=>	'نازناوێك بنووسه‌ بۆ گه‌ڕان به‌دوایدا، یان له‌ جۆریه‌تی ئه‌ندام سوود ببینه‌ بۆ نزیكتر پێكانی مه‌به‌ستت..',
'User group'			=>	'گرووپی به‌كارهێنه‌ر',
'No of posts'			=>	'ژماره‌ی په‌یامه‌كان',
'All users'				=>	'هه‌موو'

);
