<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Nájsť a zoradiť užívateľov',
'User search info'		=>	'Zadajte meno užívateľa, ktoré hľadáte a/alebo skupinu, podľa ktorej filtrovať. Pole užívateľského mena môže byť prázdne. Použite znak * pre vyhľadávanie určitej časti. Zoradí užívateľov podľa mena, dátumu registrácie, alebo množstva príspevkov stúpajúco/klesajúco.',
'User group'			=>	'Užívateľská skupina',
'No of posts'			=>	'Počet príspevkov',
'All users'				=>	'Všetci'

);
