<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'사용자를 찾고 분류하기',
'User search info'		=>	'찾고자 하는 사용자 이름을 입력하시고 소속 집단을 선택하십시오. 사용자 이름은 빈 칸으로 남겨두실 수 있습니다. 부분 일치를 위해서는 부분 일치를 나타내는 * 글자를 사용하십시오. 사용자들은 이름, 등록 날짜 혹은 올린 글 수를 기준으로 분류할 수 있으며 오름차순/내림차순으로 정렬할 수 있습니다.',
'User group'			=>	'사용자 소속 집단',
'No of posts'			=>	'올린 글 수',
'All users'				=>	'모두'

);
