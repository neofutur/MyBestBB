<?php

// Language definitions used in search.php
$lang_search = array(

// The search form
'User search'				=>	'Gebruikers soek',
'No search permission'			=>	'Jy het nie toestemming om die soek wesenstrek te gebruik nie.',
'Search'				=>	'Soek',
'Search criteria legend'		=>	'Tik die soek terme in',
'Search info'				=>	'Tik `n term of terme in na tesoek. Sky woorde met spasies. Gebruik AND (en), OR (of) en NOT (nie) omdie soek teverfyn. Om tesoek vir `n skrywer tik sy naam in. Gebruik `n asterisk (*) as `n (?)wildcard.',
'Keyword search'			=>	'Soek vir sleutelwoord',
'Author search'				=>	'Soek vir skrywer',
'Search in legend'			=>	'Kies waar om te soek',
'Search in info'			=>	'Kies die forum waar jy wil soek en of jy in die onderwerp, Boodskap of beide wil soek.',
'Forum search'				=>	'Forum',
'All forums'				=>	'Alle forums',
'Search in'				=>	'Soek in',
'Message and subject'			=>	'Boodskap en onderwerp',
'Message only'				=>	'Net boodskap',
'Topic only'				=>	'Net onderwerp',
'Sort by'				=>	'Sorteer met',
'Sort order'				=>	'Sorteer volgorde',
'Search results legend'			=>	'Kies hoe jy die resultate wil laat wys',
'Search results info'			=>	'Jy kan kies hoe jy die resultate wil sorteer en wys.',
'Sort by post time'			=>	'Bedrae tyd',
'Sort by author'			=>	'Skrywer',
'Sort by subject'			=>	'Onderwerp',
'Sort by forum'				=>	'Forum',
'Ascending'				=>	'Stygend',
'Descending'				=>	'Dalend',
'Show as'				=>	'Wys resultate as',
'Show as topics'			=>	'Onderwerpe',
'Show as posts'				=>	'Bydrae',

// Results
'Search results'			=>	'Soek resultate',
'No terms'				=>	'Jy moet tenminste een woord of een naam gee om na te soek.',
'No hits'				=>	'Daar is niks gevind.',
'No user posts'				=>	'Daar is geen gebruiker met daar die naam in die forums nie.',
'No subscriptions'			=>	'Jy is op die oomblik nie by enige onderwerpe ingeteken nie.',
'No new posts'				=>	'Daar is geen nuwe bydrae vanaf jou laaste besoek.',
'No recent posts'			=>	'Geen nuwe bedrae is gelewer in die laaste 24 uur.',
'No unanswered'				=>	'Daar is geen onbeantwoorde onderwerpe in die forum',
'Go to post'				=>	'Gaan na bydra'

);
