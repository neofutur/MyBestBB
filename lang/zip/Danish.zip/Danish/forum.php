<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Skriv nyt indl�g',
'Views'			=>	'Visninger',
'Moved'			=>	'Flyttet',
'Sticky'		=>	'Kl�brig',
'Empty forum'	=>	'Forummet er tomt.'

);
