<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Smazat příspěvek',
'Warning'				=>	'POZOR! Pokud je toto první příspěvek v tématu, téma bude SMAZÁNO!',
'Delete'				=>	'Smazat',	// The submit button
'Post del redirect'		=>	'Příspěvek smazán. Přesměrovávám&hellip;',
'Topic del redirect'	=>	'Téma smazáno. Přesměrovávám&hellip;'

);
