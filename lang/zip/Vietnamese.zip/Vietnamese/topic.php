<?php
// Language definitions used in viewtopic.php
$lang_topic = array(
'Post reply' => 'Trả lời',
'Topic closed' => 'Chủ đề đã bị khóa',
'From' => 'Từ',
'Note' => 'Ghi chú',
'Website' => 'Trang web',
'Guest' => 'Khách',
'Last edit' => 'Lần sửa gần đây nhất:',
'Report' => 'Báo cáo',
'Delete' => 'Xóa',
'Edit' => 'Sửa đổi',
'Quote' => 'Trích dẫn',
'Is subscribed' => 'Bạn đã đăng ký vào chủ đề này',
'Unsubscribe' => 'Bỏ đăng ký',
'Subscribe' => 'Đăng ký chủ đề này',
'Quick post' => 'Trả lời nhanh',
'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Online' => 'Trực tuyến',//'Online',
'Offline' => 'Ngoại tuyến',//'Offline',
'Mod controls'	=>	'Kiểm soát của Điều phối viên' //'Moderator controls'
);
