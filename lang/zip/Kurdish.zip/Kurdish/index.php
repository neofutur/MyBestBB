﻿<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'بابه‌ته‌كان',
'Moderators'			=>  'به‌ڕێوه‌به‌ران',
'Link to'				=>	'به‌سته‌ر بۆ',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'مه‌كۆ به‌تاڵه‌.',
'Newest user'			=>	'نوێترین ئه‌ندام',
'Users online'			=>	'ئه‌ندامانی سه‌رهێڵ',
'Guests online'			=>	'میوانانی سه‌رهێڵ',
'No of users'			=>	'ژماره‌ی هه‌موو ئه‌ندامان',
'No of topics'			=>	'هه‌موو بابه‌ته‌كان',
'No of posts'			=>	'هه‌موو په‌یامه‌كان',
'Online'				=>	'له‌سه‌ر هێله‌',	// As in "Online: User A, User B etc."
'Board info'			=>	'زانیاری مه‌كۆ',
'Board stats'			=>	'ژمێره‌ری مه‌كۆ',
'User info'				=>	'زانیاری ئه‌ندام'

);
