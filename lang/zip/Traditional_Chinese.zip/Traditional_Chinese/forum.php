<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'發表新主題',
'Views'			=>	'點閱',
'Moved'			=>	'已移動',
'Sticky'		=>	'置頂',
'Empty forum'	=>	'目前沒有文章。'

);
