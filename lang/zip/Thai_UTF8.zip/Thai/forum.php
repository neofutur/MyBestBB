<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'ตั้งกระทู้ใหม่',
'Views'			=>	'การอ่าน',
'Moved'			=>	'ถูกย้าย',
'Sticky'		=>	'ปักหมุด',
'Empty forum'	=>	'ไม่มีเนื้อหาในฟอรั่ม'

);
