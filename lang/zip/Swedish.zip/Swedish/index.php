<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Tr�dar',
'Moderators'			=>  'Moderatorer',
'Link to'				=>	'L�nk till',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Forumet �r tomt.',
'Newest user'			=>	'Senast registrerade anv�ndaren',
'Users online'			=>	'Registrerade anv�ndare online',
'Guests online'			=>	'G�ster online',
'No of users'			=>	'Totalt antal registrerade anv�ndare',
'No of topics'			=>	'Totalt antal tr�dar',
'No of posts'			=>	'Totalt antal inl�gg',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Foruminformation',
'Board stats'			=>	'Forumstatistik',
'User info'				=>	'Anv�ndarstatistik'

);
