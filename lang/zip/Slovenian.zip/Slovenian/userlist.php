<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'I��i in sortiraj uporabnike',
'User search info'		=>	'Vnesi  uporabnika in/ali uporabni�ko skupino, ki jo �eli� filtrirati. Uporabni�ko ime je lahko prazno. Uporabi * za delno ujemanje. Sortiraj uporabnike glede na ime, datum registracije ali �tevilo objav in v nara��ajo�e/padajo�em vrstnem redu.',
'User group'			=>	'Uporabni�ka skupina',
'No of posts'			=>	'�tevilo objav',
'All users'				=>	'Vsi'

);
