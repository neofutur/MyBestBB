<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Delete post',
'Warning'				=>	'Dikkat!!! Ba�l�ktaki ilk iletiyi silerseniz b�t� zincir silinecektir.',
'Delete'				=>	'Sil',	// The submit button
'Post del redirect'		=>	'�leti silindi. Y�nlendirme &hellip;',
'Topic del redirect'	=>	'Ba�l�k silindi.Y�nlendirme &hellip;'

);
