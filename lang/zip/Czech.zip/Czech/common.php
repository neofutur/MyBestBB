<?php


// Determine what locale to use
switch (PHP_OS)
{
	case 'WINNT':
	case 'WIN32':
		$locale = 'czech';
		break;

	case 'FreeBSD':
	case 'NetBSD':
	case 'OpenBSD':
		$locale = 'cz_CZ.cp-1250';
		break;

	default:
		$locale = 'cz_CZ';
		break;
}

// Attempt to set the locale
setlocale(LC_CTYPE, $locale);


// Language definitions for frequently used strings
$lang_common = array(

// Text orientation and encoding
'lang_direction'		=>	'ltr',	// ltr (Left-To-Right) or rtl (Right-To-Left)
'lang_encoding'			=>	'windows-1250',
'lang_multibyte'		=>	false,

// Notices
'Bad request'			=>	'�patn� po�adavek. Objekt, kter� jste po�adovali, je nespr�vn� nebo star�.',
'No view'				=>	'Nem�te opr�vn�n� prohl�et toto f�rum.',
'No permission'			=>	'Nem�te opr�vn�n� p��stupu na str�nku.',
'Bad referrer'			=>	'�patn� HTTP_REFERER. Byli jste p�esm�rov�ni na tuto str�nku z neautorizovan�ho zdroje. Pokud probl�m p�etrv�v�, pros�m ov��te, zda \'Base URL\' je nastaven� v Administrace/Options and a �e jste nav�t�vili f�rum p�es tuto adresu URL. Tak� ov��te, zda V� prohl�e� nebo proxy server tyto hlavi�ky pos�l� spr�vn�. V�ce informac� o kontrole HTTP_REFERER naleznete v dokumentaci k PunBB.',

// Topic/forum indicators
'New icon'				=>	'V t�matu jsou nov� p��sp�vky',
'Normal icon'			=>	'<!-- -->',
'Closed icon'			=>	'T�ma je zav�eno.',
'Redirect icon'			=>	'P�esm�rovan� f�rum',

// Miscellaneous
'Announcement'			=>	'Ozn�men�',
'Options'				=>	'Nastaven�',
'Actions'				=>	'�innosti',
'Submit'				=>	'Odeslat',	// "name" of submit buttons
'Ban message'			=>	'M�te ban (z�kaz) pro toto f�rum.',
'Ban message 2'			=>	'Ban (z�kaz) vypr��:',
'Ban message 3'			=>	'Administr�tor nebo moder�tor, kter� V�s zabanoval zanechal n�sleduj�c� zpr�vu:',
'Ban message 4'			=>	'Jak�koliv dotazy sm��ujte na administr�tora',
'Never'					=>	'Nikdy',
'Today'					=>	'Dnes',
'Yesterday'				=>	'V�era',
'Info'					=>	'Info',		// a common table header
'Go back'				=>	'Zp�t',
'Maintenance'			=>	'�dr�ba',
'Redirecting'			=>	'P�esm�rov�n�',
'Click redirect'		=>	'Klikn�te sem pro rychl� p�esm�rov�n� (nebo pokud v�s prohl�e� automaticky nep�esm�roval)',
'on'					=>	'on',		// as in "BBCode is on"
'off'					=>	'off',
'Invalid e-mail'		=>	'Zadan� e-mailov� adresa nen� platn�.',
'required field'		=>	'je nutn� vyplnit v tomto formul��i',	// for javascript form validation
'Last post'				=>	'Posledn� p��sp�vek',
'by'					=>	'od',	// as in last post by someuser
'New posts'				=>	'Nov�&nbsp;p��sp�vek',	// the link that leads to the first new post (use &nbsp; for spaces)
'New posts info'		=>	'Zobrazit nejnov�j�� p��sp�vek v t�matu.',	// the popup text for new posts links
'Username'				=>	'U�ivatelsk� jm�no',
'Password'				=>	'Va�e heslo',
'E-mail'				=>	'E-mail',
'Send e-mail'			=>	'Poslat e-mail',
'Moderated by'			=>	'Moderuje',
'Registered'			=>	'Registrovan�',
'Subject'				=>	'P�edm�t',
'Message'				=>	'Zpr�va',
'Topic'					=>	'T�ma',
'Forum'					=>	'F�rum',
'Posts'					=>	'P��sp�vky',
'Replies'				=>	'Odpov�di',
'Author'				=>	'Autor',
'Pages'					=>	'Str�nky',
'BBCode'				=>	'BBCode',	// You probably shouldn't change this
'img tag'				=>	'[img] tag',
'Smilies'				=>	'Smajl�ky',
'and'					=>	'a',
'Image link'			=>	'obr�zek',	// This is displayed (i.e. <image>) instead of images when "Show images" is disabled in the profile
'wrote'					=>	'napsal(a)',	// For [quote]'s
'Code'					=>	'Code',		// For [code]'s
'Mailer'				=>	'Mailer',	// As in "MyForums Mailer" in the signature of outgoing e-mails
'Important information'	=>	'D�le�it� informace',
'Write message legend'	=>	'Napi� zpr�vu a ode�li',

// Title
'Title'					=>	'Titulek',
'Member'				=>	'�len',	// Default title
'Moderator'				=>	'Moder�tor',
'Administrator'			=>	'Administr�tor',
'Banned'				=>	'Zablokovan�',
'Guest'					=>	'Host',

// Stuff for include/parser.php
'BBCode error'			=>	'Syntaxe BBCode ve zpr�v� je �patn�.',
'BBCode error 1'		=>	'Chyb� �vodn� tag pro [/quote].',
'BBCode error 2'		=>	'Chyb� ukon�ovac� tag pro [code].',
'BBCode error 3'		=>	'Chyb� �vodn� tag pro [/code].',
'BBCode error 4'		=>	'Chyb� jeden �i v�ce ukon�ovac�ch tag� pro [quote].',
'BBCode error 5'		=>	'Chyb� jeden �i v�ce po��te�n�ch tag� pro [/quote].',

// Stuff for the navigator (top of every page)
'Index'					=>	'Index',
'User list'				=>	'Seznam u�ivatel�',
'Rules'					=>  'Pravidla',
'Search'				=>  'Hledat',
'Register'				=>  'Registrace',
'Login'					=>  'P�ihl�sit',
'Not logged in'			=>  'Nejste p�ihl�en(a)',
'Profile'				=>	'Profil',
'Logout'				=>	'Odhl�sit',
'Logged in as'			=>	'P�ihl�en jako',
'Admin'					=>	'Administrace',
'Last visit'			=>	'Posledn� n�v�t�va',
'Show new posts'		=>	'Zobrazit nov� p��sp�vky od posledn� n�v�t�vy',
'Mark all as read'		=>	'Ozna�it v�echna t�mata jako p�e�ten�',
'Mark forum as read'	=>	'Ozna�it toto f�rum za p�e�ten�', // MOD: MARK TOPICS AS READ
'Link separator'		=>	'',	// The text that separates links in the navigator

// Stuff for the page footer
'Board footer'			=>	'Z�pat�',
'Search links'			=>	'Hledan� odkazy',
'Show recent posts'		=>	'Zobrazit posledn� p��sp�vky',
'Show unanswered posts'	=>	'Zobrazit p��sp�vky bez odpov�d�',
'Show your posts'		=>	'Zobrazit m� p��sp�vky',
'Show subscriptions'	=>	'Zobrazit t�mata s oznamov�n�m',
'Jump to'				=>	'P�ej�t na',
'Go'					=>	'P�ej�t',		// submit button in forum jump
'Move topic'			=>  'P�esunout t�ma',
'Open topic'			=>  'Otev��t t�ma',
'Close topic'			=>  'Zav��t t�ma',
'Unstick topic'			=>  'Zru�it zv�razn�n�',
'Stick topic'			=>  'Zv�raznit t�ma',
'Moderate forum'		=>	'Moderovat f�rum',
'Delete posts'			=>	'Smazat v�ce p��sp�vk�',
'Debug table'			=>	'Lad�c� informace',

// For extern.php RSS feed
'RSS Desc Active	'	=>	'Nejaktivn�j�� t�mata',	// board_title will be appended to this string
'RSS Desc New'			=>	'Nejnov�j�� t�mata',					// board_title will be appended to this string
'Posted'				=>	'Zaslan�'	// The date/time a topic was started

);

$czech_days=array(
	'Ned�le',
	'Pond�l�',
	'�ter�',
	'St�eda',
	'�tvrtek',
	'P�tek',
	'Sobota'
);

$v_czech_days=array(
	'v ned�li',
	'v pond�l�',
	'v �ter�',
	've st�edu',
	've �tvrtek',
	'v p�tek',
	'v sobotu'
);

function new_msg_cz($num)
{
	switch($num)
	{
		case 0:return '��dn� nov�';
		case 1:return '1 nov�';
		case 2:
		case 3:
		case 4:return $num.' nov�';
		default:return $num.' nov�ch';
	}
}
