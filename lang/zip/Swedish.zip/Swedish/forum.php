<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Skapa ny tr�d',
'Views'			=>	'Visningar',
'Moved'			=>	'Flyttad',
'Sticky'		=>	'Klistrad',
'Empty forum'	=>	'Forumet �r tomt.'

);
