<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'	=>	'V��r� tunnus ja/tai salasana.',
'Forgotten pass'	=>	'Oletko unohtanut salasanasi?',
'Login redirect'	=>	'Kirjautuminen palveluun onnistui. Paluu sivulle &hellip;',
'Logout redirect'	=>	'Olet kirjautunut pois palvelusta. Paluu sivulle &hellip;',
'No e-mail match'	=>	'K�ytt�j�rekisterist� ei l�ydy s�hk�postiosoitetta',
'Request pass'		=>	'Vaihda salasana',
'Request pass legend'	=>	'Anna s�hk�postiosoite, jota k�ytit rekister�ityess�si.',
'Request pass info'	=>	'Uusi salasana ja linkki sen aktivoimiseksi l�hetet��n antamaasi osoitteeseen.',
'Not registered'	=>	'Etk� ole viel� rekister�itynyt?',
'Login legend'		=>	'Anna k�ytt�j�tunnuksesi ja salasanasi',
'Login info'		=>	'Jos et ole viel� rekister�itynyt tai olet unohtanut salasanasi, klikkaa alla olevaa linkki�.',

// Forget password mail stuff
'Forget mail'		=>	'Antamaasi osoitteeseen on l�hetetty ohjeet kuinka saat vaihdettua salasanaasi. Jos et saa kyseist� viesti�, voit ottaa yhteytt� forumin yll�pit�j��n'

);
