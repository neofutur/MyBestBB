﻿<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'پوسٹ ختم کریں',
'Warning'				=>	'انتباہ! اگر یہ موضوع کا پہلا مراسلہ ہے تو پورا موضوع ختم کر دیا جائے گا۔',
'Delete'				=>	'ختم کریں',	// The submit button
'Post del redirect'		=>	'مراسلہ ختم کر دیا گیا۔ منتقل کیا جا رہا ہے &hellip;',
'Topic del redirect'	=>	'موضوع ختم کر دیا گیا۔ منتقل کیا جا رہا ہے  &hellip;'

);
