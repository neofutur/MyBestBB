<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Nou Tema',
'Views'			=>	'Vist',
'Moved'			=>	'Mogut',
'Sticky'		=>	'Permanent',
'Empty forum'	=>	'El f�rum est� buit.'

);
