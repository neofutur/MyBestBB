<?php

// Language definitions used in both profile.php and register.php
$lang_prof_reg = array(

'E-mail legend'                                =>        'Tw�j adres email',
'E-mail legend 2'                        =>        'Adres email',
'Localisation legend'                =>        'Ustaw opcje lokalizacji',
'Timezone'                                        =>        'Strefa Czasowa',
'Timezone info'                                =>        'Dla poprawnego wy�wietlania czasu na forum musisz wybra� stref� czasow�.',
'Language'                                        =>        'J�zyk',
'Language info'                                =>        'Mo�esz wybra� j�zyk, w kt�rym ma by� wy�wietlane forum.',
'E-mail setting info'                =>        'Tutaj mo�esz zdefiniowa� parametry wy�wietlania i odbierania emaili od innych uzytkownik�w forum.',
'E-mail setting 1'                        =>        'Pokazuj adres email.',
'E-mail setting 2'                        =>        'Ukryj adres email ale zezw�l na form� email',
'E-mail setting 3'                        =>        'Ukryj adres email i wy��cz form� email.',
'Privacy options legend'        =>        'Ustaw Twoje prywatne opcje',
'Save user/pass'                        =>        'Zapami�taj login i has�o pomi�dzy wizytami.',
'Save user/pass info'                =>        'Opcja pozwala na zaoszcz�dzenie czasu przez automatyczne logowanie.',
'Confirm pass'                                =>        'Potwierd� has�o',

'Username too short'                =>        'Login musi mie� minimum 2 znaki. Wybierz inny, d�u�szy.',
'Username guest'                        =>        'Login guest/go�� jest zarejestrowany.',
'Username IP'                                =>        'Login nie mo�e by� w formie adresu ip. Wybierz inny.',
'Username reserved chars'        =>        'Login nie mo�e zawiera� znak�w  \', " oraz [ lub ].',
'Username BBCode'                        =>        'Login nie mo�e zawiera� element�w BBCode.',
'Dupe username'                                =>       'Kto� ju� zarejestrowa� takiego u�ytkownika. Przepraszamy.',
'Pass too short'                        =>        'Has�o musi mie� minimum 4 znaki. Prosimy wybra� d�u�sze.',
'Pass not match'                        =>        'Has�a nie pasuj� do siebie. Powr�� i je popraw',
'Banned e-mail'                                =>        'Adres email kt�ry poda�e� zosta� zbanowany na tym forum. Podaj inny.',
'Dupe e-mail'                                =>        'Kto� ju� zarejestrowa� si� na podany adres email. Wpisz inny adres.',
'Sig too long'                                =>        'Sygnatura nie mo�e by� d�u�sza ni�',
'characters'                                =>        'znak�w',
'Sig too many lines'                =>        'Sygnatura nie mo�e mie� wi�cej ni�',
'lines'                                                =>        'linii',
'Signature quote/code'                =>        'BBCode: quote oraz code nie s� dozwolone w sygnaturkach. Powr�� i to popraw.',
'Bad ICQ'                                        =>        'Wpisa�e� niepoprawny adres ICQ, wr�� i popraw.'

);
