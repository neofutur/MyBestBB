<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Trimite răspuns',
'Topic closed'		=>	'Subiect închis',
'From'				=>	'Locaţie',				// User location
'Note'				=>	'Notă',				// Admin note
'Website'			=>	'Site web',
'Guest'				=>	'Oaspete',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Editat ultima oară de',
'Report'			=>	'Raportează',
'Delete'			=>	'Şterge',
'Edit'				=>	'Editează',
'Quote'				=>	'Citează',
'Is subscribed'		=>	'Sunteţi abonat la acest subiect',
'Unsubscribe'		=>	'Dezabonare',
'Subscribe'			=>	'Abonare la acest subiect',
'Quick post'		=>	'Mesaj rapid',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Controale moderator'

);
