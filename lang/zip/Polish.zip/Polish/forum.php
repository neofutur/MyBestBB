<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'        =>        'Nowy W�tek',
'Views'                        =>        'Wy�wietlenia',
'Moved'                        =>        'Przeniesiony',
'Sticky'                =>        'Przyklejony',
'Empty forum'        =>        'Forum jest puste.'

);
