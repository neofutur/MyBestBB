##
##
##        Mod title:  Private Messaging System (PMS)
##
##      Mod version:  1.2.2
##   Works on PunBB:  1.2.x
##     Release date:  2005-10-05
##           Author:  Connorhd (connorhd@mypunbb.com)
##  Original Author:  David 'Chacmool' Djurb�ck (chacmool@spray.se)
##
##      Description:  Private Messaging System for PunBB
##
##   Affected files:  viewtopic.php
##                    footer.php
##                    header.php
##                    include/functions.php
##                    profile.php
##
##       Affects DB:  New table:
##                       'messages'
##                    New options:
##                       'o_pms_enabled'
##                       'o_pms_mess_per_page'
##                    New permissions:
##                       'g_pm'
##                       'g_pm_limit'
##
##
##        Upgrading:  Use this file as the upgrading readme.
##
##
##       DISCLAIMER:  Please note that "mods" are not officially supported by
##                    PunBB. Installation of this modification is done at your
##                    own risk. Backup your forum database and any and all
##                    applicable files before proceeding.
##
##


#
#---------[ 3. DELETE ]-------------------------------------------------------
#

message_delete.php
message_list.php
message_send.php
include/pms/*.*

#
#---------[ 1. UPLOAD ]-------------------------------------------------------
#

install_mod.php to /

files/*.* to /

files/plugins/AP_Private_messaging.php to /plugins/AP_Private_messaging.php

files/include/pms/*.* to /include/pms/

#
#---------[ 2. RUN ]----------------------------------------------------------
#

install_mod.php

#
#---------[ 3. DELETE ]-------------------------------------------------------
#

install_mod.php

#
#---------[ 4. OPEN ]---------------------------------------------------------
#

profile.php

#
#---------[ 5. FIND (line: 1050) ]-------------------------------------------------
#

							$email_field = '<label><strong>'.$lang_common['E-mail'].'</strong><br /><input type="text" name="req_email" value="'.$user['email'].'" size="40" maxlength="50" /><br /></label><p><a href="misc.php?email='.$id.'">'.$lang_common['Send e-mail'].'</a></p>'."\n";

#
#---------[ 6. AFTER, ADD ]---------------------------------------------------
#

			require PUN_ROOT.'lang/'.$pun_user['language'].'/pms.php';
			$email_field .= '<p><a href="message_send.php?id='.$id.'">'.$lang_pms['Quick message'].'</a></p>'."\n";

#
#---------[ 7. OPEN ]---------------------------------------------------------
#

admin_options.php

#
#---------[ 8. FIND (line: 404) ]-------------------------------------------------
#

<?php require(PUN_ROOT.'include/pms/admin_options.php'); ?>

#
#---------[ 9. DELETE LINE ]---------------------------------------------------
#

#
#---------[ 10. SAVE/UPLOAD ]-------------------------------------------------
#