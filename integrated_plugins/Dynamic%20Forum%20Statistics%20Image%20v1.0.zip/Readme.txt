##
##
##        Mod title:  Dynamic Forum Statistics Image
##
##      Mod version:  1.0
##   Works on PunBB:  1.2.*
##     Release date:  2005-09-14
##           Author:  Fakhruddin (admin@mastiland.com)
##
##      Description:  This mod makes an image of your current forum statistics!
##
##   Affected files:  .htaccess
##
##
##       Affects DB:  No
##
##            Notes:  1) custom .htacess should be allowed by the server
##                    2) To Change the Background Image (It should be in png format) just name it sign.png
##
##
##       DISCLAIMER:  Please note that "mods" are not officially supported by
##                    PunBB. Installation of this modification is done at your
##                    own risk. Backup your forum database and any and all
##                    applicable files before proceeding.
##
##
##

#
#---------[ 1. CHANGE ]-------------------------------------------------------
#

change htaccess.txt to .htaccess (WITH THE . ) 

or

if u are havin .htaccess from before then add


<FilesMatch "^.*\.png">
   SetHandler application/x-httpd-php
</FilesMatch>
 

to .htaccess


#
#---------[ 2. UPLOAD ]-------------------------------------------------------
#

signature.png to /
.htaccess to /
sign.png to /

#
#---------[ Finish and Enjoy ]------------------------------------------------
#

Your Dynamic Forum Statistics Image will be forund at /signature.png