<?php

// Language definitions used in chatbox.php
$lang_chatbox = array(

'Page_title'				=>	'ChatBox',
'Chatbox'				=>	'ChatBox',
'Posts'				=>	' ChatBox Posts',
'Sending'				=>	'Patientez...',

'No Read Permission'				=>	'Vous n\'�tes pas autoris� � consulter la ChatBox.',
'No Post Permission'				=>	'Vous n\'�tes pas autoris� � poster dans la ChatBox.',
'No Message'				=>	'Il n\'y a actuellement aucun message dans la ChatBox.',

'Message'				=>	'Message',
'Btn Send'				=>	'Poster',
'Btn Refresh'			=>	'Actualiser',

'Error No message'				=>	'Vous n\'avez pas indiqu� de message !',
'Error Too long message'				=>	'Votre message est trop long !',

);
