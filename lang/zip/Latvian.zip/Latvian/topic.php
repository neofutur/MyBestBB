<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Rakst�t atbildi',
'Topic closed'		=>	'T�ma sl�gta',
'From'				=>	'No',				// User location
'Note'				=>	'Piez�me',				// Admin note
'Website'			=>	'Web saite',
'Guest'				=>	'Viesis',
'Online'			=>	'Pa�laik �eit',
'Offline'			=>	'Pa�laik nav �eit',
'Last edit'			=>	'P�d�jais laboja',
'Report'			=>	'Zi�ot',
'Delete'			=>	'Dz�st',
'Edit'				=>	'Labot',
'Quote'				=>	'Cit�ts',
'Is subscribed'		=>	'Tu jau esi pierakst�jies uz �o t�mu',
'Unsubscribe'		=>	'Atrakst�ties',
'Subscribe'			=>	'Pierakst�ties',
'Quick post'		=>	'Rakst�t koment�ru',

'Link separator'	=>	'|',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'T�mu vad�t�ja kontroles'

);
