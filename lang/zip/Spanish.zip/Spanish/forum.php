<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Nuevo tema',
'Views'			=>	'Vistas',
'Moved'			=>	'Movido',
'Sticky'		=>	'Permanente',
'Empty forum'	=>	'El foro est� vac�o.'

);
