<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Upis nove teme',
'Views'			=>	'Pregledano',
'Moved'			=>	'Pomeren',
'Sticky'		=>	'Lepljiv',
'Empty forum'	=>	'Forum je prazan.'

);
