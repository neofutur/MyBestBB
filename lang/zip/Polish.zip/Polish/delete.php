<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'                        =>        'Usu� post',
'Warning'                                =>        'Uwaga! Je�eli to jest pierwszy post to ca�y w�tek zostanie usuni�ty .',
'Delete'                                =>        'Usu�',        // The submit button
'Post del redirect'                =>        'Post usuni�ty. Przekierowywanie &hellip;',
'Topic del redirect'        =>        'W�tek usuni�ty. Przekierowywanie &hellip;'

);
