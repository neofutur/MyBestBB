<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  	'T�mata',
'Moderators'			=>  	'Moder�to�i',
'Link to'				=>	'Odkaz na',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'F�rum je pr�zdn�',
'Newest user'			=>	'Nejnov�j�� registrovan� u�ivatel',
'Users online'			=>	'Registrovan� u�ivatel� online',
'Guests online'			=>	'Host� online',
'No of users'			=>	'Celkem registrovan�ch u�ivatel�',
'No of topics'			=>	'T�mat',
'No of posts'			=>	'P��sp�vk�',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informace o f�ru',
'Board stats'			=>	'Statistika f�ra',
'User info'				=>	'Informace o u�ivateli'

);
