<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  '이야깃거리',
'Moderators'			=>  '돌보는 이',
'Link to'				=>	'링크 -',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'계시판이 비어 있습니다.',
'Newest user'			=>	'가장 최근에 등록한 사용자',
'Users online'			=>	'방문중인 등록 사용자',
'Guests online'			=>	'방문중인 손님',
'No of users'			=>	'전체 등록 사용자 수',
'No of topics'			=>	'전체 이야깃거리 수',
'No of posts'			=>	'전체 글 수',
'Online'				=>	'들어옴',	// As in "Online: User A, User B etc."
'Board info'			=>	'계시판 정보',
'Board stats'			=>	'계시판 통계수치',
'User info'				=>	'사용자 정보'

);
