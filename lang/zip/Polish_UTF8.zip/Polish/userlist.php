<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'                =>        'Wyszukaj użytkowników',
'User search info'                =>        'Wpisz  użytkownika lub wybierz grupę, której członków chcesz zobaczyć. Pole użytkownika może być puste. Używaj znaku * dla częściowych wyników. Sortuj użytkowników nazwami, datą rejestracji lub liczbą postów oraz w rosnącej/malejącej kolejności.',
'User group'                        =>        'Grupa użytkownika',
'No of posts'                        =>        'Liczba postów',
'All users'                                =>        'Wszystkie'

);
