<?php
// Language definitions used in index.php
$lang_index = array(
'Topics' => 'Chủ đề',
'Moderators' => 'Người điều hành',
'Link to'		=>	'Liên kết đến',	// As in "Link to http://www.punbb.org/"
'Empty board'	=>	'Diễn đàn trống.',
'Newest user'      => 'Thành viên mới nhất là',
'Users online'	=>	'Thành viên đăng ký đang trực tuyến',
'Guests online'	=>	'Khách trực tuyến',
'No of users'	=>	'Tổng số thành viên đăng ký',
'No of topics'	=>	'Tổng số chủ đề',
'No of posts'	=>	'Tổng số bài',
'Online'		=>	'Trực tuyến',	// As in "Online: User A, User B etc."
'Board info'	=>	'Bảng tin tức',
'Board stats'	=>	'Bảng thống kê',
'User info'		=>	'Thông tin người dùng'
);
