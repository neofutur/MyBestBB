<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Теми',
'Moderators'			=>  'Модератори',
'Link to'				=>	'Посилання на',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Форум порожній.',
'Newest user'			=>	'Останній зареєстрований відвідувач',
'Users online'			=>	'Зараз зареєстрованих відвідувачів',
'Guests online'			=>	'Зараз гостей',
'No of users'			=>	'Всього зареєстрованих відвідувачів',
'No of topics'			=>	'Всього тем',
'No of posts'			=>	'Всього повідомлень',
'Online'				=>	'Зараз на форумі',	// As in "Online: User A, User B etc."
'Board info'			=>	'Інформація про форум',
'Board stats'			=>	'Статистика форуму',
'User info'				=>	'Інформація про відвідувача'

);
