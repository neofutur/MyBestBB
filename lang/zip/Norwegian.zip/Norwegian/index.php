<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Emner',
'Moderators'			=>  'Moderatorer',
'Link to'				=>	'Link til',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Forumet er tomt.',
'Newest user'			=>	'Nyeste registrerte bruker',
'Users online'			=>	'Registrerte brukere p�logget',
'Guests online'			=>	'Uregistrerte bes�kende',
'No of users'			=>	'Totalt antall registrerte brukere',
'No of topics'			=>	'Totalt antall emner',
'No of posts'			=>	'Totalt antall poster',
'Online'				=>	'P�logget',	// As in "Online: User A, User B etc."
'Board info'			=>	'Forum-informasjon',
'Board stats'			=>	'Forum-statistikk',
'User info'				=>	'Brukerinformasjon'

);
