You can find installation instructions for my modifications to the PunBB signup process on my website by navigating to the following URL:
http://www.network-technologies.org/Projects/Virtual_Brain_Online/article/spam_bot_registration_mod_punbb/

Please report any issues or send suggestions via the Contact Page at:
http://www.network-technologies.org/contact.php

Please note that the register.php file contained within the archive has the submit button disabling java script removed and has my SPAM fighting modifications installed.

Quick installation instructions:
- Copy the files register.php and QandA.php from the archive into the PunBB root directory, overwriting the existing register.php file.
- Edit the file QandA.php with a text editor and fill it with your own questions and answers. This is very important since the best lock in the world will not protect you if the key is public.... 
The file is self explaining but contains instructions as well.

Uninstall:
The archive also contains the file register.php.original which you can rename back to register.php to remove all changes I have made. Deleting QandA.php is optional as it is only used by my modified register.php

