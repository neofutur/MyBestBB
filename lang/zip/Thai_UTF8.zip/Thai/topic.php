<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'โพสต์ตอบ',
'Topic closed'		=>	'กระทู้ถูกปิด',
'From'				=>	'มาจาก',				// User location
'Note'				=>	'โน้ต',				// Admin note
'Website'			=>	'เว็บไซต์',
'Guest'				=>	'ผู้มาเยือน',
'Online'			=>	'ออนไลน์',
'Offline'			=>	'ออฟไลน์',
'Last edit'			=>	'แก้ไขครั้งล่าสุด​โดย',
'Report'			=>	'รายงาน',
'Delete'			=>	'ลบ',
'Edit'				=>	'แก้ไข',
'Quote'				=>	'อ้างถึง',
'Is subscribed'		=>	'คุณกำลังติดตามกระทู้นี้',
'Unsubscribe'		=>	'ยกเลิกการติดตาม',
'Subscribe'			=>	'ติดตามกระทู้',
'Quick post'		=>	'โพสต์โดยด่วน',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'ส่วนควบคุมผู้ดูแลฟอรั่ม'

);
