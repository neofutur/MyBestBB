<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Creează un nou subiect',
'Views'			=>	'Vizualizări',
'Moved'			=>	'Mutat',
'Sticky'		=>	'Fixat',
'Empty forum'	=>	'Forumul este gol.'

);
