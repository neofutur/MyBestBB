<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Post svar',
'Topic closed'		=>	'Emne lukket',
'From'				=>	'Fra',				// User location
'Note'				=>	'Notat',				// Admin note
'Website'			=>	'Hjemmeside',
'Guest'				=>	'Gjest',
'Online'			=>	'P�logget',
'Offline'			=>	'Avlogget',
'Last edit'			=>	'Sist endret av',
'Report'			=>	'Rapporter',
'Delete'			=>	'Slett',
'Edit'				=>	'Endre',
'Quote'				=>	'Sit�r',
'Is subscribed'		=>	'Du abonnerer for �yeblikket p� dette emnet',
'Unsubscribe'		=>	'Avslutt abonnement',
'Subscribe'			=>	'Abonner p� dette emnet',
'Quick post'		=>	'Raskt svar',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Moderator-kontroll'

);
