<?php

// Language definitions used in profile.php
$lang_profile = array(

// Navigation and sections
'Profile menu'                                =>        'Menu Profilu',
'Section essentials'                =>        'G��wne',
'Section personal'                        =>        'Personalne',
'Section messaging'                        =>        'Komunikatory',
'Section personality'                =>        'Sygnatura/Avatar',
'Section display'                        =>        'Wy�wietlanie',
'Section privacy'                        =>        'Prywatno��',
'Section admin'                                =>        'Administracja',

// Miscellaneous
'Username and pass legend'        =>        'Wprowad� login i has�o',
'Personal details legend'        =>        'Wprowad� dane personalne',
'Contact details legend'        =>        'Wprowad� dane komunikator�w',
'Options display'                        =>        'Ustaw opcje wy�wietlania',
'Options post'                                =>        'Wy�wietlanie post�w',
'User activity'                                =>        'Informacje',
'Paginate info'                                =>        'Liczba w�tk�w i post�w ktore maj� by� wy�wietlone na jednej stronie.',

// Password stuff
'Pass key bad'                                =>        'Klucz aktywacyjny has�a jest niepoprawny lub przedawniony. U�yj ponownie funkcji zmiany has�a. Je�eli to nie pomo�e skontaktuj si� z administratorem na',
'Pass updated'                                =>        'Has�o zosta�o zaktualizowane. Mo�esz si� teraz zalogowa� z nowym has�em.',
'Pass updated redirect'                =>        'Has�o zaktualizowane. Przekierowywanie &hellip;',
'Wrong pass'                                =>        'Z�e stare has�o.',
'Change pass'                                =>        'Zmie� has�o',
'Change pass legend'                =>        'Wprowad� i potwierd� nowe has�o',
'Old pass'                                        =>        'Stare has�o',
'New pass'                                        =>        'Nowe has�o',
'Confirm new pass'                        =>        'Potwierd� nowe has�o',

// E-mail stuff
'E-mail key bad'                        =>        'Podany klucz aktywacyjny emaila jest niepoprawny lub wygas�. U�yj ponownie funkcji zmiany adresu email. Je�eli to nie pomo�e skontaktuj si� z administratorem na',
'E-mail updated'                        =>        'Tw�j adres email zosta� zaktualizowany.',
'Activate e-mail sent'                =>        'Email zosta� wys�any na podany adres z instrukcj� jak go aktywowa�. Je�eli to nie dzia�a to skontaktuj si� z administratorem na',
'E-mail legend'                                =>        'Wprowad� Tw�j nowy adres',
'E-mail instructions'                =>        'Email z linkiem aktywacyjnym zostanie wys�any na nowy adres. Aby aktywowa� nowy adres musisz klikn�� w link znajduj�cy si� w tym emailu.',
'Change e-mail'                                =>        'Zmie� adres email',
'New e-mail'                                =>        'Nowy e-mail',

// Avatar upload stuff
'Avatars disabled'                        =>        'Administrator zablokowa� wsparcie avatar�w.',
'Too large ini'                                =>        'Wybrany plik by� zbyt du�y aby go wys�a�. Serwer nie pozwala na wys�anie.',
'Partial upload'                        =>        'Plik zosta� cz�ciowo wys�any. Spr�buj ponownie.',
'No tmp directory'                        =>        'PHP nie by� w stanie zapisa� pliku do podanego katalogu.',
'No file'                                        =>        'Nie wybra�e� pliku do wys�ania.',
'Bad type'                                        =>        'Typ pliku kt�ry chcesz wys�a� jest niedozwolony. Typy dozwolone to: gif, jpeg i png.',
'Too wide or high'                        =>        'Plik kt�ry chcesz wys�a� przekracza dozwolon� szeroko�� lub wysoko��',
'Too large'                                        =>        'Plik kt�ry chcesz wys�a� jest zbyt du�y',
'pixels'                                        =>        'pixeli',
'bytes'                                                =>        'bajty',
'Move failed'                                =>        'Serwer nie by� w stanie pobra� wysy�anego pliku. Skontaktuj si� z administratorem na',
'Unknown failure'                        =>        'Wyst�pi� nieznany b��d. Pr�buj ponownie.',
'Avatar upload redirect'        =>        'Avatar wys�any. Przekierowywanie &hellip;',
'Avatar deleted redirect'        =>        'Avatar usuni�ty. Przekierowywanie &hellip;',
'Avatar desc'                                =>        'Avatar jest ma�ym obrazkiem kt�ry b�dzie wywietlany pod Twoim loginem w postach. Nie mo�e by� wi�kszy ni�',
'Upload avatar'                                =>        'Wy�lij Avatar',
'Upload avatar legend'                =>        'Wprowad� plik do wys�ania',
'Delete avatar'                                =>        'Usu� avatar',        // only for admins
'File'                                                =>        'Plik',
'Upload'                                        =>        'Wy�lij',        // submit button

// Form validation stuff
'Dupe username'                                =>        'Kto� ju� zarejestrowa� sobie taki login. Wr�� i spr�buj inny.',
'Forbidden title'                        =>        'Tytu� kt�ry wpisa�e� zawiera zakazane s�owa. Musisz wybra� inny.',
'Profile redirect'                        =>        'Profil zaktualizowany. Przekierowywanie &hellip;',

// Profile display stuff
'Not activated'                                =>        'Ten u�ytkownik nie aktywowa� jeszcze swojego konta. Konto staje si� aktywne po pierwszym zalogowaniu.',
'Unknown'                                        =>        '(Nieznany)',        // This is displayed when a user hasn't filled out profile field (e.g. Location)
'Private'                                        =>        '(Prywatny)',        // This is displayed when a user does not want to receive e-mails
'No avatar'                                        =>        '(Brak avatara)',
'Show posts'                                =>        'Poka� wszystkie posty',
'Realname'                                        =>        'Prawdziwe imi�',
'Location'                                        =>        'Lokacja',
'Website'                                        =>        'Strona WWW',
'Jabber'                                        =>        'Jabber',
'ICQ'                                                =>        'ICQ',
'MSN'                                                =>        'MSN Messenger',
'AOL IM'                                        =>        'AOL IM',
'Yahoo'                                                =>        'Yahoo! Messenger',
'Avatar'                                        =>        'Avatar',
'Signature'                                        =>        'Sygnatura',
'Sig max length'                        =>        'Maksymalna d�ugo��',
'Sig max lines'                                =>        'Maksymalna ilo�� linii',
'Avatar legend'                                =>        'Opcje wy�wietlania avatara',
'Avatar info'                                =>        'Avatar jest obrazkiem, kt�ry b�dzie wy�wietlany przy wszystkich Twoich postach. Mo�esz wys�a� obrazek klikaj�c w link poni�ej. Pami�taj o tym, �e avatar b�dzie wy�wietlany je�eli zaznaczysz pole "U�ywaj avatara".',
'Change avatar'                                =>        'Zmie� avatar',
'Use avatar'                                =>        'U�ywaj avatara.',
'Signature legend'                        =>        'Stw�rz w�asn� sygnatur�',
'Signature info'                        =>        'Sygnatura to tekst lub obrazek kt�ry mo�e by� do��czany do ka�dego posta. Mo�esz w niej wpisa� co tylko chcesz. W sygnaturce dzia�a BBCode, a w��czone/wy��czone opcje b�d� pokazane przy jej edycji.',
'Sig preview'                                =>        'Podgl�d aktualnej sygnatury:',
'No sig'                                        =>        'Brak sygnaturki w profilu.',
'Topics per page'                        =>        'W�tki',
'Topics per page info'                =>        'Ta opcja kontroluje liczb� w�tk�w wy�wietlonych na jednej stronie na forum. Je�eli nie jeste� pewny co wpisa� to pozostaw puste pole, wtedy zastosowane zostan� domy�le ustawienia.',
'Posts per page'                        =>        'Posts',
'Posts per page info'                =>        'Ta opcja kontroluje liczb� post�w wy�wietlonych na jednej stronie w w�tku. Je�eli nie jeste� pewny co wpisa� to pozostaw puste pole, wtedy zastosowane zostan� domy�le ustawienia.',
'Leave blank'                                =>        'Pozostaw puste dla domy�lnego ustawienia',
'Notify full'                                =>        'Zamieszczaj posty w subskrybowanych emailach.',
'Notify full info'                        =>        'Je�eli opcja jest w��czona to w emailach powiadamiaj�cych b�dzie zawarty post (sam tekst).',
'Show smilies'                                =>        'Pokazuj u�mieszki jako graficzne emotikony',
'Show smilies info'                        =>        'Ta opcja pozwala na zmiane tekstowych emot na obrazkowe emotikony.',
'Show images'                                =>        'Pokazuj obrazki w postach.',
'Show images info'                        =>        'Zablokuj to je�eli nie chcesz widzie� obrazk�w w postach (obrazki zamieszczone mi�dzy tagiem [img] a [/img]).',
'Show images sigs'                        =>        'Pokazuj obrazki w sygnaturach u�ytkownik�w.',
'Show images sigs info'                =>        'Zablokuj to je�eli nie chcesz ogl�da� obrazk�w w sygnaturach (obrazki zamieszczone mi�dzy tagiem [img] a [/img]).',
'Show avatars'                                =>        'Pokazuj avatary u�ytkownik�w w postach.',
'Show avatars info'                        =>        'Ta opcja pozwala u�ytkownikowi lub blokuje mo�liwo�� dodania obrazka znajduj�cego si� przy po�cie.',
'Show sigs'                                        =>        'Pokazuj sygnatur� u�ytkownika.',
'Show sigs info'                        =>        'W��cz to je�li chcesz widzie� sygnatury u�ytkownik�w.',
'Style legend'                                =>        'Wybierz preferowany styl',
'Style info'                                =>        'Ta opcja pozwala na zmian� stylu graficznego forum.',
'Admin note'                                =>        'Notka Admina',
'Pagination legend'                        =>        'Opcje wy�wietlania na forum',
'Post display legend'                =>        'Ustawienia dla przegl�dania post�w',
'Post display info'                        =>        'Dla posiadaczy bardzo wolnych ��cz. Wy��czaj�c te mo�liwo�ci przyspieszasz wczytywanie si� forum..',
'Instructions'                                =>        'Po zaktualizowaniu profilu zostaniesz przekierowany tutaj.',

// Administration stuff
'Group membership legend'        =>        'Wybierz grup� u�ytkownika',
'Save'                                                =>        'Zapisz',
'Set mods legend'                        =>        'Ustaw dost�p moderatora',
'Moderator in'                                =>        'Moderator na',
'Moderator in info'                        =>        'Wybierz kt�re fora mog� by� moderowane przez tego u�ytkownika. Dotyczy to tylko moderator�w, gdy� administratorzy maj� pe�ny dost�p na wszystkich forach.',
'Update forums'                                =>        'Aktualizuj fora',
'Delete ban legend'                        =>        'Usu� (tylko administratorzy) lub zbanuj u�ytkownika',
'Delete user'                                =>        'Usu� u�ytkownika',
'Ban user'                                        =>        'Zbanuj u�ytkownika',
'Confirm delete legend'                =>        'Przydatne: czytaj przed usuwaniem u�ytkownika',
'Confirm delete user'                =>        'Potwierd� usuni�cie u�ytkownika',
'Confirmation info'                        =>        'Potwierd� usuni�cie u�ytkownika',        // the username will be appended to this string
'Delete warning'                        =>        'Uwaga! Usuni�te w�tki i posty nie mog� zosta� przywr�cone. Je�eli nie zaznaczysz tej opcji, to posty i w�tki napisane przez tego u�ytkownika mog� by� usuni�te tylko r�cznie.',
'Delete posts'                                =>        'Usu� posty i w�tki stworzone przez tego u�ytkownika.',
'Delete'                                        =>        'Usu�',                // submit button (confirm user delete)
'User delete redirect'                =>        'U�ytkownik usuni�ty. Przekierowywanie &hellip;',
'Group membership redirect'        =>        'Grupa u�ytkownika zapisana. Przekierowywanie &hellip;',
'Update forums redirect'        =>        'Uprawnienia moderatora zaktualizowane. Przekierowywanie &hellip;',
'Ban redirect'                                =>        'Przekierowywanie &hellip;'

);
