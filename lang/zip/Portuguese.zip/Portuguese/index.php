<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'T�picos',
'Moderators'			=>  'Moderadores',
'Link to'				=>	'Link para',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Board is empty.',
'Newest user'			=>	'Registo mais recente',
'Users online'			=>	'Utilizadores registados online',
'Guests online'			=>	'Convidados online',
'No of users'			=>	'N�mero de utilizadores registados',
'No of topics'			=>	'N�mero de t�picos',
'No of posts'			=>	'N�mero de coment�rios',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Board information',
'Board stats'			=>	'Board statistics',
'User info'				=>	'Informa��o de utilizador'

);
