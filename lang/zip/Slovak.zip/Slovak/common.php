<?php


// Determine what locale to use
switch (PHP_OS)
{
	case 'WINNT':
	case 'WIN32':
		$locale = 'slovak';
		break;

	case 'FreeBSD':
	case 'NetBSD':
	case 'OpenBSD':
		$locale = 'sk_SK.iso-8859-2';
		break;

	default:
		$locale = 'sk_SK';
		break;
}

// Attempt to set the locale
setlocale(LC_CTYPE, $locale);


// Language definitions for frequently used strings
$lang_common = array(

// Text orientation and encoding
'lang_direction'		=>	'ltr',	// ltr (Left-To-Right) or rtl (Right-To-Left)
'lang_encoding'			=>	'windows-1250',
'lang_multibyte'		=>	false,

// Notices
'Bad request'			=>	'Chybn� po�iadavka. Vami po�adovan� odkaz je nespr�vny alebo zastaral�.',
'No view'				=>	'Nem�te opr�vnenie prezara� toto f�rum.',
'No permission'			=>	'Nem�te pr�stup na t�to str�nku.',
'Bad referrer'			=>	'Bad HTTP_REFERER. Boli ste odk�zan� na t�to str�nku z neopr�vnen�ho zdroja. Ak probl�m pretrv�va, pros�m preverte \'Base URL\' �e je spr�vne zadan� v Admin/Options a tie� �i prehliadate f�rum pomocou naviga�n�ch URL. Viac inform�ci� oh�adom overenia vz�ahov/odkazovania m��ete n�js� v dokument�cii PunBB.',

// Topic/forum indicators
'New icon'				=>	'Tu s� nov� pr�spevky',
'Normal icon'			=>	'<!-- -->',
'Closed icon'			=>	'T�ma je uzavret�',
'Redirect icon'			=>	'Presmerovan� f�rum',

// Miscellaneous
'Announcement'			=>	'Ozn�menie',
'Options'				=>	'Nastavenie',
'Actions'				=>	'�innosti',
'Submit'				=>	'Odosla�',	// "name" of submit buttons
'Ban message'			=>	'M�te ban (z�kaz pr�stupu) na toto f�rum.',
'Ban message 2'			=>	'Ban uplynie koncom',
'Ban message 3'			=>	'Administr�tor alebo moder�tor, ktor� v�m dal ban, zanechal nasleduj�cu spr�vu:',
'Ban message 4'			=>	'Ak�ko�vek ot�zky smerujte administr�torovi na',
'Never'					=>	'Nikdy',
'Today'					=>	'Dnes',
'Yesterday'				=>	'V�era',
'Info'					=>	'Info',		// a common table header
'Go back'				=>	'Sp�',
'Maintenance'			=>	'�dr�ba',
'Redirecting'			=>	'Presmerovanie',
'Click redirect'		=>	'Kliknite sem ak nechcete dlh�ie �aka� (alebo pokia� sa prehliada� nepresmeroval)',
'on'					=>	'on',		// as in "BBCode is on"
'off'					=>	'off',
'Invalid e-mail'		=>	'Zadan� emailov� adresa je neplatn�.',
'required field'		=>	'je nutn� vyplni� v tomto formul�ri.',	// for javascript form validation
'Last post'				=>	'Posledn� pr�spevok',
'by'					=>	'od',	// as in last post by someuser
'New posts'				=>	'Nov� pr�spevky',	// the link that leads to the first new post (use &nbsp; for spaces)
'New posts info'		=>	'Zobrazi� prv� nov� pr�spevok v t�me.',	// the popup text for new posts links
'Username'				=>	'U��vate�sk� meno',
'Password'				=>	'Heslo',
'E-mail'				=>	'E-mail',
'Send e-mail'			=>	'Posla� e-mail',
'Moderated by'			=>	'Moderovan�',
'Registered'			=>	'Registrovan�',
'Subject'				=>	'Predmet',
'Message'				=>	'Spr�va',
'Topic'					=>	'T�ma',
'Forum'					=>	'F�rum',
'Posts'					=>	'Pr�spevky',
'Replies'				=>	'Odpovede',
'Author'				=>	'Autor',
'Pages'					=>	'Str�nky',
'BBCode'				=>	'BBCode',	// You probably shouldn't change this
'img tag'				=>	'[img] tag',
'Smilies'				=>	'Smajl�ci',
'and'					=>	'a',
'Image link'			=>	'obr�zok',	// This is displayed (i.e. <image>) instead of images when "Show images" is disabled in the profile
'wrote'					=>	'nap�sal',	// For [quote]'s
'Code'					=>	'Code',		// For [code]'s
'Mailer'				=>	'Odosielate�',	// As in "MyForums Mailer" in the signature of outgoing e-mails
'Important information'	=>	'D�le�it� inform�cie',
'Write message legend'	=>	'Nap� spr�vu a odo�li',

// Title
'Title'					=>	'Titul',
'Member'				=>	'�len',	// Default title
'Moderator'				=>	'Moder�tor',
'Administrator'			=>	'Administr�tor',
'Banned'				=>	'Ban',
'Guest'					=>	'N�v�tevn�k',

// Stuff for include/parser.php
'BBCode error'			=>	'Syntax BBCode v spr�ve je nespr�vna.',
'BBCode error 1'		=>	'Ch�ba za�iato�n� tag pre [/quote].',
'BBCode error 2'		=>	'Ch�ba ukon�ovac� tag pre [code].',
'BBCode error 3'		=>	'Ch�ba za�iato�n� tag pre [/code].',
'BBCode error 4'		=>	'Ch�ba jeden alebo viac ukon�ovac�ch tagov pre [quote].',
'BBCode error 5'		=>	'Ch�ba jeden alebo viac za�iato�n�ch tagov pre [/quote].',

// Stuff for the navigator (top of every page)
'Index'					=>	'Index',
'User list'				=>	'Zoznam u��vate�ov',
'Rules'					=>  'Pravidl�',
'Search'				=>  'H�ada�',
'Register'				=>  'Registrova� sa',
'Login'					=>  'Prihl�si� sa ',
'Not logged in'			=>  'Nie ste prihl�sen�.',
'Profile'				=>	'Profil',
'Logout'				=>	'Odhl�si�',
'Logged in as'			=>	'Naposledy prihl�sen�',
'Admin'					=>	'Administr�cia',
'Last visit'			=>	'Posledn� n�v�teva',
'Show new posts'		=>	'Zobrazi� nov� pr�spevky od poslednej n�v�tevy',
'Mark all as read'		=>	'Ozna�i� v�etky t�my ako pre��tan�',
'Link separator'		=>	'',	// The text that separates links in the navigator

// Stuff for the page footer
'Board footer'			=>	'Z�p�tie',
'Search links'			=>	'H�ada� odkazy',
'Show recent posts'		=>	'Zobrazi� poslend� pr�spevky',
'Show unanswered posts'	=>	'Zobrazi� pr�spevky bez odpoved�',
'Show your posts'		=>	'Zobrazi� moje pr�spevky',
'Show subscriptions'	=>	'Zobrazi� moje sledovan� t�my',
'Jump to'				=>	'Prejs� na',
'Go'					=>	' Prejs� ',		// submit button in forum jump
'Move topic'			=>  'Prenies� t�mu',
'Open topic'			=>  'Otvori� t�mu',
'Close topic'			=>  'Zavrie� t�mu',
'Unstick topic'			=>  'Zru�i� zv�raznenie',
'Stick topic'			=>  'Zv�razni� t�mu',
'Moderate forum'		=>	'Moderova� f�rum',
'Delete posts'			=>	'Zmaza� viacero pr�spevkov',
'Debug table'			=>	'Inform�cie ladenia',

// For extern.php RSS feed
'RSS Desc Active'		=>	'Najakt�vnej�ie t�my v',	// board_title will be appended to this string
'RSS Desc New'			=>	'Najnov�ie t�my v',					// board_title will be appended to this string
'Posted'				=>	'Poslan�'	// The date/time a topic was started

);
