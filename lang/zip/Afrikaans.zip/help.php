<?php

// Language definitions used in help.php
$lang_help = array(

'Help'					=>	'Hulp',
'produces'				=>	'produseer',

'BBCode info 1'				=>	'BBCode is versameling van formaat etikette soort gelyk aan html, en word gebruik om die verandering teks en formaat. Hier volg `n lys BBCodes en wat elke een doen.', 
'BBCode info 2'				=>	'Die beheerders het die keuse om BBCode aan of af te skakel. Jy kan sien of BBCode aan of af geskakel is links van die boodskap.',


'Text style'				=>	'Teks styl',
'Text style info'			=>	'Die volgende etikette kan die aansien van die teks verander:',
'Bold text'				=>	'Vet teks',
'Underlined text'			=>	'Onderstreepte teks',
'Italic text'				=>	'Skuins teks',
'Red text'				=>	'Rooi teks',
'Blue text'				=>	'Blou teks',


'Links and images'			=>	'Skakels en prente',
'Links info'				=>	'Jy kan `n skakel na ander dokumente of na e-mail adresse maak deur die volgende etikette te gebruik:',
'My e-mail address'			=>	'My e-mail adres',
'Images info'				=>	'As jy `n prent wil in sit kan jy die img etiket gebruik.',

'Quotes'				=>	'Aanhaling',
'Quotes info'				=>	'As jy iemand wil aanhaal, gebruik die quote etiket.',
'Quotes info'				=>	'As jy nie `n spesifieke persoon wil aanhaal, kan jy die qoute etiket gebruik sonder om `n naam te verskaf.',
'Quote text'				=>	'Dit is die teks wat ek wil aanhaal.',
'produces quote box'			=>	'Verskaf `n aanhaal box soos die:',


'Code'					=>	'Kode',
'Code info'				=>	'Wanneer jy bronkode wil weergee, moet jy seker maak dat jy die code etiket gebruik. Teks met die code etiket sal monospace gebruik en sal nie deur ander etikette beinvloed word nie.',
'Code text'				=>	'Die is `n stuk kode.',
'produces code box'			=>	'Verskaf `n kode box soos die:',

'Nested tags'				=>	'In geplante etikette',
'Nested tags info'			=>	'BBCode kan ingeplant word om meer gevorderde formate opte maak. By voorbeeld
',
'Bold, underlinded text'		=>	'Vet, geonderstreepte teks',

'Smilies info'				=>	'As jy wil (en as dit toegelaat word), kan die forum sekere smilies in prentjies verander om die smilie voor te stel. Die forum herken die volgende smilies em vervang hul met prente:'

);
