<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Eliminar Coment�rio',
'Warning'				=>	'Aten��o!! Se este � o primeiro coment�rio de um t�pico, todo o t�pico ser� eliminado.',
'Delete'				=>	'Eliminar',	// The submit button
'Post del redirect'		=>	'Coment�rio Eliminado. A redireccionar...',
'Topic del redirect'	=>	'T�pico Eliminado. A redireccionar...'

);
