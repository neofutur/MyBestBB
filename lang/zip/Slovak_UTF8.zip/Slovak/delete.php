<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Zmazať príspevok',
'Warning'				=>	'Pozor! Ak je toto prvý príspevok v téme, celá téma bude vymazaná.',
'Delete'				=>	'Zmazať',	// The submit button
'Post del redirect'		=>	'Príspevok vymazaný. Presmerovávam&hellip;',
'Topic del redirect'	=>	'Téma vymazaná. Presmerovávam&hellip;'

);
