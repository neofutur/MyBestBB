<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Excluir post',
'Warning'				=>	'Aten��o! Se este for o primeiro post do t�pico, todo o t�pico ser� exclu�do.',
'Delete'				=>	'Excluir',	// The submit button
'Post del redirect'		=>	'Post exclu�do. Redirecionando &hellip;',
'Topic del redirect'	=>	'T�pico exclu�do. Redirecionando &hellip;'

);
