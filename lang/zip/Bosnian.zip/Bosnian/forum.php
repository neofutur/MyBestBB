<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Pokrenite novu temu',
'Views'			=>	'pogledano',
'Moved'			=>	'Pomjereno',
'Sticky'		=>	'Ljepljivo',
'Empty forum'	=>	'Forum je prazan.'

);
