<?php

// Language definitions used in various scripts
$lang_misc = array(

'Mark read redirect'		=>	'V�etke t�my a diskusie boli ozna�en� ako pre��tan�. Presmerov�vam &hellip;',

// Send e-mail
'Form e-mail disabled'		=>	'U��vate�, ktor�mu chcete posla� email, m� t�to funkciu vypnut�.',
'No e-mail subject'			=>	'Mus�te zada� predmet.',
'No e-mail message'			=>	'Mus�te nap�sa� spr�vu.',
'Too long e-mail message'	=>	'Spr�vy nem��u by� dlh�ie ako 65535 znakov (64 KB).',
'E-mail sent redirect'		=>	'Email poslan�. Presmerov�vam &hellip;',
'Send e-mail to'			=>	'Posla� email',
'E-mail subject'			=>	'Predmet',
'E-mail message'			=>	'Spr�va',
'E-mail disclosure note'	=>	'Majte na pam�ti, �e pou�it�m tohto formul�ra bude Va�a emailov� adresa pre pr�jemcu vidite�n�.',
'Write e-mail'				=>	'Nap�te a po�lite emailov� spr�vu',

// Report
'No reason'					=>	'Mus�te zada� d�vod.',
'Report redirect'			=>	'Pr�spevok ohl�sen�. Presmerov�vam &hellip;',
'Report post'				=>	'Ozn�mi� pr�spevok',
'Reason'					=>	'D�vod',
'Reason desc'				=>	'Zadajte kr�tky d�vod, pre�o upozor�ujete na tento pr�spevok',

// Subscriptions
'Already subscribed'		=>	'U� ste prihl�sen� k odberu pr�spevkov z tejto t�my.',
'Subscribe redirect'		=>	'Boli ste pridan� k odberu pr�spevkov. Presmerov�vam &hellip;',
'Not subscribed'			=>	'Nieste prihl�sen� k odberu pr�spevkov z tejto t�my.',
'Unsubscribe redirect'		=>	'Odber pr�spevkov bol zru�en�. Presmerov�vam &hellip;',

// General forum and topic moderation
'Moderate'					=>	'Moderova�',
'Select'					=>	'Vybra�',	// the header of a column of checkboxes
'Move'						=>	'Presun��',
'Delete'					=>	'Vymaza�',

// Moderate forum
'Open'						=>	'Otvori�',
'Close'						=>	'Uzavrie�',
'Move topic'				=>	'Presun�� t�mu',
'Move topics'				=>	'Presun�� t�my',
'Move legend'				=>	'Zvo�te cie� presunu',
'Move to'					=>	'Prenies� do',
'Leave redirect'			=>	'Ponecha� presmerovanie t�m(y)',
'Move topic redirect'		=>	'T�ma prenesen�. Presmerov�vam &hellip;',
'Move topics redirect'		=>	'T�my prenesen�. Presmerov�vam &hellip;',
'Confirm delete legend'		=>	'Pros�m potvr�te vymazanie',
'Delete topics'				=>	'Zmaza� t�my',
'Delete topics comply'		=>	'Naozaj chcete vyzmaza� vybran� t�my ?',
'Delete topics redirect'	=>	'T�my zmazan�. Presmerov�vam &hellip;',
'Open topic redirect'		=>	'T�ma otvoren�. Presmerov�vam &hellip;',
'Open topics redirect'		=>	'T�my otvoren�. Presmerov�vam &hellip;',
'Close topic redirect'		=>	'T�ma uzavret�. Presmerov�vam &hellip;',
'Close topics redirect'		=>	'T�my uzavret�. Presmerov�vam &hellip;',
'No topics selected'		=>	'Mus�te vybra� aspo� jednu t�mu na presunutie/vymazanie/otvorenie/uzavretie.',
'Stick topic redirect'		=>	'T�ma zv�raznen�. Presmerov�vam &hellip;',
'Unstick topic redirect'	=>	'Zv�raznenie t�my zru�en�. Presmerov�vam &hellip;',

// Delete multiple posts in topic
'Delete posts'				=>	'Vymaza� pr�spevky',
'Delete posts comply'		=>	'Naozaj chcete vymaza� ozna�en� pr�spevky ?',
'Delete posts redirect'		=>	'Pr�spevky zmazan�. Presmerov�vam &hellip;',
'No posts selected'			=>	'Mus�te vybra� aspo� jeden pr�spevok k zmazaniu.'

);
