<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Postita vastus',
'Topic closed'		=>	'Teema on suletud',
'From'				=>	'Asukoht',				// User location
'Note'				=>	'M�rge',				// Admin note
'Website'			=>	'Veebileht',
'Guest'				=>	'K�laline',
'Online'			=>	'Foorumis',
'Offline'			=>	'Eemal',
'Last edit'			=>	'Viimati muutnud',
'Report'			=>	'Teata',
'Delete'			=>	'Kustuta',
'Edit'				=>	'Muuda',
'Quote'				=>	'Tsiteeri',
'Is subscribed'		=>	'Sa oled tellinud selle teema',
'Unsubscribe'		=>	'T�hista tellimus',
'Subscribe'			=>	'Telli see teema',
'Quick post'		=>	'Kiirvastus',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Moderaatori valikud'

);
