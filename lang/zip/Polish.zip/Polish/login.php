<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'                =>        'Z�y login i/lub has�o.',
'Forgotten pass'                =>        'Zapomnia�e� has�a?',
'Login redirect'                =>        'Zosta�e� poprawnie zalogowany. Przekierowywanie &hellip;',
'Logout redirect'                =>        'Wylogowany. Przekierowywanie &hellip;',
'No e-mail match'                =>        'Brak zarejestrowanego u�ytkownika z tym adresem email',
'Request pass'                        =>        'Popro� o has�o',
'Request pass legend'        =>        'Wpisz adres email kt�ry poda�e� podczas rejestracji',
'Request pass info'                =>        'Nowe has�o razem z linkiem do aktywacji zostanie wys�ane na podany adres.',
'Not registered'                =>        'Niezarejestrowany?',
'Login legend'                        =>        'Poni�ej wpisz login i has�o',
'Login info'                        =>        'Je�eli nie jeste� zarejestrowany lub zapomnia�e� has�o to kliknij w link poni�ej.',

// Forget password mail stuff
'Forget mail'                        =>        'Email zosta� wys�any na podany adres z instrukcjami jak zmieni� has�o. Je�li list nie dotar� prosimy o kontakt z administratorem na'

);
