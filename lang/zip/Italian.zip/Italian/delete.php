<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Cancella messaggio',
'Warning'				=>	'Attenzione! Se questo &egrave; il primo messaggio della discussione, l\'intera discussione sar&agrave; cancellata.',
'Delete'				=>	'Cancella',	// The submit button
'Post del redirect'		=>	'Messaggio cancellato. Reindirizzamento &hellip;',
'Topic del redirect'	=>	'Discussione cancellata. Reindirizzamento &hellip;',

);
