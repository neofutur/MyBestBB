<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Esborra missatge',
'Warning'				=>	'Av�s! Si aquest �s el primer missatge del tema, tot el tema ser� esborrat.',
'Delete'				=>	'Esborra',	// The submit button
'Post del redirect'		=>	'Missatge esborrat. Redirigint &hellip;',
'Topic del redirect'	=>	'Tema esborrat. Redirigint &hellip;'

);
