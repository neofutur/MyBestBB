<?php

// Language definitions used in register.php
$lang_register = array(

// Miscellaneous
'No new regs'                                =>        'Rejestracja na forum zosta�a zablokowana.',
'Reg cancel redirect'                =>        'Rejestracja anulowana. Przekierowywanie &hellip;',
'Forum rules'                                =>        'Zasady Forum',
'Rules legend'                                =>        'Musisz si� zgodzi�, je�li chcesz si� zarejestrowa�',
'Agree'                                                =>        'Zgadzam si�',
'Cancel'                                        =>        'Anuluj',
'Register'                                        =>        'Rejestruj',

// Form validation stuff (some of these are also used in post.php)
'Username censor'                        =>        'Login kt�ry wpisa�e� zawiera jedno lub wi�cej cenzurowanych s��w. Wymy�l inny...',
'Username dupe 1'                        =>        'Kto� ju� zarejestrowa� takiego u�ytkownika',
'Username dupe 2'                        =>        'Login, kt�ry wpisa�e� jest zbyt podobny do innego. Musi si� r�ni� alfanumerycznymi znakami  (a-z lub 0-9). Wybierz inny.',
'E-mail not match'                        =>        'Adresy email nie pasuj� do siebie. Powr�� i je popraw.',

// Registration e-mail stuff
'Reg e-mail'                                =>        'Dzi�kujemy za rejestracj�. Has�o zosta�o wys�ane na podany adres email. Je�eli po jakim� czasie nie dojdzie to skontaktuj si� z administratorem: ',
'Reg complete'                                =>        'Rejestracja zako�czona. Logowanie i przekierowywanie &hellip;',

// Register info
'Desc 1'                                        =>        'Rejestracja pozwala na dost�p do wielu funkcji kt�rych jako go�� nie mo�esz u�ywa�. Funkcje pozwalaj� na edycj� i kasowanie post�w czy zaprojektowanie sygnatury, kt�ra b�dzie wy�wietlana pod ka�dym Twoim postem. Je�eli masz jakie� pytania to powienie� skontaktowa� si� z administratorem tego forum.',
'Desc 2'                                        =>        'Poni�ej znajduje si� formularz, kt�ry nale�y wype�ni� aby si� zarejestrowa�. Po rejestracji i zalogowaniu powiniene� odwiedzi� sw�j profil, aby uzupe�ni� informacje. Pola poni�ej s� jedynie ma�� garstk� ustawie�, ale s� niezb�dne.',
'Username legend'                        =>        'Wpisz login pomi�dzy  2 oraz 25 znakami',
'Pass legend 1'                                =>        'Wpisz i potwierd� wybrane has�o',
'Pass legend 2'                                =>        'Przeczytaj instrukcje poni�ej',
'Pass info'                                        =>        'Has�o mo�e mie� 4 do 16 znak�w. Passwords are case sensitive.',
'E-mail info'                                =>        'Musisz wpisa� poprawny adres email, na kt�ry zostanie wys�ane wygenerowane has�o.',
'Confirm e-mail'                        =>        'Potwierd� adres email',

);
