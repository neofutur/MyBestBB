<?php

// Language definitions used in userlist.php
$lang_ul = array(
 
'User find legend'		=>	'Chercher et trier les utilisateurs',
'User search info'		=>	'Saisissez un nom d\'utilisateur pour rechercher un utilisateur et le trier par groupe d\'utilisateurs. Le champ nom d\'utilisateur peut rester vide. Utilisez le joker * pour des recherches partielles. Triez les utilisateurs par nom, date d\'inscription ou nombre de messages et en ordre croissant ou d�croissant.',
'User group'			=>	'Groupe d\'utilisateurs',
'No of posts'			=>	'Nombre de messages',
'All users'				=>	'Tous les utilisateurs'
 
);