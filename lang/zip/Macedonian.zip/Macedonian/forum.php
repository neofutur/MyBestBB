<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Прати нова порака',
'Views'			=>	'Читања',
'Moved'			=>	'Преместено',
'Sticky'		=>	'Леплива',
'Empty forum'	=>	'Темата е празна.'

);
