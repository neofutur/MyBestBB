<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Topik',
'Moderators'			=>  'Moderator',
'Link to'				=>	'Link ke',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Forum kosong.',
'Newest user'			=>	'Pengguna terbaru',
'Users online'			=>	'Pengguna yang sedang online',
'Guests online'			=>	'Pengunjung yang sedang online',
'No of users'			=>	'Jumlah keseluruhan pengguna',
'No of topics'			=>	'Jumlah keseluruhan topik',
'No of posts'			=>	'Jumlah keseluruhan posting',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informasi forum',
'Board stats'			=>	'Statistik forum',
'User info'				=>	'Informasi pengguna'

);
