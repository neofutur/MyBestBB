<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'กระทู้',
'Moderators'			=>  'ผู้ดูแลฟอรั่ม',
'Link to'				=>	'ลิงค์ไปยัง',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'บอร์ดนี้ว่างเปล่า',
'Newest user'			=>	'สมาชิกใหม่ล่าสุด',
'Users online'			=>	'สมาชิกที่กำลังออนไลน์',
'Guests online'			=>	'ผู้มาเยือนที่กำลังออนไลน์',
'No of users'			=>	'จำนวนสมาชิกทั้งหมด',
'No of topics'			=>	'จำนวนกระทู้ทั้งหมด',
'No of posts'			=>	'จำนวนโพสต์ทั้งหมด',
'Online'				=>	'ออนไลน์',	// As in "Online: User A, User B etc."
'Board info'			=>	'ข้อมูลของเว็บบอร์ด',
'Board stats'			=>	'สถิติของเว็บบอร์ด',
'User info'				=>	'ข้้อมูลผู้ใช้งาน'

);
