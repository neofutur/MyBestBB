<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Ba�l�klar',
'Moderators'			=>  'Denetmenler',
'Link to'				=>	'Ba�lant� adresi',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Bo� pano',
'Newest user'			=>	'En yeni �yemiz',
'Users online'			=>	'Ba�l� kay�tl� kullan�c�lar',
'Guests online'			=>	'Ba�l� misafirler',
'No of users'			=>	'Toplam kay�tl� kullan�c� say�s�',
'No of topics'			=>	'Toplam konu say�s�',
'No of posts'			=>	'Toplam ileti say�s�',
'Online'				=>	'Ba�l�',	// As in "Online: User A, User B etc."
'Board info'			=>	'Pano bilgisi',
'Board stats'			=>	'Pano istatistikleri',
'User info'				=>	'Kullan�c� bilgisi'

);
