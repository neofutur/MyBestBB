<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Napa�no uporabni�ko ime/geslo.',
'Forgotten pass'		=>	'Pozabljeno geslo?',
'Login redirect'		=>	'Prijava je bila uspe�na. Preusmerjanje &hellip;',
'Logout redirect'		=>	'Odjava je bila uspe�na. Preusmerjanje &hellip;',
'No e-mail match'		=>	'Ni uporabnika s tem e-po�tnim naslovom',
'Request pass'			=>	'Zahtevaj geslo',
'Request pass legend'	=>	'Vnesi e-po�tni naslov s katerim si se registriral',
'Request pass info'		=>	'Na tvoj e-po�tni naslov bo poslano geslo in povezava na kateri  se lahko ponovno prijavi�.',
'Not registered'		=>	'�e nisi registriran?',
'Login legend'			=>	'Vnesi uporabni�ko ime in geslo',
'Login info'			=>	'�e �e nisi registriran ali si pozabil geslo klikni na povezavo.',

// Forget password mail stuff
'Forget mail'			=>	'Na tvoj e-po�tni naslov si dobil po�to z navodili kako spremeniti geslo. �e po�te nisi dobil se obrni na administratorja.'

);
