<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Témy',
'Moderators'			=>  'Moderátori',
'Link to'				=>	'Odkaz na',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Fórum je práznde.',
'Newest user'			=>	'Najnovší registrovaný užívateľ',
'Users online'			=>	'Registrovaní užívatelia online',
'Guests online'			=>	'Návštevníkov online',
'No of users'			=>	'Registrovaných užívateľov celkom',
'No of topics'			=>	'Celkový počet tém',
'No of posts'			=>	'Celkový počet príspevkov',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informácie boardu',
'Board stats'			=>	'Štatistika boardu',
'User info'				=>	'Info o užívateľovi'

);
