<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Identifica��o ou Palavra-Passe incorecta.',
'Forgotten pass'		=>	'Esqueceu sua Palavra-Passe?',
'Login redirect'		=>	'Identifica��o Correcta. A redireccionar...',
'Logout redirect'		=>	'A encerrar sess�o. A redireccionar...',
'No e-mail match'		=>	'N�o foi encontrado o utilizador com o correio electr�nico indicado',
'Request pass'			=>	'Recuperar Palavra-Passe',
'Request pass legend'	=>	'Enter the e-mail address with which you registered',
'Request pass info'		=>	'A nova Palavra-Passe juntamente com um link para proceder � sua activa��o ir� ser enviada para o endere�o fornecido.',
'Not registered'		=>	'Ainda n�o fez o seu registo?',
'Login legend'			=>	'Introduza o seu utilizador e Palavra-Passe abaixo',
'Login info'			=>	'Se ainda n�o se registou ou se esqueceu da Palavra-Passe clique no link apropriado abaixo.',

// Forget password mail stuff
'Forget mail'			=>	'Foi lhe enviada uma mensagem para o Correio Electr�nico indicado com as instru��es para recupera��o de sua Palavra-Passe. Caso n�o receba esta mensagem entre em contacto com o Administrador do F�rum'

);
