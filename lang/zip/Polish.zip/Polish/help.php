<?php

// Language definitions used in help.php
$lang_help = array(

'Help'                                        =>        'Pomoc',
'produces'                                =>        'wynik:',

'BBCode info 1'                        =>        'BBCode jest kolekcj� tag�w, kt�r� u�ywa si� do szybkiej zmiany wygl�du post�w. BBCode jest bardzo prosty,  bardzo podobny do HTMLa. Poni�ej jest dost�pny wykaz tag�w BBCode i instrukcje ich u�ytkowania.',
'BBCode info 2'                        =>        'Administratorzy mog� wy��cza� i w��cza� BBCode.  Informacja o BBCode gdy  w��czony lub wy��czony znajduje si� po lewej stronie piszesz lub edytujesz sygnatur�.',

'Text style'                        =>        'Styl tekstu',
'Text style info'                =>        'Nast�puj�ce tagi zmieniaj� wygl�d tekstu:',
'Bold text'                                =>        'Tekst Pogrubiony',
'Underlined text'                =>        'Tekst Podkre�lony',
'Italic text'                        =>        'Kursywa',
'Red text'                                =>        'Czerwony tekst',
'Blue text'                                =>        'Niebieski tekst',

'Links and images'                =>        'Linki i obrazki',
'Links info'                        =>        'Mo�esz tworzy� linki do r�nych dokument�w, serwis�w czy adres�w email u�ywaj�c nast�puj�cych tag�w:',
'My e-mail address'                =>        'M�j adres email',
'Images info'                        =>        'Je�eli chcesz wy�wietli� obrazek w po�cie to u�yj taga img.',

'Quotes'                                =>        'Cytaty',
'Quotes info'                        =>        'Je�eli chcesz kogo� zacytowa�, powiniene� u�y� tagu quote.',
'Quotes info 2'                        =>        'Je�eli nie cytujesz kogo� z forum, mo�esz u�y� tagu quote bez podania u�ytkownika.',
'Quote text'                        =>        'Tekst kt�ry chc� cytowa�.',
'produces quote box'        =>        'Wyniki cytowania:',

'Code'                                        =>        'Kod',
'Code info'                                =>        'Do wy�wietlania kodu �r�d�owego u�ywa si� tagu code. Tekst w nim wyr�nia si� czcionk�, kt�ra jest do tego przystosowana.',
'Code text'                                =>        'To jest kawa�ek kodu.',
'produces code box'                =>        'Wynikiem jest ramka kodu:',

'Nested tags'                        =>        'Z�o�one tagi',
'Nested tags info'                =>        'BBCode mo�na u�y� do tworzenia bardziej z�o�onych rzeczy, na przyk�ad:',
'Bold, underlined text'        =>        'Pogrubiony, podkre�lony tekst',

'Smilies info'                        =>        'Je�eli chcesz i emotikonki s� w��czone, to forum mo�e konwertowa� tekstowe emotikony do obrazk�w. To forum konwertuje nast�puj�ce emotikony:'

);
