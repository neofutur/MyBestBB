<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Temos',
'Moderators'			=>  'Moderatoriai',
'Link to'				=>	'Nuoroda �',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Forumas tu��ias.',
'Newest user'			=>	'Naujausias registruotas vartotojas',
'Users online'			=>	'Prisijungusi� registruot� vartotoj�',
'Guests online'			=>	'Prisijungusi� sve�i�',
'No of users'			=>	'I� viso registruot� vartotoj�',
'No of topics'			=>	'I� viso tem�',
'No of posts'			=>	'I� viso �inu�i�',
'Online'				=>	'Prisijung�',	// As in "Online: User A, User B etc."
'Board info'			=>	'Forumo informacija',
'Board stats'			=>	'Forumo statistikos',
'User info'				=>	'Vartotoj� informacija'

);
