<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'用户搜索和排序',
'User search info'		=>	'输入用户名进行搜索，并且/或者选择用户群组来做分类。用户名一栏可以保留空白，也可以使用通配符 * 来做部分匹配。您可以依照用户名、注册日期，或者帖子发表数来做递增递减等排序浏览。',
'User group'			=>	'用户群组',
'No of posts'			=>	'发表帖子数',
'All users'				=>	'全部用户'

);
