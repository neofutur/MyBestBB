<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'        =>        'Nowy Wątek',
'Views'                        =>        'Wyświetlenia',
'Moved'                        =>        'Przeniesiony',
'Sticky'                =>        'Przyklejony',
'Empty forum'        =>        'Forum jest puste.'

);
