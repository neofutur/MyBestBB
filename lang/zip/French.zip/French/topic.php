<?php

// Language definitions used in viewtopic.php
$lang_topic = array(
 
'Post reply'		=>	'�crire une r�ponse',
'Topic closed'		=>	'Discussion ferm�e',
'From'				=>	'Lieu',				// User location
'Note'				=>	'Note',				// Admin note
'Website'			=>	'Site web',
'Guest'				=>	'Invit�',
'Online'			=>	'En ligne',
'Offline'			=>	'Hors ligne',
'Last edit'			=>	'Derni�re modification par',
'Report'			=>	'Signaler',
'Delete'			=>	'Supprimer',
'Edit'				=>	'Modifier',
'Quote'				=>	'Citer',
'Is subscribed'		=>	'Vous �tes abonn� � cette discussion',
'Unsubscribe'		=>	'D�sabonner',
'Subscribe'			=>	'S\'abonner � cette discussion',
'Quick post'		=>	'R�ponse rapide',
'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Mod�ration'
 
);