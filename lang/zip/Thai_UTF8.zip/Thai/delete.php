<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'ลบโพสต์',
'Warning'				=>	'คำเตือน! ถ้าโพสต์นี้คือโพสต์แรกของกระทุ้ กระทู้นี้้จะหายไปหลังจากทำการลบด้วย',
'Delete'				=>	'ลบ',	// The submit button
'Post del redirect'		=>	'โพสต์ถูกลบแล้ว กำลังเปลี่ยนหน้า &hellip;',
'Topic del redirect'	=>	'กระทู้ถูกลบแล้ว กำลังเปลี่ยนหน้า &hellip;'

);
