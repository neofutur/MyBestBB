<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post' => 'Xóa bài',
'Warning' => 'Cảnh báo! Người dùng bị xoá không thể khôi phục lại được.',
'Delete' => 'Xóa',
'Post del redirect' => 'Bài đã được xóa. Chuyển trang...',
'Topic del redirect' => 'Chủ đề đã được xóa. Chuyển trang...',

);
