<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'&#2488;&#2470;&#2488;&#2509;&#2479; &#2454;&#2497;&#2433;&#2460;&#2497;&#2472; &#2451; &#2488;&#2494;&#2460;&#2494;&#2472;',
'User search info'		=>	'Enter a username to search for and/or a user group to filter by. The username field can be left blank. Use the wildcard character * for partial matches. Sort users by name, date registered or number of posts and in ascending/descending order.',
'User group'			=>	'&#2488;&#2470;&#2488;&#2509;&#2479; &#2486;&#2509;&#2480;&#2503;&#2467;&#2496;',
'No of posts'			=>	'&#2474;&#2507;&#2488;&#2509;&#2463;&#2503;&#2480; &#2488;&#2434;&#2454;&#2509;&#2479;&#2494;',
'All users'				=>	'&#2488;&#2476;&#2494;&#2439;'

);
