<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Sukurti nauj� tem�',
'Views'			=>	'Per�i�ros',
'Moved'			=>	'Perkelta',
'Sticky'		=>	'Svarbu',
'Empty forum'	=>	'Forumas tu��ias.'

);
