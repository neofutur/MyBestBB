<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Изтрива мнение',
'Warning'				=>	'Внимание! Ако това е първото мнение по темата, цялата тема ще бъде изтрита.',
'Delete'				=>	'Изтриване',	// The submit button
'Post del redirect'		=>	'Мнението е изтрито. Пренасочване &hellip;',
'Topic del redirect'	=>	'Темата е изтрита. Пренасочване &hellip;'

);
