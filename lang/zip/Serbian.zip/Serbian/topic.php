<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Upis odgovora',
'Topic closed'		=>	'Tema zatvorena',
'From'				=>	'Iz',				// User location
'Note'				=>	'Obave�tenje',				// Admin note
'Website'			=>	'Web sajt',
'Guest'				=>	'Gost',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Poslednje editovanje od',
'Report'			=>	'Izve�taj',
'Delete'			=>	'Brisanje',
'Edit'				=>	'Izmena',
'Quote'				=>	'Citat',
'Is subscribed'		=>	'Vi ste sada prijavljeni na ovu temu',
'Unsubscribe'		=>	'Odjava',
'Subscribe'			=>	'Prijava na temu',
'Quick post'		=>	'Brzi upis',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Kontrole urednika'

);
