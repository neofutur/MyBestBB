<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Nombre de usuario y/o contrase�a incorrectos.',
'Forgotten pass'		=>	'�Has olvidado la contrase�a?',
'Login redirect'		=>	'Te has conectado con �xito. Redirigiendo &hellip;',
'Logout redirect'		=>	'Has salido. Redirigiendo &hellip;',
'No e-mail match'		=>	'No hay ning�n usuario registrado con este correo electr�nico',
'Request pass'			=>	'Solicita contrase�a',
'Request pass legend'	=>	'Introduce el correo electr�nico con el quieres registrate',
'Request pass info'		=>	'Una nueva contrase�a junto con un enlace para activar la nueva contrase�a ser� enviada a esta direcci�n electr�nica.',
'Not registered'		=>	'�Todav�a no te has registrado?',
'Login legend'			=>	'Introduce tu nombre de usuario y una contrase�a debajo',
'Login info'			=>	'Si no te has registrado o te has olvidado de tu contrase�a haz un click sobre el enlace adecuado que hay debajo.',

// Forget password mail stuff
'Forget mail'			=>	'Se ha enviado un correo a las direcciones especificadas e instrucciones de c�mo cambiar tu contrase�a. Si no lo recibes puedes contactar con el administrador del foro en'

);
