<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Obrisi komentar',
'Warning'				=>	'Upozorenje! Ako je ovo prvi komentar, svi ispod ce biti obrisani.',
'Delete'				=>	'Obrisi',	// The submit button
'Post del redirect'		=>	'Komentar obrisan. Preusmjeravam na &hellip;',
'Topic del redirect'	=>	'Tema obrisana. Preusmjeravam &hellip;'

);
