<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Atsakyti � �inut�',
'Topic closed'		=>	'Tema u�daryta',
'From'				=>	'Nuo',				// User location
'Note'				=>	'�yma',				// Admin note
'Website'			=>	'Tinklapis',
'Guest'				=>	'Sve�ias',
'Online'			=>	'Prisijung�s',
'Offline'			=>	'Neprisijung�s',
'Last edit'			=>	'Paskutinis tais�',
'Report'			=>	'Prane�ti administratoriui',
'Delete'			=>	'Trinti',
'Edit'				=>	'Redaguoti',
'Quote'				=>	'Cituoti',
'Is subscribed'		=>	'J�s u�registravote �i� tem�',
'Unsubscribe'		=>	'Nuimti temos registracij�',
'Subscribe'			=>	'U�registruoti �i� tem�',
'Quick post'		=>	'Greita �inut�',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Moderatoriaus valdymas'

);
