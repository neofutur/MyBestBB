<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Buscar e ordenar usu�rios',
'User search info'		=>	'Entre com um nome de usu�rio para busca e/ou filtre pelo grupo de usu�rios. O campo nome de usu�rio pode ser deixado em branco. Use o caracter * para buscas parciais. Ordene os usu�rios por nome, data de cadastro ou n�mero de posts e em ordem ascendente ou descentente.',
'User group'			=>	'Grupo de usu�rios',
'No of posts'			=>	'N�mero de posts',
'All users'				=>	'Todos'

);
