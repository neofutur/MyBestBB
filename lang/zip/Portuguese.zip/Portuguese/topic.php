<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Responder ao Coment�rio',
'Topic closed'		=>	'T�pico Fechado',
'From'				=>	'De',				// User location
'Note'				=>	'Nota',				// Admin note
'Website'			=>	'Website',
'Guest'				=>	'Convidado',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'�ltimo coment�rio por',
'Report'			=>	'Reportar',
'Delete'			=>	'Apagar',
'Edit'				=>	'Editar',
'Quote'				=>	'Citar',
'Is subscribed'		=>	'Voc� subscreveu este T�pico',
'Unsubscribe'		=>	'Cancelar Subscri��o',
'Subscribe'			=>	'Subscrever',
'Quick post'		=>	'Comentar',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Controlos do moderador'


);
