<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Nepareizs lietot�jv�rds un/vai parole.',
'Forgotten pass'		=>	'Aizmirsi paroli?',
'Login redirect'		=>	'Autoriz�cija veiksm�ga. P�radres�cija &#8230;',
'Logout redirect'		=>	'Tu esi izg�jis no foruma. P�radres�cija &#8230;',
'No e-mail match'		=>	'�eit nav lietot�ja ar ��du e-pasta adresi',
'Request pass'			=>	'Piepras�t paroli',
'Request pass legend'	=>	'Ievadi e-pasta adresi ar kuru esi piere�istr�j�ties',
'Request pass info'		=>	'Uz �o e-pasta adresi ir nos�t�ta jauna parole kop� ar saiti caur kuru �o paroli var aktiviz�t.',
'Not registered'		=>	'V�l neesi piere�istr�jies?',
'Login legend'			=>	'Ievadi lietot�jv�rdu un paroli zem�k',
'Login info'			=>	'Ja tu v�l neesat re�istr�jies vai ar� esi aizmirsis paroli, izv�lies atbilsto�o saiti zem�k.',

// Forget password mail stuff
'Forget mail'			=>	'Uz nor�d�to e-pasta adresi tika nos�t�ta v�stule ar instrukcij�m k� nomain�t tavu paroli. Ja t� nepien�k, tu vari kontakt�ties ar foruma administratoru uz '

);
