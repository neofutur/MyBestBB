<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Radera inl�gg',
'Warning'				=>	'Varning! Om detta �r f�rsta inl�gget i tr�den kommer hela tr�den raderas.',
'Delete'				=>	'Radera',	// The submit button
'Post del redirect'		=>	'Inl�gg raderat. Omdirigerar &hellip;',
'Topic del redirect'	=>	'Tr�d raderad. Omdirigerar &hellip;'

);
