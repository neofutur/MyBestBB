<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  '�r��ir',
'Moderators'			=>  'Umsj�narmenn',
'Link to'				=>	'Link to',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'T�mt spjallbor�',
'Newest user'			=>	'N�jasti skr��i notandinn er',
'Users online'			=>	'Innskr��ir notendur',
'Guests online'			=>	'Gestir',
'No of users'			=>	'Fj�ldi skr��ra notanda',
'No of topics'			=>	'Fj�ldi �r��a',
'No of posts'			=>	'Fj�ldi p�sta',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Uppl�singar um spjallbor�i�',
'Board stats'			=>	'T�lfr��i spjallbor�sins',
'User info'				=>	'Notendauppl�singar'

);
