<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'L�het� uusi aihe',
'Views'		=>	'Luettu',
'Moved'		=>	'Siirretty',
'Sticky'	=>	'Sticky',
'Empty forum'	=>	'Kanavalla ei ole viestej�.'

);
