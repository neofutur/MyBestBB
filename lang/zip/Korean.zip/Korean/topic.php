<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'댓글 달기',
'Topic closed'		=>	'잠긴 이야깃거리',
'From'				=>	'위치',				// User location
'Note'				=>	'관리자 기록',				// Admin note
'Website'			=>	'웹싸이트',
'Guest'				=>	'손님',
'Online'			=>	'들어옴',
'Offline'			=>	'안들어옴',
'Last edit'			=>	'마지막에 고친 사람 (시간) -',
'Report'			=>	'신고',
'Delete'			=>	'지우기',
'Edit'				=>	'고치기',
'Quote'				=>	'따오기',
'Is subscribed'		=>	'현재 이 이야깃러리를 구독하고 계십니다',
'Unsubscribe'		=>	'구독 취소',
'Subscribe'			=>	'이 이야깃거리 구독하기',
'Quick post'		=>	'잽싸게 글 쓰기',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'돌보는 이 관리'

);
