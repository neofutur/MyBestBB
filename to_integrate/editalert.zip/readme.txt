##
##
##        Mod title:  Edit Alert mod
##
##      Mod version:  1.0
##   Works on PunBB:  1.2.11
##     Release date:  2006-04-18
##           Author:  hcs (from punbb.ru), angelsin (board.angelsin.net)
##
##      Description:  zero: sorry for poor eng =)
##      That simply mod send notification to user by email, when his post  
##      was edited by moderator\admin. E-mail message contains board name,
##	link to edited post, topic name (where that post) and
##	moderator's nickname. (eng and rus languages inside)
##      
##      
##   Affected files:  edit.php
##                    
##       Affects DB:  No
##
##            Notes:  None
##
##       DISCLAIMER:  Please note that "mods" are not officially supported by
##                    PunBB. Installation of this modification is done at your
##                    own risk. Backup your forum database and any and all
##                    applicable files before proceeding.
##
##
#
#
#---------[ 1. MAKE BACKUP! ]---------------------------------------------
#
	Copy affected files and save it!.
#
#---------[ 2. UPLOAD ]-----------------------------------------------------
#

	Copy the zip file contents to your PunBB root folder 
	excluding readme.txt ;)

#
#---------[ 3. OPEN ]-----------------------------------------------------
#
	edit.php

#
#---------[ 4. FIND LINE ~39 ]-------------------------------------------
#

p.poster, p.poster_id,

#
#---------[ 5. AFTER ADD ]--------------------------------------------------
#

u.email, u.language, p.id AS pid,

#
#---------[ 6. FINE LINE ~39 ]------------------------------------------------
#

(fp.forum_id=f.id AND fp.group_id='.$pun_user['g_id'].')    

#
#---------[ 7. AFTER ADD ]----------------------------------------------------
#

LEFT JOIN '.$db->prefix.'users AS u ON u.id=p.poster_id 

#
#---------[ 8. FIND LINE ~ 129 ]----------------------------------------------
#

        redirect('viewtopic.php?pid='.$id.'#p'.$id, $lang_post['Edit redirect']);

#
#---------[ 9. BEFORE ADD     ]----------------------------------------------
#

// MOD EDITALERT begin
require PUN_ROOT.'lang/'.$cur_post['language'].'/editalert.php';

if ($is_admmod && $cur_post['poster_id']!=$pun_user['id']) {

        $subject = $lang_editalert['Subj Edit Alert'].' '.$pun_config['o_board_title'];
        $message = $lang_editalert['Message Edit Alert beg'].' '.$pun_config['o_base_url'].'/viewtopic.php?pid='.$cur_post['pid'].'#p'.$cur_post['pid'] .' '.$lang_editalert['Message Edit Alert mid'].' "'.$cur_post['subject'].'" '.$lang_editalert['Message Edit Alert end'].' '.$pun_user['username'].'.';

    // begin send by email        
        $mail_tpl = trim(file_get_contents(PUN_ROOT.'lang/'.$cur_post['language'].'/mail_templates/editalert_email.tpl'));
        $first_crlf = strpos($mail_tpl, "\n");
        $mail_subject = trim(substr($mail_tpl, 8, $first_crlf-8));
        $mail_message = trim(substr($mail_tpl, $first_crlf));
        $mail_subject = str_replace('<mail_subject>', $subject, $mail_subject);
        $mail_message = str_replace('<board_title>', $pun_config['o_board_title'], $mail_message);
        $mail_message = str_replace('<mail_message>', $message, $mail_message);
        $mail_message = str_replace('<board_mailer>', $pun_config['o_board_title'].' '.$lang_common['Mailer'], $mail_message);

        require_once PUN_ROOT.'include/email.php';

        pun_mail($cur_post['email'], $mail_subject, $mail_message);
    // end send by email        
}
// MOD EDITALERT end


#
#---------[ 10. SAVE/UPLOAD ]---------------------------------------------
#


enjoy =)
