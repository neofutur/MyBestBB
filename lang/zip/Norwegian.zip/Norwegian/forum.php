<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Post nytt emne',
'Views'			=>	'Visninger',
'Moved'			=>	'Flyttet',
'Sticky'		=>	'Klistret',
'Empty forum'	=>	'Forumet er tomt.'

);
