<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'发表新主题',
'Views'			=>	'点阅',
'Moved'			=>	'已移动',
'Sticky'		=>	'置顶',
'Empty forum'	=>	'目前没有帖子。'

);
