<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Нова тема',
'Views'			=>	'Прегледа',
'Moved'			=>	'Преместена',
'Sticky'		=>	'Важна',
'Empty forum'	=>	'Форума е празен.'

);
