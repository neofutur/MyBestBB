<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Nome de usuario e/ou contrase�a incorrectos.',
'Forgotten pass'		=>	'�Esqueciches a contrase�a?',
'Login redirect'		=>	'Conect�cheste con �xito. Redirixindo &hellip;',
'Logout redirect'		=>	'Sa�ches. Redirixindo &hellip;',
'No e-mail match'		=>	'Non hai ning�n usuario rexistrado con este correo electr�nico',
'Request pass'			=>	'Solicita contrasinal',
'Request pass legend'	=>	'Introduce o correo electr�nico co queres rexistrarte',
'Request pass info'		=>	'Un novo contrasinal xunto cun enlace para activa-lo novo contrasinal ser� env�ada a esta direcci�n electr�nica.',
'Not registered'		=>	'�A�nda non te rexistraches?',
'Login legend'			=>	'Introduce o teu nome de usuario e un contrasinal debaixo',
'Login info'			=>	'Se non te rexistraches ou esquec�cheste da t�a contrase�a fai un click sobre o enlace adecuado que hai debaixo.',

// Forget password mail stuff
'Forget mail'			=>	'Env�ouse un correo �s direcci�ns especificadas e instruci�ns de como cambia-lo teu contrasinal. Se non o recibe pode contactar co administrador do foro en'

);
