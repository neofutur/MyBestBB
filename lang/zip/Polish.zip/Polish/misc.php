<?php

// Language definitions used in various scripts
$lang_misc = array(

'Mark read redirect'                =>        'Wszystkie w�tki i fora zosta�y oznaczone jako przeczytane. Przekierowywanie &hellip;',

// Send e-mail
'Form e-mail disabled'                =>        'U�ytkownik do kt�rego pr�bujesz wys�a� email zablokowa� opcje wysy�ania.',
'No e-mail subject'                        =>        'Musisz wpisa� temat.',
'No e-mail message'                        =>        'Musisz wpisa� wiadomo��.',
'Too long e-mail message'        =>        'Wiadomo�� nie mo�e mie� wi�cej ni� 65535 znak�w (64 KB).',
'E-mail sent redirect'                =>        'E-mail wys�any. Przekierowywanie &hellip;',
'Send e-mail to'                        =>        'Wy�lij email do',
'E-mail subject'                        =>        'Temat',
'E-mail message'                        =>        'Wiadomo��',
'E-mail disclosure note'        =>        'Pami�taj, �e po u�yciu tej formy adres email b�dzie widoczny dla odbiorcy.',
'Write e-mail'                                =>        'Napisz i wy�lij wiadomo�� email',

// Report
'No reason'                                        =>        'Musisz poda� pow�d.',
'Report redirect'                        =>        'Raport wys�any . Przekierowywanie &hellip;',
'Report post'                                =>        'Raport posta',
'Reason'                                        =>        'Pow�d',
'Reason desc'                                =>        'Napisz kr�tki pow�d, dlaczego wys�a�e� post do raportu',

// Subscriptions
'Already subscribed'                =>        'Ju� subskrybujesz ten w�tek.',
'Subscribe redirect'                =>        'Twoja subskrypcja zosta�a dodana. Przekierowywanie &hellip;',
'Not subscribed'                        =>        'Nie subskrybujesz w�tku.',
'Unsubscribe redirect'                =>        'Twoja subskrypcja zosta�a usuni�ta. Przekierowywanie &hellip;',

// General forum and topic moderation
'Moderate'                                        =>        'Moderuj',
'Select'                                        =>        'Wybierz',        // the header of a column of checkboxes
'Move'                                                =>        'Przenie�',
'Delete'                                        =>        'Usu�',

// Moderate forum
'Open'                                                =>        'Otw�rz',
'Close'                                                =>        'Zamknij',
'Move topic'                                =>        'Przenie� w�tek',
'Move topics'                                =>        'Przenie� w�tki',
'Move legend'                                =>        'Przenie� na forum...',
'Move to'                                        =>        'Przenie� do',
'Leave redirect'                        =>        'Zostaw linki do w�tk�w',
'Move topic redirect'                =>        'W�tek przeniesiony. Przekierowywanie &hellip;',
'Move topics redirect'                =>        'W�tki przeniesione. Przekierowywanie &hellip;',
'Confirm delete legend'                =>        'Potwierd� usuni�cie',
'Delete topics'                                =>        'Usu� w�tki',
'Delete topics comply'                =>        'Na pewno chcesz usun�� te w�tki?',
'Delete topics redirect'        =>        'W�tki usuni�te. Przekierowywanie &hellip;',
'Open topic redirect'                =>        'W�tek otwarty. Przekierowywanie &hellip;',
'Open topics redirect'                =>        'W�tki otwarte. Przekierowywanie &hellip;',
'Close topic redirect'                =>        'W�tek zamkni�ty. Przekierowywanie &hellip;',
'Close topics redirect'                =>        'W�tki zamkni�te. Przekierowywanie &hellip;',
'No topics selected'                =>        'Musisz wybra� minimum jeden w�tek do przeniesienia/usuni�cia/otwarcia/zamkni�cia.',
'Stick topic redirect'                =>        'W�tek przyklejony.Przekierowywanie &hellip;',
'Unstick topic redirect'        =>        'W�tek odklejony. Przekierowywanie &hellip;',

// Delete multiple posts in topic
'Delete posts'                                =>        'Usu� posty',
'Delete posts comply'                =>        'Na pewno chcesz usun�� zaznaczone posty?',
'Delete posts redirect'                =>        'Posty usuni�te. Przekierowywanie &hellip;',
'No posts selected'        		=>	'Musisz wybra� minimum jeden post do usuni�cia.'

);
