<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Brisanje poruke',
'Warning'				=>	'Upozorenje! Ako je ovo prva poruka u temi, cela tema �e biti obrisana.',
'Delete'				=>	'Brisanje',	// The submit button
'Post del redirect'		=>	'Poruka obrisana. Preusmeravanje &hellip;',
'Topic del redirect'	=>	'Tema obrisana. Preusmeravanje &hellip;'

);
