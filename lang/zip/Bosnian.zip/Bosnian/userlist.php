<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Na�i i poredaj korisnike',
'User search info'		=>	'Upi�ite korisni�ko ime za pretragu. Korisni�ko ime obavezno morate upisati, koristite * ukoliko znate djelimi�no korisni�ko ime.',
'User group'			=>	'Korisni�ka grupa',
'No of posts'			=>	'Broj komentara',
'All users'				=>	'Sve'

);
