<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'पोस्ट मिटाएं',
'Warning'			=>	'चेतावनी! यह प्रकरण की प्रथम पोस्ट है, पूरा प्रकरण ही मिट जाएगा।',
'Delete'				=>	'मिटाएं',	// The submit button
'Post del redirect'		=>	'पोस्ट मिटी। अनुप्रेषण &hellip;',
'Topic del redirect'		=>	'प्रकरण मिटा। अनुप्रेषण &hellip;'

);
