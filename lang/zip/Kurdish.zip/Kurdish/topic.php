﻿<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'وه‌ڵام نووسین',
'Topic closed'		=>	'بابه‌ت داخراوه‌',
'From'				=>	'شوێن',				// User location
'Note'				=>	'تێبینی به‌ڕێوه‌به‌ر',				// Admin note
'Website'			=>	'ویبگه‌',
'Guest'				=>	'میوان',
'Online'			=>	'لێره‌یه‌',
'Offline'			=>	'لێره‌ نیه‌',
'Last edit'			=>	'دواترین جار ده‌ستكاری كراوه‌ له‌لایه‌ن',
'Report'			=>	'به‌ڕێوه‌به‌ر ئاگادار كردنه‌وه‌',
'Delete'			=>	'سڕینه‌وه‌',
'Edit'				=>	'ده‌ستكاریكردن',
'Quote'				=>	'دووباره‌',
'Is subscribed'		=>	'تۆ ئێستا له‌ نوێكاریه‌كانی ئه‌م بابه‌ته‌ ئاگادار ده‌كرێیته‌وه‌',
'Unsubscribe'		=>	'ئاگادار نه‌كرێمه‌وه‌',
'Subscribe'			=>	'له‌ نوێكاریه‌كانی ئه‌م په‌یامه‌ ئاگادار بكرێمه‌وه‌',
'Quick post'		=>	'نووسینی خێرا',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'كۆنترۆڵی چاوه‌دێران'

);
