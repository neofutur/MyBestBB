<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Slett post',
'Warning'				=>	'Advarsel! Om dette er den f�rste posten i emnet, vil hele emnet bli slettet.',
'Delete'				=>	'Slett',	// The submit button
'Post del redirect'		=>	'Post slettet. Omdirigerer &hellip;',
'Topic del redirect'	=>	'Emne slettet. Omdirigerer &hellip;'

);
