<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Novo t�pico',
'Views'			=>	'Visualiza��es',
'Moved'			=>	'Movido',
'Sticky'		=>	'Fixo',
'Empty forum'	=>	'O f�rum est� vazio.'

);
