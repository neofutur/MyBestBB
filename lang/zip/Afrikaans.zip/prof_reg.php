<?php

// Language definitions used in both profile.php and register.php
$lang_prof_reg = array(


'E-mail legend'				=>	'Tik `n geldige e-pos adres in',
'E-mail legend 2'			=>	'Tik asb weer jou e-pos in',
'Localisation legend'			=>	'Kies jou land stellings',
'Timezone'				=>	'Tyd sone',
'Timezone info'				=>	'Om te sorg dat die forum, tyd reg wys, moet jy jou tydsone kies.',
'Language'				=>	'Taal',
'Language info'				=>	'Jy kan kies wat se taal jy die forum in wil laat vertoon.',
'E-mail setting info'			=>	'Kies of jou e-pos adres moet sigbaar wees vir ander gebruikers, of nie en of jy ander gebruikers wil toelaat om jou, met gebruik van die forum e-pos te kontak of nie.',
'E-mail setting 1'			=>	'Wys jou e-pos adres.',
'E-mail setting 2'			=>	'Moenie jou e-pos vertoon nie maar laat forum e-pos toe.',
'E-mail setting 3'			=>	'Moenie jou e-pos vertoon nie en moenie forum e-pos toelaat nie.',
'Privacy options legend'		=>	'Verander jou privaatheid opsies',
'Save user/pass'			=>	'Bewaar my gebruikers naam en wagwoord tussen besoeke.',
'Save user/pass info'			=>	'Die opsies beheer of jy outomaties ingelog moet word elke keer as jy hier na toe kom. Aanbeveel.',
'Confirm pass'				=>	'Bevestig wagwoord',


'Username too short'			=>	'Die gebruikersnaam moet tenminste 2 karakters lank wees. Kies `n ander (langer) gebruikersnaam.',
'Username guest'			=>	'Die gebruikers naam Gas is gereserveer. Kies `n ander een.',
'Username IP'				=>	'Gebruikersnaam in die vorm van `n IP adres is nie toe gelaat nie. Kies asb `n ander een.',
'Username reserved chars'		=>	'Gebruikers naam mag nie die karakters   \', " []   bevat nie. Kies asb `n ander gebruikers naam.',
'Username BBCode'			=>	'Gebruikers naam mag nie BBCode etikette bevat nie. kies asb `n ander een.',
'Dupe username'				=>	'Daar is al iemand geregistreer met daar die gebruikers naam. Kies asb `n ander naam.',
'Pass too short'			=>	'Jou wagwoord moet ten minste 4 karakters lank wees. Kies asb `n ander (langer) wagwoord.',
'Pass not match'			=>	'Die wagwoorde verskil. Gaan terug en maak dit reg',
'Banned e-mail'				=>	'Die e-pos wat jy gebruik is verban van die forum.',
'Dupe e-mail'				=>	'Daar is al iemand geregistreer met die gegewe e-pos adres. Kies `n ander e-pos.',
'Sig too long'				=>	'Jou sigi kan nie langer wees as',
'characters'				=>	'karakters',
'Sig too many lines'			=>	'Sigs kan nie meer as',
'lines'					=>	'lyntjies he nie',
'Signature quote/code'			=>	'Die aanhaling en kode BBCode etikette mag nie in sigs gebruik word nie. Gaan asb terug en herstel dit',
'Bad ICQ'				=>	'Jy het `n ongeldige ICQ UIN gegee. Gaan terug en herstel dit.'

);
