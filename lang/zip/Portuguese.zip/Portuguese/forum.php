<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Criar Novo T�pico',
'Views'			=>	'Visitas',
'Moved'			=>	'Movido',
'Sticky'		=>	'Fundido',
'Empty forum'	=>	'O F�rum est� vazio.'

);
