<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Kustuta postitus',
'Warning'				=>	'Hoiatus! Juhul kui see on esimene postitus teemas siis kustutatakse kogu teema.',
'Delete'				=>	'Kustuta',	// The submit button
'Post del redirect'		=>	'Postitus kustutatud. �mbersuunamine &hellip;',
'Topic del redirect'	=>	'Teema kustutatud. �mbersuunamine &hellip;'

);
