<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Obri�i komentar',
'Warning'				=>	'Upozorenje! Ukoliko je ovo prvi komentar u temi, cijela tema �e tako�er biti obrisana.',
'Delete'				=>	'Obri�i',	// The submit button
'Post del redirect'		=>	'Komentar je obrisan. Preusmjeravanje &hellip;',
'Topic del redirect'	=>	'Tema je obrisana. Preusmjeravanje &hellip;'

);
