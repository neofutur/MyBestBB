<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'T�mas',
'Moderators'			=>  'Moderatori',
'Link to'				=>	'Saite uz',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'D�lis ir tuk�s',
'Newest user'			=>	'Jaun�kais re�istr�tais lietot�js ir',
'Users online'			=>	'Re�istr�tie lietot�ji pa�laik forum�',
'Guests online'			=>	'Viesi pa�laik forum�',
'No of users'			=>	'Pavisam re�istr�ti lietot�ji',
'No of topics'			=>	'Pavisam t�mas',
'No of posts'			=>	'Pavisam koment�ri',
'Online'				=>	'Pa�laik forum�',	// As in "Online: User A, User B etc."
'Board info'			=>	'D��a inform�cija',
'Board stats'			=>	'D��a statistika',
'User info'				=>	'Lietot�ja inform�cija'

);
