<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Zoek en sorteer gebruikers',
'User search info'		=>	'Voer een gebruikersnaam in om naar te zoeken en/of selecteer een groep om op te filteren. De gebruikersnaam hoeft niet te worden ingevuld. Gebruik een asterisk(*) voor gedeeltelijke overeenkomst. Het resultaat kan worden gesorteerd op gebruikersnaam, datum van registratie en het aantal bijdragen, in zowel oplopende als aflopende volgorde.',
'User group'			=>	'Groep',
'No of posts'			=>	'Aantal bijdragen',
'All users'				=>	'Alle gebruikers'

);
