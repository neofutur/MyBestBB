<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Pievienot jaunu t�mu',
'Views'			=>	'Las�ts',
'Moved'			=>	'P�rvietots',
'Sticky'		=>	'Piel�m�ts',
'Empty forum'	=>	'Forum� nav t�mu.'

);
