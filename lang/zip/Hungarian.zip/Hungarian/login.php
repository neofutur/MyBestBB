<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Rossz felhaszn�l�n�v �s/vagy jelsz�.',
'Forgotten pass'		=>	'Elfelejtetted a jelszavad?',
'Login redirect'		=>	'Sikeres bel�p�s. �tir�ny�t�s &hellip;',
'Logout redirect'		=>	'Kil�pt�l. �tir�ny�t�s &hellip;',
'No e-mail match'		=>	'Nincs ilyen e-mail c�mmel regisztr�lt felhaszn�l�',
'Request pass'			=>	'Jelsz� k�r�se',
'Request pass legend'	=>	'Add meg az e-mail c�met, amelyet a regisztr�ci�dhoz haszn�lt�l',
'Request pass info'		=>	'Egy �j jelsz� az aktiv�ci�s linkkel el lesz k�ldve a megadott c�mre.',
'Not registered'		=>	'M�g nem regisztr�lt�l?',
'Login legend'			=>	'Add meg a felhaszn�l�neved �s a jelszavad',
'Login info'			=>	'Ha m�g nem regisztr�lt�l vagy elfelejtetted a jelszavad, kattints a megfelel� hivatkoz�sra.',

// Forget password mail stuff
'Forget mail'			=>	'Egy e-mail el lett k�ldve a megadott c�mre az utas�t�sokkal, hogyan v�ltoztasd meg a jelszavad. Ha nem kaptad meg, kapcsolatba l�phetsz a f�rum adminisztr�torral: '

);
