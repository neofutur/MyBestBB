<?php

// Language definitions used by the Private Message System-mod
$lang_pms = array(
	// Common
	'Messages'			=>		'Poruke',
	'Message'			=>		'Poruka',
	'Save message'		=>		'Snimi poruku',
	'Send'				=>		'Posalji',

	// Messages
	'Inbox'				=>		'Pretinac ulazne poste',
	'Outbox'				=>		'Pretinac poslanih poruka',
	'Box0'				=>		'Otvori slanje',
	'Box1'				=>		'Otvori pretinac',
	'Action'				=>		'Akcija',
	'Reply'				=>		'Proslijedi',
	'Delete'				=>		'Obrisi',
	'Quote'				=>		'Citiraj',
	'Date'				=>		'Datum',
	'Status'				=>		'Status poruka:',
	'Subject'			=>		'Naslov',
	'Sender'				=>		'Posiljatelj',
	'Receiver'			=>		'Primatelj',
	'Private Messages'=> 	'Privatne poruke',
	'New message'		=>		'Posalji novu poruku',
	'Multidelete'		=>		'Obrisi vise poruka',
	'Delete messages comply'	=> 'Da li si siguran/na da �eli� obrisati oznacene poruke?',
	'Deleted redirect'			=> 'Poruke obrisane. Preusmjeravam ...',
	'Read redirect'				=> 'Sve poruke su oznacene kao procitane. Preusmjeravam...',
	'Mark all'			=>		'Oznaci sve poruke kao procitane',

	// Viewtopic
	'PM'					=>		'PP',

	// Profile
	'Quick message'	=> 	'Posalji privatnu poruku',
	'Show smilies'		=>		'Prikazi emocije',

	// Send or delete message
	'Send to'			=> 	'Posalji za',
	'Send a message'	=>		'Posalji poruku',
	'Delete message'	=>		'Obrisi poruku',
	'Del redirect'		=>		'Poruka obrisana, preusmjeravam...',
	'Sent redirect'	=>		'Poruka poslana korisniku, preusmjeravam...',

	// Errors and messages
	'No messages'		=>		'Nema poruka',
	'New messages'		=>		'Imas novu poruku',
	'No user'			=>		'Ne postoji korisnik s tim imenom',
	'Full inbox'		=>		'Vas pretinac je pun!',
	'Inbox full'		=>		'Korisnicki pretinac pun, nemoguce poslati poruku korisniku.',
	'Sent full'			=>		'Ne mozete snimiti poruku, Vas pretinac je pun.',
	'Flood start'		=>		'Posljednje',
	'Flood end'			=>		'Pricekajte trenutak.'
);
