<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'				=>	'Bydrae verwyder',
'Warning'				=>	'Waarskuwing! As dit die eerste bydrae van die onderwerp is, dan word die hele onderwerp uitgewis.',
'Delete'				=>	'Verwyder',
'Post del redirect'			=>	'Bydrae is verwyder. Besig met nastuuring &hellip;',
'Topic del redirect'			=>	'Onderwerp is verwyder. Besig met nastuuring &hellip;'

);
