<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Teme',
'Moderators'			=>  'Ure�uje',
'Link to'				=>	'Vodi na',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Forum je trenutno prazan.',
'Newest user'			=>	'Najnoviji �lan',
'Users online'			=>	'Prisutni korisnici',
'Guests online'			=>	'Prisutni gosti',
'No of users'			=>	'Ukupno registrovanih korisnika',
'No of topics'			=>	'Ukupan broj tema',
'No of posts'			=>	'Ukupan broj komentara',
'Online'				=>	'Trenutno prisutni',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informacije foruma',
'Board stats'			=>	'Statistike',
'User info'				=>	'Informacije korisnika'

);
