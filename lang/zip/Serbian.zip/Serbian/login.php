<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Lo�e korisni�ko ime i/ili lozinka.',
'Forgotten pass'		=>	'Zaboravili ste Va�u lozinku?',
'Login redirect'		=>	'Prijavljivanje uspe�no zavr�eno. Preusmeravanje &hellip;',
'Logout redirect'		=>	'Odjavljivanje. Preusmeravanje &hellip;',
'No e-mail match'		=>	'Nema korisnika registrovanog sa tom e-mail adresom',
'Request pass'			=>	'Zahteva se lozinka',
'Request pass legend'	=>	'Unesite e-mail adresu sa kojom ste registrovani',
'Request pass info'		=>	'Nova lozinka zajedno sa linkom za aktivaciju nove lozinke �e biti poslat na tu adresu.',
'Not registered'		=>	'Niste registrovani jo�?',
'Login legend'			=>	'Unesite korisni�ko ime i lozinku ispod',
'Login info'			=>	'Ako niste registrovani ili ste zaboravili Va�u lozinku kliknite na odgovaraju�i link ispod.',

// Forget password mail stuff
'Forget mail'			=>	'e-mail je poslat na specificiranu adresu sa instrukcijama kako da promenite Va�u lozinku. Ako ga ne dobijete uskoro mo�ete kontaktirati forum administratora na.'

);
