<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Svar vi� p�sti',
'Topic closed'		=>	'�r��i loka�',
'From'				=>	'Fr�',				// User location
'Note'				=>	'Ath.',				// Admin note
'Website'			=>	'Vefs��a',
'Guest'				=>	'Gestur',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'S��ast breytt af',
'Report'			=>	'Tilkynna',
'Delete'			=>	'Ey�a',
'Edit'				=>	'Breyta',
'Quote'				=>	'Tilvitnun',
'Is subscribed'		=>	'�� ert � �skrift a� �essum �r��i',
'Unsubscribe'		=>	'Afpanta �skrift',
'Subscribe'			=>	'Skr� �ennan �r�� � �skrift',
'Quick post'		=>	'Fl�tip�stur',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Stj�rnt�ki umsj�narmanns'

);
