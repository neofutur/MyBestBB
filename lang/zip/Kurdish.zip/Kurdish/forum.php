﻿<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'په‌یامێكی نوێ بنووسه‌',
'Views'			=>	'جاری بینراو',
'Moved'			=>	'گوێزراوه‌ته‌وه‌',
'Sticky'		=>	'ئاگاداری',
'Empty forum'	=>	'مه‌كۆ به‌تاڵه‌.'

);
