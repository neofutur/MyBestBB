<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'नए प्रकरण पोस्ट करें',
'Views'		=>	'देखे गए',
'Moved'	=>	'हट गए',
'Sticky'		=>	'घोषणात्मक',
'Empty forum'	=>	'फोरम खाली है'

);
