<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'			=>	'जवाब पोस्ट करें',
'Topic closed'			=>	'प्रकरण बंद ',
'From'				=>	'से',				// User location
'Note'				=>	'नोट',				// Admin note
'Website'			=>	'वैबसाइट',
'Guest'				=>	'आगंतुक',
'Online'				=>	'ऑनलाइन',
'Offline'				=>	'ऑफलाइन',
'Last edit'			=>	'अंतिम संपादक',
'Report'			=>	'रिपोर्ट',
'Delete'				=>	'मिटाएं',
'Edit'				=>	'संपादन',
'Quote'				=>	'उद्धरित करें',
'Is subscribed'			=>	'आप इस विषय के साथ फिलहाल अधिसूचित हैं',
'Unsubscribe'			=>	'विषय के साथ अधिसूचित होना समाप्त',
'Subscribe'			=>	'इस विषय के साथ अधिसूचित होवें',
'Quick post'			=>	'त्वरित पोस्ट',

'Link separator'		=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'			=>	'नियामक नियंत्रण'
 
);
