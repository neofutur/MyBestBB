<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Cevap yaz',
'Topic closed'		=>	'Ba�l�k kapand�',
'From'				=>	'G�nderen',				// User location
'Note'				=>	'Not',				// Admin note
'Website'			=>	'Websitesi',
'Guest'				=>	'Misafir',
'Online'			=>	'Ba�l�',
'Offline'			=>	'Ba�l� de�il',
'Last edit'			=>	'Son olarak d�zenleyen',
'Report'			=>	'Rapor',
'Delete'			=>	'Sil',
'Edit'				=>	'D�zenle',
'Quote'				=>	'Al�nt� yap',
'Is subscribed'		=>	'Bu ba�l��a �yesiniz',
'Unsubscribe'		=>	'�yelikten ��k',
'Subscribe'			=>	'Bu konuya �ye ol',
'Quick post'		=>	'H�zl� cevap',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Denetmen kontrolleri'

);
