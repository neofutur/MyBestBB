<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  	'प्रकरण',
'Moderators'			=>  	'नियामक',
'Link to'				=>	'यह है लिंक',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'बोर्ड खाली है',
'Newest user'			=>	'नवीनतम पंजीकृत प्रयोक्ता',
'Users online'			=>	'ऑनलाइन पंजीकृत प्रयोक्ता',
'Guests online'			=>	'ऑनलाइन आगंतुक',
'No of users'			=>	'पंजीकृत प्रयोक्ताओं की संख्या',
'No of topics'			=>	'प्रकरणों की कुल संख्या',
'No of posts'			=>	'पोस्टों की कुल संख्या',
'Online'				=>	'ऑनलाइन',	// As in "Online: User A, User B etc."
'Board info'			=>	'बोर्ड संबंधी सूचना',
'Board stats'			=>	'बोर्ड सांख्यिकी',
'User info'			=>	'प्रयोक्ता सूचना'
 
);
