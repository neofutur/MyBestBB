<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Leia ning j�rjesta kasutajaid',
'User search info'		=>	'Sisesta kasutajanimi ja -grupp keda otsida. Kasutajanime v�li v�ib j��da t�hjaks. V�imalik on kasutada t�rni * osaliseks kattuvuseks.',
'User group'			=>	'Kasutajagrupp',
'No of posts'			=>	'Postituste hulk',
'All users'				=>	'K�ik'

);
