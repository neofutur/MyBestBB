<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'T�picos',
'Moderators'			=>  'Moderadores',
'Link to'				=>	'Link para',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'O f�rum est� vazio.',
'Newest user'			=>	'�ltimo usu�rio cadastrado',
'Users online'			=>	'Usu�rios cadastrados online',
'Guests online'			=>	'Visitantes online',
'No of users'			=>	'N�mero total de usu�rios cadastrados',
'No of topics'			=>	'N�mero total de t�picos',
'No of posts'			=>	'N�mero total de posts',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informa��es do f�rum',
'Board stats'			=>	'Estat�sticas do f�rum',
'User info'				=>	'Informa��es do usu�rio'

);
