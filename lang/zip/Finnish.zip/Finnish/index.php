<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'		=>      'Aiheet',
'Moderators'		=>      'Moderaattorit',
'Link to'		=>	'Linkki',	// As in "Link to http://www.punbb.org/"
'Empty board'		=>	'Foorumi on tyhj�',
'Newest user'		=>	'Viimeisin rekister�itynyt k�ytt�j�',
'Users online'		=>	'J�seni� linjalla',
'Guests online'		=>	'Muita k�ytt�ji�',
'No of users'		=>	'Rekister�ityneit� j�seni� yhteens�',
'No of topics'		=>	'Otsikoita',
'No of posts'		=>	'Viestej� yhteens�',
'Online'		=>	'Linjoilla',	// As in "Online: User A, User B etc."
'Board info'		=>	'Tietoja t�st� forumista',
'Board stats'		=>	'Tilastoja',
'User info'		=>	'K�ytt�j�n tiedot'

);
