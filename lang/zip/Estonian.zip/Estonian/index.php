<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Teemad',
'Moderators'			=>  'Moderaatorid',
'Link to'				=>	'Viide',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Foorum on t�hi.',
'Newest user'			=>	'Uusim kasutaja',
'Users online'			=>	'Registreeritud kasutajaid lehel',
'Guests online'			=>	'K�lalisi lehel',
'No of users'			=>	'Kokku registreeritud kasutajat',
'No of topics'			=>	'Kokku teemasid',
'No of posts'			=>	'Kokku postitusi',
'Online'				=>	'Lehel',	// As in "Online: User A, User B etc."
'Board info'			=>	'Foorumi info',
'Board stats'			=>	'Foorumi statistika',
'User info'				=>	'Kasutaja info'

);
