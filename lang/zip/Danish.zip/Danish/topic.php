<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Besvar indl�g',
'Topic closed'		=>	'Emnet er lukket',
'From'				=>	'Fra',				// User location
'Note'				=>	'Note',				// Admin note
'Website'			=>	'Website',
'Guest'				=>	'G�st',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Sidst �ndret af',
'Report'			=>	'Rapport�r',
'Delete'			=>	'Slet',
'Edit'				=>	'Ret',
'Quote'				=>	'Cit�r',
'Is subscribed'		=>	'Du abonnerer p� dette emne',
'Unsubscribe'		=>	'Anull�r abonnement',
'Subscribe'			=>	'Abonn�r p� dette emne',
'Quick post'		=>	'Hurtigindl�g',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Moderator kontroller'

);
