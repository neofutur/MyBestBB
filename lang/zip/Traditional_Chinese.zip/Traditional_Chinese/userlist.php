<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'會員搜尋和排序',
'User search info'		=>	'輸入會員名稱來做搜尋或者選擇會員群組來做分類。會員名稱一欄可以保留空白，也可以使用萬用字元 * 來做部分比對。您可以依照會員名稱、註冊日期，或者文章張貼數來做遞增遞減等排序瀏覽。',
'User group'			=>	'會員群組',
'No of posts'			=>	'發表文章數',
'All users'				=>	'全部會員'

);
