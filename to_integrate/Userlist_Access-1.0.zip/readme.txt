##
##
##        Mod title:  Userlist Access
##
##      Mod version:  1.0
##   Works on PunBB:  1.2.10
##     Release date:  2005-11-16
##           Author:  Atis Lezdins (atis@best.eu.org)
##
##      Description:  This mod allows to forbid seeing userlist and profiles
##                    for certain groups.
##
##   Affected files:  userlist.php
##                    profile.php
##                    admin_groups.php
##                    include/functions.php
##
##       Affects DB:  Yes
##
##            Notes:  This mod allows to forbid certaing group to see the
##                    user lists and profiles. As well - the 'user list'
##                    is hidden from main menu if unaccessible
##                    This is my first mod, so i might miss something, but it
##                    works for me right now ;-)
##                    Also there are .diff files included in this package
##                    and you are encouraged to use them instead of step-by-step
##                    changing of files.
##
##       DISCLAIMER:  Please note that "mods" are not officially supported by
##                    PunBB. Installation of this modification is done at your
##                    own risk. Backup your forum database and any and all
##                    applicable files before proceeding.
##
##


#
#---------[ 1. UPLOAD ]-------------------------------------------------------
#

install_mod.php to /


#
#---------[ 2. RUN ]----------------------------------------------------------
#

install_mod.php


#
#---------[ 3. DELETE ]-------------------------------------------------------
#

install_mod.php


#
#---------[ 4. OPEN ]---------------------------------------------------------
#

include/functions.php


#
#---------[ 5. FIND (line: 242) ]---------------------------------------------
#

       $links[] = '<li id="navuserlist"><a href="userlist.php">'.$lang_common['User list'].'</a>';


#
#---------[ 6. REPLACE WITH ]-------------------------------------------------
#

         if ($pun_user['g_view_users'] == '1')
                 $links[] = '<li id="navuserlist"><a href="userlist.php">'.$lang_common['User list'].'</a>';


#
#---------[ 7. OPEN ]---------------------------------------------------------
#

admin_groups.php


#
#---------[ 8. FIND (line: 157) ]---------------------------------------------
#

            <tr>
                <th scope="row">Search user list</th>
                <td>
                    <input type="radio" name="search_users" value="1"<?php if ($group['g_search_users'] == '1') echo ' checked="checked"' ?> tabindex="21" />&nbsp;<strong>Yes</strong>&nbsp;&nbsp;&nbsp;<input type="radio" name="search_users" value="0"<?php if ($group['g_search_users'] == '0') echo ' checked="checked"' ?> tabindex="22" />&nbsp;<strong>No</strong>
                    <?php if ($group['g_search_users'] == '0') echo ' checked="checked"' ?> tabindex="22" />&nbsp;<strong>No</strong>
                    <span>Allow users in this group to freetext search for users in the user list.</span>
                </td>
            </tr>


#
#---------[ 9. BEFORE, ADD ]---------------------------------------------------
#

            <tr>
                <th scope="row">View user list</th>
 		<td>
                    <input type="radio" name="view_users" value="1"<?php if ($group['g_view_users'] == '1') echo ' checked="checked"' ?> tabindex="21" />&nbsp;<strong>Yes</strong>&nbsp;&nbsp;&nbsp;<input type="radio" name="view_users" value="0"<?php if ($group['g_view_users'] == '0') echo ' checked="checked"' ?> tabindex="22" />&nbsp;<strong>No</strong>
 		    <span>Allow users in this group to see the user list.</span>
 		</td>
 	    </tr>


#
#---------[ 10. FIND (line: 227) ]--------------------------------------------
#

	$search_users = isset($_POST['search_users']) ? intval($_POST['search_users']) : '1';


#
#---------[ 11. BEFORE, ADD ]-------------------------------------------------
#

 	$view_users = isset($_POST['view_users']) ? intval($_POST['view_users']) : '1';


#
#---------[ 12. FIND (line: 243) ]--------------------------------------------
#

	$db->query('INSERT INTO '.$db->prefix.'groups (g_title, g_user_title, g_read_board, g_post_replies, g_post_topics, g_edit_posts, g_delete_posts, g_delete_topics, g_set_title, g_search, g_search_users, g_edit_subjects_interval, g_post_flood, g_search_flood) VALUES(\''.$db->escape($title).'\', '.$user_title.', '.$read_board.', '.$post_replies.', '.$post_topics.', '.$edit_posts.', '.$delete_posts.', '.$delete_topics.', '.$set_title.', '.$search.', '.$search_users.', '.$edit_subjects_interval.', '.$post_flood.', '.$search_flood.')') or error('Unable to add group', __FILE__, __LINE__, $db->error());


#
#---------[ 13. REPLACE ]-----------------------------------------------------
#

	$db->query('INSERT INTO '.$db->prefix.'groups (g_title, g_user_title, g_read_board, g_post_replies, g_post_topics, g_edit_posts, g_delete_posts, g_delete_topics, g_set_title, g_search, g_view_users, g_search_users, g_edit_subjects_interval, g_post_flood, g_search_flood) VALUES(\''.$db->escape($title).'\', '.$user_title.', '.$read_board.', '.$post_replies.', '.$post_topics.', '.$edit_posts.', '.$delete_posts.', '.$delete_topics.', '.$set_title.', '.$search.', '.$view_users.', '.$search_users.', '.$edit_subjects_interval.', '.$post_flood.', '.$search_flood.')') or error('Unable to add group', __FILE__, __LINE__, $db->error());

        
#
#---------[ 14. FIND (line: 257) ]--------------------------------------------
#

	$db->query('UPDATE '.$db->prefix.'groups SET g_title=\''.$db->escape($title).'\', g_user_title='.$user_title.', g_read_board='.$read_board.', g_post_replies='.$post_replies.', g_post_topics='.$post_topics.', g_edit_posts='.$edit_posts.', g_delete_posts='.$delete_posts.', g_delete_topics='.$delete_topics.', g_set_title='.$set_title.', g_search='.$search.', g_search_users='.$search_users.', g_edit_subjects_interval='.$edit_subjects_interval.', g_post_flood='.$post_flood.', g_search_flood='.$search_flood.' WHERE g_id='.intval($_POST['group_id'])) or error('Unable to update group', __FILE__, __LINE__, $db->error());


#
#---------[ 15. REPLACE ]-----------------------------------------------------
#

	$db->query('UPDATE '.$db->prefix.'groups SET g_title=\''.$db->escape($title).'\', g_user_title='.$user_title.', g_read_board='.$read_board.', g_post_replies='.$post_replies.', g_post_topics='.$post_topics.', g_edit_posts='.$edit_posts.', g_delete_posts='.$delete_posts.', g_delete_topics='.$delete_topics.', g_set_title='.$set_title.', g_search='.$search.', g_view_users='.$view_users.', g_search_users='.$search_users.', g_edit_subjects_interval='.$edit_subjects_interval.', g_post_flood='.$post_flood.', g_search_flood='.$search_flood.' WHERE g_id='.intval($_POST['group_id'])) or error('Unable to update group', __FILE__, __LINE__, $db->error());


#
#---------[ 16. OPEN ]--------------------------------------------------------
#

userlist.php


#
#---------[ 17. FIND (line: 30) ]---------------------------------------------
#

 if ($pun_user['g_read_board'] == '0')


#
#---------[ 18. REPLACE WITH ]------------------------------------------------
#

 if ($pun_user['g_read_board'] == '0' || $pun_user['g_view_users'] == '0')


#
#---------[ 19. OPEN ]--------------------------------------------------------
#

profile.php


#
#---------[ 20. FIND (line: 36) ]---------------------------------------------
#

 if ($pun_user['g_read_board'] == '0' && ($action != 'change_pass' || !isset($_GET['key'])))


#
#---------[ 21. REPLACE WITH ]------------------------------------------------
#

 if (($pun_user['g_read_board'] == '0' || ($pun_user['g_view_users'] == 0 && $pun_user['id'] != $id)) && ($action != 'change_pass' || !isset($_GET['key'])))

        
#
#---------[ 16. SAVE/UPLOAD ]-------------------------------------------------
#


