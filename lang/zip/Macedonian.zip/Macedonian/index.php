<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Теми',
'Moderators'			=>  'Модератори',
'Link to'				=>	'Линк до',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Форумот е празен.',
'Newest user'			=>	'Најнов корисник',
'Users online'			=>	'Регистрирани кориснци online',
'Guests online'			=>	'Гости online',
'No of users'			=>	'Вкупно регистрирани корисници',
'No of topics'			=>	'Вкупно теми',
'No of posts'			=>	'Вкупно пораки',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Информации за форумот',
'Board stats'			=>	'Статистика за форумот',
'User info'				=>	'Информации за корисникот'

);
