﻿<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'په‌یام بسڕه‌وه‌',
'Warning'				=>	'ئاگاداری، ئه‌گه‌ر ئه‌مه‌ یه‌كه‌مین په‌یامی بابه‌ته‌، ئه‌وا په‌یامه‌كانی دیكه‌ش ده‌سڕێنه‌وه‌',
'Delete'				=>	'سڕینه‌وه‌',	// The submit button
'Post del redirect'		=>	'په‌یام سڕایه‌وه‌، ده‌برێیته‌وه‌ &hellip;',
'Topic del redirect'	=>	'بابه‌ت سڕایه‌وه‌، ده‌برێیته‌وه‌ &hellip;'

);
