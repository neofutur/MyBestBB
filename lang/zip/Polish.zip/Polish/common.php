<?php


// Determine what locale to use
switch (PHP_OS)
{
        case 'WINNT':
        case 'WIN32':
                $locale = 'polish';
                break;

        case 'FreeBSD':
        case 'NetBSD':
        case 'OpenBSD':
                $locale = 'pl_PL.ISO8859-2';
                break;

        default:
                $locale = 'pl_PL';
                break;
}

// Attempt to set the locale
setlocale(LC_CTYPE, $locale);


// Language definitions for frequently used strings
$lang_common = array(

// Text orientation and encoding
'lang_direction'                =>        'ltr',        // ltr (Left-To-Right) or rtl (Right-To-Left)
'lang_encoding'                        =>        'iso-8859-2',
'lang_multibyte'                =>        false,

// Notices
'Bad request'                        =>        'Z�e zapytanie. Link kt�ry poda�e� jest niepoprawny lub nieaktualny.',
'No view'                                =>        'Brak pozwolenia na przegl�danie tego forum.',
'No permission'                        =>        'Brak pozwolenia na dost�p do tej strony.',
'Bad referrer'                        =>        'Z�e HTTP_REFERER. Pr�bowa�e� si� dosta� do tej strony z nieznanego �r�d�a. Je�li problem nadal istnieje to upewnij si�, �e \'Base URL\'  jest poprawnie ustawiona w Admin/Opcje. Wszelkie problemy s� opisane w dokumentacji punBB.',

// Topic/forum indicators
'New icon'                                =>        'Nowe posty',
'Normal icon'                        =>        '<!-- -->',
'Closed icon'                        =>        'Ten w�tek jest zamkni�ty',
'Redirect icon'                        =>        'Przekierowane forum',

// Miscellaneous
'Announcement'                        =>        'Og�oszenie',
'Options'                                =>        'Opcje',
'Actions'                                =>        'Akcje',
'Submit'                                =>        'Potwierd�',        // "name" of submit buttons
'Ban message'                        =>        'Zosta�e� zbanowany na tym forum',
'Ban message 2'                        =>        'Ban wygasa',
'Ban message 3'                        =>        'Administrator lub moderator zostawi�, nast�puj�c� wiadomo��:',
'Ban message 4'                        =>        'Prosz� kierowa� wszelkie pytania do administratora na',
'Never'                                        =>        'Nigdy',
'Today'                                        =>        'Dzisiaj',
'Yesterday'                                =>        'Wczoraj',
'Info'                                        =>        'Info',                // a common table header
'Go back'                                =>        'Powr�t',
'Maintenance'                        =>        'Remont',
'Redirecting'                        =>        'Przekierowywanie',
'Click redirect'                =>        'Kliknij tutaj je�eli nie chcesz d�u�ej czeka� (lub przegl�darka nie obs�uguje przekierowywania)',
'on'                                        =>        'w��czone',                // as in "BBCode is on"
'off'                                        =>        'wy��czone',
'Invalid e-mail'                =>        'Adres email kt�ry poda�e� jest niepoprawny.',
'required field'                =>        'jest obowi�zkowym polem.',        // for javascript form validation
'Last post'                                =>        'Ostatni post',
'by'                                        =>        'przez',        // as in last post by someuser
'New posts'                                =>        'Nowe&nbsp;posty',        // the link that leads to the first new post (use &nbsp; for spaces)
'New posts info'                =>        'Id� do pierwszego nowego posta w tym w�tku.',        // the popup text for new posts links
'Username'                                =>        'Login',
'Password'                                =>        'Has�o',
'E-mail'                                =>        'E-mail',
'Send e-mail'                        =>        'Wy�lij e-mail',
'Moderated by'                        =>        'Moderowane przez',
'Registered'                        =>        'Zarejestrowany',
'Subject'                                =>        'Temat',
'Message'                                =>        'Wiadomo��',
'Topic'                                        =>        'W�tek',
'Forum'                                        =>        'Forum',
'Posts'                                        =>        'Posty',
'Replies'                                =>        'Odpowiedzi',
'Author'                                =>        'Autor',
'Pages'                                        =>        'Strony',
'BBCode'                                =>        'BBCode',        // You probably shouldn't change this
'img tag'                                =>        'tag [img]',
'Smilies'                                =>        'Emoty',
'and'                                        =>        'i',
'Image link'                        =>        'obrazek',        // This is displayed (i.e. <image>) instead of images when "Show images" is disabled in the profile
'wrote'                                        =>        'napisa�',        // For [quote]'s
'Code'                                        =>        'Kod',                // For [code]'s
'Mailer'                                =>        'Mailer',        // As in "MyForums Mailer" in the signature of outgoing e-mails
'Important information'        =>        'wa�na informacja',
'Write message legend'        =>        'Napisz nowego posta',

// Title
'Title'                                        =>        'Tytu�',
'Member'                                =>        'U�ytkownik',        // Default title
'Moderator'                                =>        'Moderator',
'Administrator'                        =>        'Administrator',
'Banned'                                =>        'Zbanowany',
'Guest'                                        =>        'Go��',

// Stuff for include/parser.php
'BBCode error'                        =>        'Sk�adnia BBCode w wiadomo�ci jest b��dna.',
'BBCode error 1'                =>        'Brakuj�cy tag startowy dla [/quote].',
'BBCode error 2'                =>        'Brakuj�cy tag ko�cowy dla [code].',
'BBCode error 3'                =>        'Brakuj�cy tag startowy dla  [/code].',
'BBCode error 4'                =>        'Brakuje jednego lub wi�cej ko�cowych tag�w dla [quote].',
'BBCode error 5'                =>        'Brakuje jednego lub wi�cej startowych tag�w dla [/quote].',

// Stuff for the navigator (top of every page)
'Index'                                        =>        'Index',
'User list'                                =>        'Lista u�ytkownik�w',
'Rules'                                        =>  'Zasady',
'Search'                                =>  'Szukaj',
'Register'                                =>  'Rejestracja',
'Login'                                        =>  'Logowanie',
'Not logged in'                        =>  'Nie jeste� zalogowany.',
'Profile'                                =>        'Profil',
'Logout'                                =>        'Wyloguj',
'Logged in as'                        =>        'Zalogowany jako',
'Admin'                                        =>        'Administracja',
'Last visit'                        =>        'Ostatnia wizyta',
'Show new posts'                =>        'Poka� nowe posty od ostatniej wizyty',
'Mark all as read'                =>        'Oznacz nowe posty jako przeczytane',
'Link separator'                =>        '',        // The text that separates links in the navigator

// Stuff for the page footer
'Board footer'                        =>        'Stopka forum',
'Search links'                        =>        'Linki szukania',
'Show recent posts'                =>        'Poka� nowe posty',
'Show unanswered posts'        =>        'Poka� w�tki bez odpowiedzi',
'Show your posts'                =>        'Poka� Twoje posty',
'Show subscriptions'        =>        'Poka� Twoje subskrybowane w�tki',
'Jump to'                                =>        'Skocz do',
'Go'                                        =>        ' Id� ',                // submit button in forum jump
'Move topic'                        =>  'Przenie� w�tek',
'Open topic'                        =>  'Otw�rz w�tek',
'Close topic'                        =>  'Zamknij w�tek',
'Unstick topic'                        =>  'Odklej w�tek',
'Stick topic'                        =>  'Przyklej w�tek',
'Moderate forum'                =>        'Moderuj forum',
'Delete posts'                        =>        'Usu� posty',
'Debug table'                        =>        'Informacje debugowania',

// For extern.php RSS feed
'RSS Desc Active'                =>        'Ostatnio najbardziej aktywne w�tki na',        // board_title will be appended to this string
'RSS Desc New'                        =>        'Najnowsze w�tki na',                                        // board_title will be appended to this string
'Posted'                                =>        'Napisany'        // The date/time a topic was started

);
