<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Témata',
'Moderators'			=>  'Moderátoři',
'Link to'				=>	'Odkaz na',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Fórum je prázdné',
'Newest user'			=>	'Nejnovější registrovaný uživatel',
'Users online'			=>	'Registrovaní uživatelé online',
'Guests online'			=>	'Hosté online',
'No of users'			=>	'Celkem registrovaných uživatelů',
'No of topics'			=>	'Témat',
'No of posts'			=>	'Příspěvků',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informace o fóru',
'Board stats'			=>	'Statistika fóra',
'User info'				=>	'Informace o uživateli'

);
