<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Temas',
'Moderators'			=>  'Moderadores',
'Link to'				=>	'Enlace a',	// As in "Link to http://www.punbb.org/"
'Empty board'		=>	'O foro est� baleiro.',
'Newest user'			=>	'Ultimo usuario rexistrado',
'Users online'			=>	'Usuarios rexistrados conectados',
'Guests online'			=>	'Convidados conectados',
'No of users'			=>	'N�mero total de usuarios rexistrados',
'No of topics'			=>	'N�mero total de temas',
'No of posts'			=>	'N�mero total de mensaxes',
'Online'				=>	'Conectados',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informaci�n do foro - Traducido � galego por egalego.com',
'Board stats'			=>	'Estat�sticas do foro - Traducido � galego por egalego.com',
'User info'				=>	'Informaci�n do usuario'

);
