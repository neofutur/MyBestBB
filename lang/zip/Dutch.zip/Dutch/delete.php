<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Bijdrage verwijderen',
'Warning'				=>	'Waarschuwing! Als dit de eerste bijdrage aan het onderwerp is, dan wordt het gehele onderwerp verwijderd.',
'Delete'				=>	'Verwijderen',	// The submit button
'Post del redirect'		=>	'Bijdrage is verwijderd. Bezig met omleiden &hellip;',
'Topic del redirect'	=>	'Onderwerp is verwijderd. Bezig met omleiden &hellip;'

);
