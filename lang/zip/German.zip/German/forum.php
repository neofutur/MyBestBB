<?php

// SPRACHDEFINITIONEN DIE IN "viewforum.php" GEBRAUCHT WERDEN
$lang_forum = array(

'Post topic'	=>	'Neues Thema',
'Views'			=>	'Aufrufe',
'Moved'			=>	'Verschoben',
'Sticky'		=>	'Fixiert',
'Empty forum'	=>	'Das Forum ist leer.'

);
