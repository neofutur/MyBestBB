<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Soek en sorteer gebruikers',
'User search info'		=>	'Tik `n gebruikersnaam in om na te soek en/of kies `n groep om te gebruik as `n filter. Die gebruikersnaam hoef nie ingevul tewees nie. Gebruik `n asterisk(*) as `n wildcard. Die resultate kan gesorteer word op gebruikers naame, datum van registrasie en die aantal bydrae in stygende of dalende volgorde.',
'User group'			=>	'Gebruiker groep',
'No of posts'			=>	'Aantal Bydrae',
'All users'			=>	'Alle gebruikers'

);
