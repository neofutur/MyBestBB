<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Nespr�vne u��vate�sk� meno alebo heslo.',
'Forgotten pass'		=>	'Zabudli ste heslo ?',
'Login redirect'		=>	'Prihl�senie bolo �spe�n�. Presmerov�vam &hellip;',
'Logout redirect'		=>	'Boli ste odhl�sen�. Presmerov�vam &hellip;',
'No e-mail match'		=>	'�iadny registrovan� u��vate� s touto emailovou adresou',
'Request pass'			=>	'Vy�iada� si heslo',
'Request pass legend'	=>	'Vlo�te emailov� adresu, s ktorou ste sa registrovali',
'Request pass info'		=>	'Nov� heslo spolu s odkazom na aktiv�ciu nov�ho hesla bud� poslan� na zadan� emailov� adresu.',
'Not registered'		=>	'Nieste e�te zaregistrovan�(�) ?',
'Login legend'			=>	'Zadajte va�e u��vate�sk� meno a heslo',
'Login info'			=>	'Pokia� nieste zaregistorvan�(�) alebo ste zabudli heslo kliknite ni��ie na vhodn� odkaz.',

// Forget password mail stuff
'Forget mail'			=>	'Na zaslan� email boli odoslan� in�trukcie, ako zmeni� va�e heslo. Ak V�m �iaden email nepri�iel, kontaktujte administr�tora na'

);
