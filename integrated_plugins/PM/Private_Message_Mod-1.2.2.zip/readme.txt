##
##
##        Mod title:  Private Messaging System (PMS)
##
##      Mod version:  1.2.2
##   Works on PunBB:  1.2.x
##     Release date:  2005-10-05
##           Author:  Connorhd (connorhd@mypunbb.com)
##  Original Author:  David 'Chacmool' Djurb�ck (chacmool@spray.se)
##
##      Description:  Private Messaging System for PunBB
##
##   Affected files:  viewtopic.php
##                    footer.php
##                    header.php
##                    include/functions.php
##                    profile.php
##
##       Affects DB:  New table:
##                       'messages'
##                    New options:
##                       'o_pms_enabled'
##                       'o_pms_mess_per_page'
##                    New permissions:
##                       'g_pm'
##                       'g_pm_limit'
##
##
##        Upgrading:  Do not use this readme, follow readme-upgrade.txt
##
##
##       DISCLAIMER:  Please note that "mods" are not officially supported by
##                    PunBB. Installation of this modification is done at your
##                    own risk. Backup your forum database and any and all
##                    applicable files before proceeding.
##
##


#
#---------[ 1. UPLOAD ]-------------------------------------------------------
#

install_mod.php to /

files/*.* to /

files/plugins/AP_Private_messaging.php to /plugins/AP_Private_messaging.php

files/include/pms/*.* to /include/pms/

files/lang/English/pms.php to /lang/English/pms.php


(Note: you can download other languages from punres)

#
#---------[ 2. RUN ]----------------------------------------------------------
#

install_mod.php

#
#---------[ 3. DELETE ]-------------------------------------------------------
#

install_mod.php

#
#---------[ 4. OPEN ]---------------------------------------------------------
#

footer.php

#
#---------[ 5. FIND (line: 47) ]---------------------------------------------
#

$footer_style = isset($footer_style) ? $footer_style : NULL;

#
#---------[ 6. AFTER, ADD ]---------------------------------------------------
#

require(PUN_ROOT.'include/pms/footer_links.php');

#
#---------[ 7. OPEN ]---------------------------------------------------------
#

header.php

#
#---------[ 8. FIND (line: 171) ]-------------------------------------------------
#

	if (in_array(basename($_SERVER['PHP_SELF']), array('index.php', 'search.php')))
		$tpl_temp .= "\n\t\t\t".'</ul>'."\n\t\t\t".'<ul class="conr">'."\n\t\t\t\t".'<li><a href="search.php?action=show_new">'.$lang_common['Show new posts'].'</a></li>'."\n\t\t\t\t".'<li><a href="misc.php?action=markread">'.$lang_common['Mark all as read'].'</a></li>'."\n\t\t\t".'</ul>'."\n\t\t\t".'<div class="clearer"></div>'."\n\t\t".'</div>';

#
#---------[ 9. BEFORE, ADD ]---------------------------------------------------
#

	require(PUN_ROOT.'include/pms/header_new_messages.php');
	
#
#---------[ 10. OPEN ]---------------------------------------------------------
#

include/functions.php

#
#---------[ 11. FIND (line: 250) ]-------------------------------------------------
#

		if ($pun_user['g_id'] > PUN_MOD)
		{
			if ($pun_user['g_search'] == '1')
				$links[] = '<li id="navsearch"><a href="search.php">'.$lang_common['Search'].'</a>';

			$links[] = '<li id="navprofile"><a href="profile.php?id='.$pun_user['id'].'">'.$lang_common['Profile'].'</a>';
			$links[] = '<li id="navlogout"><a href="login.php?action=out&amp;id='.$pun_user['id'].'">'.$lang_common['Logout'].'</a>';
		}
		else
		{
			$links[] = '<li id="navsearch"><a href="search.php">'.$lang_common['Search'].'</a>';
			$links[] = '<li id="navprofile"><a href="profile.php?id='.$pun_user['id'].'">'.$lang_common['Profile'].'</a>';
			$links[] = '<li id="navadmin"><a href="admin_index.php">'.$lang_common['Admin'].'</a>';
			$links[] = '<li id="navlogout"><a href="login.php?action=out&amp;id='.$pun_user['id'].'">'.$lang_common['Logout'].'</a>';
		}
	
#
#---------[ 12. REPLACE WITH ]---------------------------------------------------------
#

		if ($pun_user['g_id'] > PUN_MOD)
		{
			if ($pun_user['g_search'] == '1')
				$links[] = '<li id="navsearch"><a href="search.php">'.$lang_common['Search'].'</a>';

			$links[] = '<li id="navprofile"><a href="profile.php?id='.$pun_user['id'].'">'.$lang_common['Profile'].'</a>';
			require(PUN_ROOT.'include/pms/functions_navlinks.php');
			$links[] = '<li id="navlogout"><a href="login.php?action=out&amp;id='.$pun_user['id'].'">'.$lang_common['Logout'].'</a>';
		}
		else
		{
			$links[] = '<li id="navsearch"><a href="search.php">'.$lang_common['Search'].'</a>';
			$links[] = '<li id="navprofile"><a href="profile.php?id='.$pun_user['id'].'">'.$lang_common['Profile'].'</a>';
			$links[] = '<li id="navadmin"><a href="admin_index.php">'.$lang_common['Admin'].'</a>';
			require(PUN_ROOT.'include/pms/functions_navlinks.php');
			$links[] = '<li id="navlogout"><a href="login.php?action=out&amp;id='.$pun_user['id'].'">'.$lang_common['Logout'].'</a>';
		}

#
#---------[ 13. OPEN ]---------------------------------------------------------
#

profile.php

#
#---------[ 14. FIND (line: 586) ]-------------------------------------------------
#

		$db->query('DELETE FROM '.$db->prefix.'users WHERE id='.$id) or error('Unable to delete user', __FILE__, __LINE__, $db->error());

#
#---------[ 15. AFTER, ADD ]---------------------------------------------------
#

		require(PUN_ROOT.'include/pms/profile_delete.php');
		
#
#---------[ 16. FIND (line: 974) ]-------------------------------------------------
#

							<dt><?php echo $lang_common['E-mail'] ?>: </dt>
							<dd><?php echo $email_field ?></dd>
							
#
#---------[ 17. AFTER, ADD ]---------------------------------------------------
#

							<?php require(PUN_ROOT.'include/pms/profile_send.php'); ?>

#
#---------[ 18. FIND (line: 1050) ]-------------------------------------------------
#

							$email_field = '<label><strong>'.$lang_common['E-mail'].'</strong><br /><input type="text" name="req_email" value="'.$user['email'].'" size="40" maxlength="50" /><br /></label><p><a href="misc.php?email='.$id.'">'.$lang_common['Send e-mail'].'</a></p>'."\n";

#
#---------[ 19. AFTER, ADD ]---------------------------------------------------
#

			require PUN_ROOT.'lang/'.$pun_user['language'].'/pms.php';
			$email_field .= '<p><a href="message_send.php?id='.$id.'">'.$lang_pms['Quick message'].'</a></p>'."\n";

#
#---------[ 20. OPEN ]---------------------------------------------------------
#

viewtopic.php
		
#
#---------[ 21. FIND (line: 240) ]-------------------------------------------------
#

			else if ($cur_post['email_setting'] == '1' && !$pun_user['is_guest'])
				$user_contacts[] = '<a href="misc.php?email='.$cur_post['poster_id'].'">'.$lang_common['E-mail'].'</a>';
							
#
#---------[ 22. AFTER, ADD ]---------------------------------------------------
#										

			require(PUN_ROOT.'include/pms/viewtopic_PM-link.php');

#
#---------[ 23. SAVE/UPLOAD ]-------------------------------------------------
#