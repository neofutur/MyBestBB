<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Discussioni',
'Moderators'			=>  'Moderatori',
'Link to'				=>	'Link a',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Forum vuoto.',
'Newest user'			=>	'Ultimo utente registrato',
'Users online'			=>	'Utenti registrati in linea',
'Guests online'			=>	'Ospiti in linea',
'No of users'			=>	'Numero totale di utenti registrati',
'No of topics'			=>	'Numero totale di discussioni',
'No of posts'			=>	'Numero totale di messaggi',
'Online'				=>	'In linea',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informazioni sul forum',
'Board stats'			=>	'Statistiche del forum',
'User info'				=>	'Informazioni utente'

);
