<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Zmaza� pr�spevok',
'Warning'				=>	'Pozor! Ak je toto prv� pr�spevok v t�me, cel� t�ma bude vymazan�.',
'Delete'				=>	'Zmaza�',	// The submit button
'Post del redirect'		=>	'Pr�spevok vymazan�. Presmerov�vam &hellip;',
'Topic del redirect'	=>	'T�ma vymazan�. Presmerov�vam &hellip;'

);
