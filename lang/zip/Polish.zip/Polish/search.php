<?php

// Language definitions used in search.php
$lang_search = array(

// The search form
'User search'                                =>        'Szukaj u�ytkownika',
'No search permission'                =>        'Brak zezwolenia na u�ywanie wyszukiwania.',
'Search'                                        =>        'Szukaj',
'Search criteria legend'        =>        'Wybierz kryteria szukania',
'Search info'                                =>        'Szukaj�c s�owa kluczowe wpisz te kt�re Ci� interesuj�. Oddziel je przecinkami. Szukaj�c autora, kt�rego posty chcesz czyta� wpisz jego login. U�ywaj znaku * dla wy�wietlenia mniej szczeg�owych wynik�w.',
'Keyword search'                        =>        'Szukaj s�owa kluczowe',
'Author search'                                =>        'Szukaj autora',
'Search in legend'                        =>        'Wybierz forum do przeszukania',
'Search in info'                        =>        'Wybierz kt�re forum chcia�by� przeszuka�, a tak�e parametr szukania (tekst wiadomo�ci, nazw� tematu lub obydwa)',
'Forum search'                                =>        'Forum',
'All forums'                                =>        'Wszystkie fora',
'Search in'                                        =>        'Szukaj w',
'Message and subject'                =>        'Tre�� postu i temat w�tku',
'Message only'                                =>        'Tylko tre�� postu',
'Topic only'                                =>        'Tylko temat w�tku',
'Sort by'                                        =>        'Sortuj przez',
'Sort order'                                =>        'Kolejno�� sortowania',
'Search results legend'                =>        'Wybierz jak wy�wietla� wyniki szukania',
'Search results info'                =>        'Mo�esz sobie wybra� jak sortowa� i pokazywa� wyniki.',
'Sort by post time'                        =>        'Data Napisania',
'Sort by author'                        =>        'Autor',
'Sort by subject'                        =>        'Temat',
'Sort by forum'                                =>        'Forum',
'Ascending'                                        =>        'Rosn�co',
'Descending'                                =>        'Malej�co',
'Show as'                                        =>        'Poka� wyniki jako',
'Show as topics'                        =>        'W�tki',
'Show as posts'                                =>        'Posty',

// Results
'Search results'                        =>        'Wyniki szukania',
'No terms'                                        =>        'Musisz wpisa� minimum jedno s�owo kluczow�, lub nazw� autora.',
'No hits'                                        =>        'Brak wynik�w dla tego szukania.',
'No user posts'                                =>        'Brak post�w napisanych przez tego u�ytkownika.',
'No subscriptions'                        =>        'Aktualnie nie subskrybujesz w�tk�w.',
'No new posts'                                =>        'Brak w�tk�w z nowymi postami od ostatniej wizyty.',
'No recent posts'                        =>        'Brak nowych post�w napisanych pomi�dzy ostatnimi 24 godzinami.',
'No unanswered'                                =>	'Brak w�tk�w, na kt�re nie odpowiedzono.',
'Go to post'				=>	'Id� do postu'

);
