<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Відповісти',
'Topic closed'		=>	'Тема закрита',
'From'				=>	'Звідки',				// User location
'Note'				=>	'Примітка',				// Admin note
'Website'			=>	'Вебсайт',
'Guest'				=>	'Гість',
'Online'			=>	'На форумі',
'Offline'			=>	'Поза форумом',
'Last edit'			=>	'Відредаговано',
'Report'			=>	'Повідомити модератору',
'Delete'			=>	'Знищити',
'Edit'				=>	'Редагувати',
'Quote'				=>	'Цитувати',
'Is subscribed'		=>	'Ви підписані на цю тему',
'Unsubscribe'		=>	'Відписатись',
'Subscribe'			=>	'Підписатись і відслідковувати тему',
'Quick post'		=>	'Швидка відповідь',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Контролюється модератором'

);
