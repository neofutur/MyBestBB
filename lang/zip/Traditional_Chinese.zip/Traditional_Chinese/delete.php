<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'刪除文章',
'Warning'				=>	'警告！如果這是本主題的第一篇文章，整個主題都會被刪除！',
'Delete'				=>	'刪除',	// The submit button
'Post del redirect'		=>	'文章已刪除。載入中 &hellip;',
'Topic del redirect'	=>	'主題已刪除。載入中 &hellip;'

);
