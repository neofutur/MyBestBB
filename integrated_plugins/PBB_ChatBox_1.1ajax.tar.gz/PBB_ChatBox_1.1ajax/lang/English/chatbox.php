<?php

// Language definitions used in chatbox.php
$lang_chatbox = array(

'Page_title'		=>	'ChatBox',
'Chatbox'				=>	'ChatBox',
'Posts'         =>	' ChatBox Posts',
'Sending'				=>	'Sending...',

'No Read Permission'				=>	'You have not permission to read ChatBox.',
'No Post Permission'				=>	'You have not permission to post in ChatBox.',
'No Message'                =>	'No message in ChatBox.',

'Message'         =>	'Message',
'Btn Send'				=>	'Send',
'Btn Refresh'			=>	'Refresh',

'Error No message'				=>	'You must enter a message.',
'Error Too long message'  =>	'Your message is too long.',

);
