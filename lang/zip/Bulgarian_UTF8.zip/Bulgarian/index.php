<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Теми',
'Moderators'			=>  'Модератори',
'Link to'				=>	'Връзка към',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Форума е празен.',
'Newest user'			=>	'Последно регистриран потребител',
'Users online'			=>	'Регистрирани потребители на линия',
'Guests online'			=>	'Гости на линия',
'No of users'			=>	'Общ брой регистрирани членове',
'No of topics'			=>	'Общ брой теми',
'No of posts'			=>	'Общ брой мнения',
'Online'				=>	'На линия',	// As in "Online: User A, User B etc."
'Board info'			=>	'Информация за форума',
'Board stats'			=>	'Статистики за форума',
'User info'				=>	'Потребителска информация'

);
