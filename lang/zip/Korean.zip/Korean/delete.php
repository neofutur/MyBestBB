<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'글 지우기',
'Warning'				=>	'주의! 만약 이 글이 이야깃거리의 처음 글이라면, 아래에 달린 댓글들도 같이 지워지게 됩니다',
'Delete'				=>	'지우기',	// The submit button
'Post del redirect'		=>	'글이 지워졌습니다. 되돌아감 &hellip;',
'Topic del redirect'	=>	'이야깃거리가 지워졌습니다. 되돌아감 &hellip;'

);
