<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'投稿の削除',
'Warning'				=>	'警告! 削除しようとしている投稿がトピック内で最初の投稿の場合、トピックすべてが削除されます。',
'Delete'				=>	'削除',	// The submit button
'Post del redirect'		=>	'投稿が削除されました。リダイレクト中 ...',
'Topic del redirect'	=>	'トピックが削除されました。リダイレクト中 ...'

);
