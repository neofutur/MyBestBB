<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Založiť novú tému',
'Views'			=>	'Zobrazené',
'Moved'			=>	'Presunuté',
'Sticky'		=>	'Zvýraznené',
'Empty forum'	=>	'Fórum je prázdne.'

);
