<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Finde und sortiere Mitglieder',
'User search info'		=>	'Geben Sie einen Mitgliedsnamen und/oder eine Mitgliedergruppe ein nach der gefiltert werden soll. Der Mitgliedsname kann leer bleiben. Benutzen Sie Wildcards (*), um allgemeiner zu suchen. Sortieren Sie die Mitglieder nach Namen, Registrierungsdatum oder Anzahl von Beitr&auml;gen auf-/absteigend.',
'User group'			=>	'Mitgliedergruppe',
'No of posts'			=>	'Anzahl der Beitr&auml;ge',
'All users'				=>	'Alle'

);
