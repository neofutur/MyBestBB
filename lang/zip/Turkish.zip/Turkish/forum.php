<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Yeni konu',
'Views'			=>	'G�r�n�m',
'Moved'			=>	'Ta��nd�',
'Sticky'		=>	'Sabit Konu',
'Empty forum'	=>	'Bo� Forum'

);
