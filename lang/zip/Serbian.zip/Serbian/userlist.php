<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Prona�i i sortiraj �lanove',
'User search info'		=>	'Unesi neko korisni�ko ime za tra�enje i /ili korisni�ku grupu za filtriranje. Polje za korisni�ko ime mo�e biti prazno. Koristite karakter * za delove. Sortirajte �lanove po imenu, datumu registrovanja ili po broju poruka u opadaju�em ili rastu�em redosledu.',
'User group'			=>	'Korisni�ka grupa',
'No of posts'			=>	'Broj poruka',
'All users'				=>	'Sve'

);
