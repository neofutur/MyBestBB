<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Trazi korisnika',
'User search info'		=>	'Upisite ima korisnika ili grupe za pretragu. Obavezno unesite korisnicko ime, polje ne moze ostati prazno.',
'User group'			=>	'Korisnicka grupa',
'No of posts'			=>	'Broj komentara',
'All users'				=>	'Svi'

);
