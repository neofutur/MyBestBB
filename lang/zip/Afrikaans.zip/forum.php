<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'		=>	'Begin `n nuwe onderwerp',
'Views'			=>	'Gelees',
'Moved'			=>	'Geskuif',
'Sticky'		=>	'Gesticky',
'Empty forum'		=>	'Die forum is leeg.'

);
