<?php
/***********************************************************************

  Caleb Champlin (med_mediator@hotmail.com)

************************************************************************/

// Language definitions used in viewforum.php
$lang_polls = array(
'Poll'					=>	'Anketa',
'New poll'				=>	'Vytvořit novou anketu',
'New poll legend multiselect'	=>	'Zadejte informace o anketě (Vícevýběrová anketa)',
'New poll legend yesno'		=>	'Zadejte informace o anketě (Vícevýběrová ano/ne anketa)',
'New poll legend'			=>	'Zadejte informace o anketě',
'Multiselect'			=>	'Vícevýběrová anketa',
'Yesno'					=>	'Vícevýběrová ano/ne anketa',
'Regular'				=>	'Normální anketa',
'Question'				=>	'Otázka',
'Option'				=>	'Možnost',
'Optional'				=>	'(Volitelné)',
'Yes'					=>	'Možnost ano (pravda/souhlasím/apod.)',
'Null vote'				=>	'Prázdný hlas',
'Poll preview'			=>	'Náhled ankety',
'No'					=>	'Možnost ne (lež/nesouhlasím/apod.)',
'Create new poll' 		=> 	'Vytvořit novou anketu',
'Poll select'			=>	'Vyberte typ ankety',
'Already voted'			=>	'V této anketě jste už hlasoval',
'Vote success'			=>	'Váš hlas byl započítán',
'Empty option'			=>	'Anketa má prázdnou možnost.',
'No options'			=>	'Ankety musí obsahovat možnosti.',
'Low options'			=>	'Ankety musí obsahovat 2 nebo více možností.',
'No question'			=>	'Ankety musí mít otázku.',
'Too long question'		=>	'Otázka nesmí být delší než 70 znaků.',
'No yes'				=>	'Tato anketa musí obsahovat možnost Ano.',
'Too long yes'			=>	'Možnost Ano nesmí být delší než 35 znaků.',
'No no'					=>	'Tato anketa musí obsahovat možnost Ne.',
'Too long no'			=>	'Možnost Ne nesmí být delší než 35 znaků.',
'No message'			=>	'Musíte zadat zprávu.',
'Too long message'		=>	'Příspěvky nesmí být delší než 65535 znaků (64 KB).'
);
