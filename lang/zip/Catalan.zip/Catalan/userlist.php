<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Troba i ordena usuaris',
'User search info'		=>	'Introdu�u un nom d\'usuari per a buscar, i/o un grup d\'usuaris per a filtrar la cerca. El camp Nom d\'usuari es pot deixar en blanc. Useu el car�cter asterisc * per a coincid�ncies parcials. Ordena els usuaris per nom, data de registre o nombre de missatges i en ordre ascendent/descendent.',
'User group'			=>	'Grup d\'Usuaris',
'No of posts'			=>	'No. de missatges',
'All users'				=>	'Tots'

);
