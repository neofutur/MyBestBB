<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'새로운 이야깃거리 쓰기',
'Views'			=>	'읽은 횟수',
'Moved'			=>	'옮겨짐',
'Sticky'		=>	'매달음',
'Empty forum'	=>	'포럼이 비어 있습니다.'

);
