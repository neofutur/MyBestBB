<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Почати нову тему',
'Views'			=>	'Переглядів',
'Moved'			=>	'Перенесена',
'Sticky'		=>	'Прикріплена',
'Empty forum'	=>	'Форум порожній.'

);
