<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'                =>        'Odpowied�',
'Topic closed'                =>        'W�tek Zamkni�ty',
'From'                                =>        'Od',                                // User location
'Note'                                =>        'Notka',                                // Admin note
'Website'                        =>        'Serwis',
'Guest'                                =>        'Go��',
'Online'                        =>        'Online',
'Offline'                        =>        'Offline',
'Last edit'                        =>        'Ostatnio edytowany przez',
'Report'                        =>        'Raportuj',
'Delete'                        =>        'Usu�',
'Edit'                                =>        'Edytuj',
'Quote'                                =>        'Cytuj',
'Is subscribed'                =>        'Aktualnie subskrybujesz ten w�tek',
'Unsubscribe'                =>        'Zaniechaj subskrypcji',
'Subscribe'                        =>        'Subskrypcja tego w�tku',
'Quick post'                =>        'Szybka odpowied�',

'Link separator'        =>        ' | ',        // The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'                =>	'Opcje Moderatora'

);
