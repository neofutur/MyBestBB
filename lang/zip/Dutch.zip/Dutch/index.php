<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Onderwerpen',
'Moderators'			=>  'Moderators',
'Link to'				=>	'Ga naar',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Het bulletin board is leeg.',
'Newest user'			=>	'Meest recent geregistreerde gebruiker',
'Users online'			=>	'Geregistreerde gebruikers online',
'Guests online'			=>	'Gasten online',
'No of users'			=>	'Totaal aantal geregistreerde gebruikers',
'No of topics'			=>	'Totaal aantal onderwerpen',
'No of posts'			=>	'Totaal aantal bijdragen',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Bulletin board informatie',
'Board stats'			=>	'Bulletin board statistieken',
'User info'				=>	'Gebruikersinformatie'

);
