<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Cerca ed ordina utenti',
'User search info'		=>	'Inserisci un nome utente da cercare e/o un gruppo utenti da filtrare. Il campo nome utente pu&ograve; essere lasciato vuoto. Usa il carattere * per ricerche parziali. Ordina gli utenti per nome, data di registrazione o numero di messaggi in ordine ascendente/discendente.',
'User group'			=>	'Gruppo utenti',
'No of posts'			=>	'Numero messaggi',
'All users'				=>	'Tutti'

);
