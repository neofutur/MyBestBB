<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Klaidingas vartotojo vardas ir/arba slapta�odis.',
'Forgotten pass'		=>	'Pamir�ote slapta�od�?',
'Login redirect'		=>	'Prisijungta s�kmingai. Perkeliama &hellip;',
'Logout redirect'		=>	'Atsijungta s�kmingai. Perkeliama &hellip;',
'No e-mail match'		=>	'N�ra registruoto vartotojo su e-pa�to adresu',
'Request pass'			=>	'Pra�yti slapta�od�io',
'Request pass legend'	=>	'�veskite e-pa�to adres�, kuriuo prisiregistravote',
'Request pass info'		=>	'Naujas slapta�odis kartu su jo aktyvacijos nuoroda bus i�si�stas �iuo adresu.',
'Not registered'		=>	'Dar neprisiregistrav�?',
'Login legend'			=>	'�emiau �veskite vartotojo vard� ir slapta�od�',
'Login info'			=>	'Jei dar nesate prisiregistrav� ar pamir�ote savo slapta�od� spauskite ant atitinkamos nuorodos �emiau.',

// Forget password mail stuff
'Forget mail'			=>	'Lai�kas nusi�stas nurodytu adresu su instrukcijomis kaip pakeisti j�s� slapta�od�. Jei lai�ko nesulauksite, galite susisiekti su forumo administratoriumi adresu'

);
