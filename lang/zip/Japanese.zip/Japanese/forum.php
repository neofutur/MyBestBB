<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'新しいトピックの投稿',
'Views'			=>	'閲覧',
'Moved'			=>	'移動済',
'Sticky'		=>	'スティッキー',
'Empty forum'	=>	'フォーラムに投稿がありません。'

);
