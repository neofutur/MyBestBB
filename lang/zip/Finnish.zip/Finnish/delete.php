<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'		=>	'Poista viesti',
'Warning'		=>	'Varoitus! Jos t�m� on aiheryhm�n ensimm�inen viesti, koko viestiketju poistetaan.',
'Delete'		=>	'Poista',	// The submit button
'Post del redirect'	=>	'Viesti poistettu. Uudelleenohjaus &hellip;',
'Topic del redirect'	=>	'Aihe poistettu. Uudelleenohjaus &hellip;'

);
