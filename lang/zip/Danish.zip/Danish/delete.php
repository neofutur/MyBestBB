<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Slet indl�g',
'Warning'				=>	'Advarsel! Hvis dette er det f�rste indl�g i emnet, vil hele emnet blive slettet.',
'Delete'				=>	'Slet',	// The submit button
'Post del redirect'		=>	'Indl�g slettet. Henviser &hellip;',
'Topic del redirect'	=>	'Emne slettet. Henviser &hellip;'

);
