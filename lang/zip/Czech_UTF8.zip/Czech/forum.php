<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Založit nové téma',
'Views'			=>	'Zobrazení',
'Moved'			=>	'Přesunuto',
'Sticky'		=>	'Zvýrazněno',
'Empty forum'	=>	'Fórum je prázdné'

);