<?php

// Language definitions used in various scripts
$lang_misc = array(


'Mark read redirect'		=>	'Alle forums en bydrae is gemerk as gelees. Besig met nastuuring &hellip;',
// Send e-mail
'Form e-mail disabled'		=>	'Die gebruiker aan wie jy die e-pos probeer stuur het het forum e-pos na hom toe af gesit.',
'No e-mail subject'		=>	'Jy moet `n onderwerp verskaf.',
'No e-mail message'		=>	'Jy moet `n boodskap verskaf.',
'Too long e-mail message'	=>	'Jou boodskap kan ongelukkig nie langer 65535 (64 KB) wees nie.',
'E-mail sent redirect'		=>	' E-pos is gestuur. Besig met nastuuring &hellip;',
'Send e-mail to'		=>	'Stuur e-pos na',
'E-mail subject'		=>	'Onderwerp',
'E-mail message'		=>	'Boodskap',
'Write e-mail'			=>	'Skryf en stuur jou e-pos',

// Report
'No reason'			=>	'Jy moet `n rede verskaf.',
'Report redirect'		=>	'Boodskap gestuur. Besig met nastuuring &hellip:',
'Report post'			=>	'Raporteer Boodskap',
'Reason'			=>	'Reede',
'Reason desc'			=>	'Vul `n kort rede in waarom jy die bydrae aanmeld.',

// Subscriptions
'Already subscribed'		=>	'Jy het al klaar ingeskryf op die onderwerp.',
'Subscribe redirect'		=>	'Jy inskrywing is bygelas. Besig met nastuuring &hellip:',
'Not subscribed'		=>	'Jou is nie ingeskryf by die onderwerp nie.',
'Unsubscribe redirect'		=>	'Jou inskrywing is verwyder. Besig met nastuuring &hellip:',

// General forum and topic moderation
'Moderate'			=>	'Modereer',
'Select'			=>	'Kies',
'Move'				=>	'Skuif',
'Delete'			=>	'Verwyder',

// Moderate forum
'Open'				=>	'Begin',
'Close'				=>	'Sluit',
'Move topic'			=>	'Skuif onderwerp',
'Move topics'			=>	'Skuif onderwerpe',
'Move legend'			=>	'Kies die bestemming van die verskuiwing',
'Move to'			=>	'Skuif na',
'Leave redirect'		=>	'(?)Los onderwerp(e) nastuur',
'Move topic redirect'		=>	'Onderwerp geskuif. Besig met nastuuring &hellip;',
'Move topics redirect'		=>	'Onderwerpe verskuif. Besig met nastuuring &hellip;',
'Confirm delete legend'		=>	'Bevestig asb verwydering',
'Delete topics'			=>	'Vernietig onderwerpe',
'Delete topics comply'		=>	'Is jy seker dat jy die onderwerp will verwyder?',
'Delete topics redirect'	=>	'Onderwerp verwyder. Besig met nastuuring &hellip;',
'Open topic redirect'		=>	'Onderwerp begin. Besig met nastuuring &hellip;',
'Open topic redirect'		=>	'Onderwerpe oopgestel. Besig met nastuuring &hellip;',
'Close topic redirect'		=>	'Onderwerp gesluit. Besig met nastuuring &hellip;',
'Close topics redirect'		=>	'Onderwerpe gesluit. Besig met nastuuring &hellip;',
'No topics selected'		=>	'Jy moet minstens een onderwerp kies om te verwyder/sluit/of te skuif.',
'Stick topic redirect'		=>	'Onderwerp ge sticky. Besig met nastuuring &hellip;',
'Unstick topic redirect'	=>	'Onderwerp ge unsticky. Besig met nastuuring &hellip;',

// Delete multiple posts in topic
'Delete posts'			=>	'Bydrae verwyder',
'Delete posts comply'		=>	'Is jy seker dat jy die bydrae will verwyder?',
'Delete posts redirect'		=>	'Die bydrae is verwyder. Besig met nastuuring &hellip;',
'No posts selected'		=>	'Jy moet mistens een bydrae kies om te verwyder.'

);
