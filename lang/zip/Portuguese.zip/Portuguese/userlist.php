<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Encontre e ordene utilizadores',
'User search info'		=>	'Introduza um utilizador para procurar e/ou um grupo onde efectuar o filtro. O campo do username pode ficar em branco. Use o caracter * para procuras parciais. Ordene os utilizadores por nome, data de registo ou n�mero de posts e em ordem ascendente/descendente.',
'User group'			=>	'Grupo de utilizador',
'No of posts'			=>	'N�mero de coment�rios',
'All users'				=>	'Todos'

);
