<?php

// Language definitions used in chatbox.php
$lang_chatbox = array(

'Chatbox'				=>	'Chat',
'Messages'				=>	'Poruke',
'Anti flood'            =>  'Flood za�tita, pricekajte malo.',
'Anti blank'            =>  'Flood za�tita, nemo�e� upisati praznu poruku.',
'Btn Send'				=>	'Po�alji',
'Btn Refresh'			=>	'Osvje�i',

);
