<?php

// Language definitions used in delete.php
$lang_login = array(
 
// Miscellaneous
'Wrong user/pass'		=>	'Identifiant et/ou mot de passe incorrect.',
'Forgotten pass'		=>	'Mot de passe oubli�&#160;?',
'Login redirect'		=>	'Vous �tes maintenant identifi�. Redirection ...',
'Logout redirect'		=>	'Vous �tes maintenant d�connect�. Redirection ...',
'No e-mail match'		=>	'Il n`y a pas d\'utilisateur inscrit avec l\'adresse e-mail',
'Request pass'			=>	'Demande de mot de passe',
'Request pass legend'	=>	'Saisissez l\'adresse e-mail avec laquelle vous vous �tes inscrits',
'Request pass info'		=>	'Un nouveau mot de passe ainsi que le lien pour activer ce nouveau mot de passe vont �tre envoy�s � cette adresse e-mail.',
'Not registered'		=>	'Toujours pas inscrit&#160;?',
'Login legend'			=>	'Saisissez ci-dessous votre nom d\'utilisateur et votre mot de passe',
'Login info'			=>	'Si vous ne vous �tes jamais inscrits  ou si vous avez oubli� votre mot de passe, veuillez cliquer ci-dessous sur le lien appropri�.',
 
// Forget password mail stuff
'Forget mail'			=>	'Un e-mail avec les instructions pour changer de mot de passe vient d\'�tre envoy� � l\'adresse indiqu�e. Si vous ne le recevez pas, vous pouvez contacter l\'administrateur des forums �'
 
);