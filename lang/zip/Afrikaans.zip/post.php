<?php

// Language definitions used in post.php and edit.php
$lang_post = array(

// Post validation stuff (many are similiar to those in edit.php)
'No subject'			=>	'Die onderwerp moet `n titel he.',
'Too long subject'		=>	'Onderwerpe kan nie langer as 70 karakters wees nie.',
'No message'			=>	'Jy moet `n Boodskap in tik.',
'Too long message'		=>	'Jou boodskap mag nie langer as 65535 karakters (64 KB) wees nie.',

// Posting
'Post errors'			=>	'Fout tydens stuur van boodskap',
'Post errors info'		=>	'Die volgende foute moet reggemaak word voor die bydrae gepos kan word:',
'Post preview'			=>	'Voorbeeld van bydrae',
'Guest name'			=>	'Naam',
'Post redirect'			=>	'Bydrae ingestuur. Besig met nastuuring &hellip;',
'Post a reply'			=>	'Beantwoord',
'Post new topic'		=>	'Begin `n nuwe onderwerp',
'Hide smilies'			=>	'Moenie smilies in prente verander vir die bydrae',
'Subscribe'			=>	'Skryf in by die onderwerp',
'Topic review'			=>	'Oorsig van die onderwerp (nuutste eerste)',
'Flood start'			=>	'Jy moet ten minste',
'flood end'			=>	'sekondes wag tussen die stuur van boodskappe. Wag nog `n biekie en probeer dan weer.',
'Preview'			=>	'Voorvertooning',

// Edit post
'Edit post legend'		=>	'Verander die bydrae en stuur veranderinge',
'Silent edit'			=>	'Ongemerkde veranderinge (sit nie "Verander duur ..." in die onderwerp sig nie)',
'Edit post'			=>	'Verander bydrae',
'Edit redirect'			=>	'Bydrae verander. Besig met nastuuring &hellip;'

);
