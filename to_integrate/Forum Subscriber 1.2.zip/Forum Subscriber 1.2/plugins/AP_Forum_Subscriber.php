<?php
/***********************************************************************

  Copyright (C) 2005  Connor Dunn (Connorhd@mypunbb.com)
  Modified by 

  This software is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published
  by the Free Software Foundation; either version 2 of the License,
  or (at your option) any later version.

  This software is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
  MA  02111-1307  USA

************************************************************************/
// Make sure no one attempts to run this script "directly"
if (!defined('PUN'))
    exit;

// Tell admin_loader.php that this is indeed a plugin and that it is loaded
define('PUN_PLUGIN_LOADED', 1);

    generate_admin_menu($plugin);
?>
    <div class="block"> 
        <h2><span>Forum Subscriber</span></h2> 
        <div class="box"> 
            <div class="inbox"> 
                <p>Shows you what forums users are subscribed to, grouped by username</p>
            </div> 
        </div> 
    </div> 
    <div class="block">
        <h2 class="block2"><span>Forum Subscriber Viewer</span></h2>
        <div class="box">
            <div class="inbox">
                <table class="aligntop" cellspacing="0">
                    <?php
$result = $db->query('SELECT u.username, f.forum_name FROM '.$db->prefix.'subscriptions AS s INNER JOIN '.$db->prefix.'forums AS f ON s.forum_id=f.id LEFT JOIN '.$db->prefix.'users AS u ON s.user_id=u.id ORDER BY u.username;');

while ($row = $db->fetch_assoc($result))
{
    if (!isset($last_user)) {
        echo "<tr>\n\t\t\t\t\t\t<th scope=\"row\">\n\t\t\t\t\t\t\t".$row['username']."\n\t\t\t\t\t\t</th>\n\t\t\t\t\t\t<td>\n\t\t\t\t\t\t\t<span>";
        echo $row['forum_name'];
    }
    elseif ($last_user == $row['username']) {
        echo ', '.$row['forum_name'];
    }
    else
    {
        echo "</span>\n\t\t\t\t\t\t</td>\n\t\t\t\t\t</tr>\n\t\t\t\t\t<tr>\n\t\t\t\t\t\t<th scope=\"row\">\n\t\t\t\t\t\t\t".$row['username']."\n\t\t\t\t\t\t</th>\n\t\t\t\t\t\t<td>\n\t\t\t\t\t\t\t<span>";
        echo $row['forum_name'];
    }
    $last_user = $row['username'];
}
echo "\n ";
?></span>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>