<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'			=>	'Antwoord',
'Topic closed'			=>	'Onderwerp gesluit',
'From'				=>	'Van',				// User location
'Note'				=>	'Nota',				// Admin note
'Website'			=>	'Webblad',
'Guest'				=>	'Gas',
'Online'			=>	'Oplyn',
'Offline'			=>	'Aflyn',
'Last edit'			=>	'Laaste verander deur',
'Report'			=>	'Rapporteer',
'Delete'			=>	'Verwyder',
'Edit'				=>	'Bewerk',
'Quote'				=>	'Haal aan',
'Is subscribed'			=>	'Jy is op die oomblik ingeskryf by die onderwerp',
'Unsubscribe'			=>	'Teken uit',
'Subscribe'			=>	'Teken in by die onderwerp',
'Quick post'			=>	'Snel bydrae',

'Link separator'		=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'			=>	'Moderator beheer'

);
