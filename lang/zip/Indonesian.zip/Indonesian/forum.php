<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Kirim topik baru',
'Views'			=>	'Dilihat',
'Moved'			=>	'Dipindahkan',
'Sticky'		=>	'Sticky',
'Empty forum'	=>	'Forum kosong.'

);
