<?php
/******************************************************************************************************
		Reputation Plugin for PunBB
		----------------------------
-- Version 2.2.0
-- Created by hcs on 25-04-2006  hcs@mail.ru

-- GPL:
  This software is free software; you can redistribute it and/or modify it
  under the terms of the GNU General Public License as published
  by the Free Software Foundation; either version 2 of the License,
  or (at your option) any later version.

  This software is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
  MA  02111-1307  USA
******************************************************************************************************/
// Language definitions used by the Reputation System mod
$lang_reputation = array(
  'Reputation' 				=> 	'Reputace',
  'Disabled' 				=> 	'Syst�m reputace je nyn� vypnut�',
  'Invalid voice value' 		=> 	'Hodnota hlasu byla �patn�, pros�m jd�te zp�t a opravte j�.',
  'Silly user' 				=> 	'Nem��ete d�t hlas sami sob�',
  'No user'					=>	'�patn� ID u�ivatele, u�ivatel s t�mto ID neexistuje',
  'Timeout 1'				=>	'Dal�� hlasov�n� m��ete prov�st a� za ',
  'Timeout 2'       			=>    ' minut.',
  'Plus'					=>	'Zv��en� reputace',
  'Minus'					=>	'Sn�en� reputace',
  'Form header'				=>	'P�id�n� reputace',
  'Form your name'			=>	'V�e p�ezd�vka',
  'Form to name'				=>	'Komu',
  'Form reason'				=>	'D�vod',
  'Form method'				=>	'Akce',
  'Redirect Message'			=>	'Reputace byla �sp�n� zm�n�na. P�esm�rov�v�m&hellip;',
  'User reputation' 			=>	'Reputace u�ivatele ',
  'From user'				=>	'Od u�ivatele',
  'For topic'				=>	'T�ma',
  'Reason'					=>	'D�vod',
  'Estimation'				=>	'Akce',
  'Date'					=>	'Datum',
  'No reputation'				=>	'Nen� ��dn� reputace',
  'No message'				=>	'D�vod je povinn�',
  'Too long message' 			=> 	'P��li� dlouh� zpr�va',
  'Max length of message' 		=>    'Maxim�ln� d�lka zpr�vy:',
  'You already of use' 			=>	'U� jste pou�ili',
  'Of symbol'				=>	'znak�',
  'Profile deleted'			=>	'Profil byl smaz�n',
  'Delete'					=>	'Odstranit',
  'Are you sure'				=>	'Jste si jist�?',
  'Deleted redirect'			=>	'Odstran�no. P�esm�rov�v�m&hellip;',
  'Reputation mod'			=>	'Reputace',
  'Plugin description'			=>	'Toto roz���en� je ur�eno k nastaven� a povolen� reputace u�ivatel�.',
  'Removed or deleted'			=>	'Odstran�no nebo vymaz�no',
  'Group Disabled'			=> 	'Pro tuto skupinu, do kter� vstoup�te, je pou�it� reputace zak�z�no',
  'Individual Disabled'			=> 	'Administr�tor v�m zak�zal pou��v�n� reputace',
  'User Disable'				=>	'U�ivatel nedovolil pou�it� reputace',  
  'Your Disabled'				=>	'Nem��ete u��vat syst�m hodnocen� reputace',
  'Small Number of post'		=>	'Nedostate�n� mno�stv� zpr�v pro vyhodnocen� reputace ',
  'Manage reputation'			=>	'Uk�zat reputaci',
  'Description Manage reputation'	=>	'Pokud zak�ete syst�m reputace, nikdo va�i reputaci nem��e hodnotit. Z�rove� v�ak nesm�te hodnotit ani zhl�dnout reputaci ostatn�ch u�ivatel�.' 
);
