<?php

// Language definitions used in help.php
$lang_help = array(

'Help'					=>	'Pal�dz�ba',
'produces'				=>	'veido',

'BBCode info 1'			=>	'BBCode ir format��anas elementu grupa kas at�auj main�t teksta izskatu �aj� forum�. BBCode ir balst�ts uz tiem pa�iem principiem un ir �oti l�dz�gs HTML valodai. Zem�k ir saraksts ar visiem pieejamajiem BBCode elementiem un aprakstiem - k� tos lietot.',
'BBCode info 2'			=>	'Administratoriem ir iesp�jas iesl�gt un izsl�gt BBCode. Tas, vai BBCode ir iesl�gts vai izsl�gts tiek att�lots kreisaj� mal� zem koment�ra pievieno�anas vai paraksta redi���anas lauka. ',

'Text style'			=>	'Teksta stils',
'Text style info'		=>	'�ie elementi maina teksta izskatu:',
'Bold text'				=>	'Iebiezin�ts teksts',
'Underlined text'		=>	'Pasv�trots teksts',
'Italic text'			=>	'Sl�ps teksts',
'Red text'				=>	'Sarkans teksts',
'Blue text'				=>	'Zils teksts',

'Links and images'		=>	'Saites un bildes',
'Links info'			=>	'Tu vari izveidot saites uz citiem dokumentiem, e-pasta adres�m izmantojot sekojo�os elementus:',
'My e-mail address'		=>	'Mana e-pasta adrese',
'Images info'			=>	'Ja v�lies par�d�t bildes, tu vari izmantot img elementu.',

'Quotes'				=>	'Cit�ti',
'Quotes info'			=>	'Ja v�lies k�du cit�t, tev b�tu ieteicams izmantot quote elementu.',
'Quotes info 2'			=>	'Ja nev�lies cit�t k�du konkr�tu, tu vari izmantot quote elementu nenor�dot v�rdu',
'Quote text'			=>	'�is ir teksts ko es v�los cit�t',
'produces quote box'	=>	'izveido ��du cit�ta kasti:',

'Code'					=>	'Kods',
'Code info'				=>	'Kad v�lies par�d�t izejas kodu, lieto code elementu. Teksts kas tiek att�lots ar code elementu izmantos fiks�ta platuma fontu. Ar� citi t� iek�ien� eso�ie elementi netiks apstr�d�ti.',
'Code text'				=>	'�is ir koda paraugs.',
'produces code box'		=>	'izveido ��du koda kasti:',

'Nested tags'			=>	'Iek�autie elementi',
'Nested tags info'		=>	'BBCode elementus var iek�aut vienu otr� lai pan�ktu sare���tu izskatu. Piem�ram:',
'Bold, underlined text'	=>	'Iebiezin�ts, pasv�trots teksts.',

'Smilies info'			=>	'Ja v�lies (un tas ir iesl�gts), forums var att�lot smaidi�us k� bildes. �is forums atpaz�st sekojo�us smaidi�us - un aizst�j tos ar bild�m:'

);
