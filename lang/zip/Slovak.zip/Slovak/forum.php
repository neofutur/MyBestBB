<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Zalo�i� nov� t�mu',
'Views'			=>	'Zobrazen�',
'Moved'			=>	'Presunut�',
'Sticky'		=>	'Zv�raznen�',
'Empty forum'	=>	'F�rum je pr�zdne.'

);
