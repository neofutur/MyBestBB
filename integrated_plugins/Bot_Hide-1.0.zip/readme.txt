##
##
##        Mod title:  Bot Hide
##
##      Mod version:  1.0
##   Works on PunBB:  1.2.10
##     Release date:  2006-01-22
##           Author:  Brian Hysell (pogenwurst[at]gmail[dot]com)
##
##      Description:  Hides "Powered by PunBB" and the copyright in the board
##			footer if the visitor has a user agent of a search
##			engine spider. Meant as a small measure of security 
##			against pesky script kiddies. By no means foolproof.
##
##   Affected files:  footer.php
##                    include/common.php
##
##       Affects DB:  No
##
##            Notes:  Very simple and my first mod to be released. Please
##                    contact me with any suggestions you may have.
##                    This mod intends to stop crackers from finding your
##                    forum by searching for "Powered by PunBB" or
##                    "Copyright Rickard Andersson".
##                    Blacklisted UA strings are held in the array $spiders
##                    in include/common.php. Most come from a list
##			(http://www.siteware.ch/webresources/useragents/spiders/)
##	    		in addition to other sources. Add/remove from the blacklist
##			as you please.
##
##       DISCLAIMER:  Please note that "mods" are not officially supported by
##                    PunBB. Installation of this modification is done at your
##                    own risk. Backup your forum database and any and all
##                    applicable files before proceeding.
##
##



#
#---------[ 1. OPEN ]---------------------------------------------------------
#

footer.php


#
#---------[ 2. FIND (line: 108) ]--------------------------------------------
#

?>
			<p class="conr">Powered by <a href="http://www.punbb.org/">PunBB</a><?php if ($pun_config['o_show_version'] == '1') echo ' '.$pun_config['o_cur_version']; ?><br />&copy; Copyright 2002&#8211;2005 Rickard Andersson</p>


#
#---------[ 3. BEFORE, ADD ]-------------------------------------------------
#

	if (!in_array($_SERVER['HTTP_USER_AGENT'], $spiders)) {

#
#---------[ 4. FIND (line: 110) ]--------------------------------------------
#

<?php


#
#---------[ 5. AFTER, ADD ]-------------------------------------------------
#

	}


#
#---------[ 6. OPEN ]---------------------------------------------------------
#

include/common.php


#
#---------[ 7. FIND (line: 146) ]---------------------------------------------
#

// Update online list
update_users_online();


#
#---------[ 8. AFTER, ADD ]---------------------------------------------------
#

$spiders = array(
	'AltaVista Intranet V2.0 www.altavista.de search-support@altavista.de',
	'AnzwersCrawl/2.0 (anzwerscrawl@anzwers.com.au; http://faq.anzwers.com.au/anzwerscrawl.html)',
	'Arachnoidea (arachnoidea@euroseek.com)',
	'ArchitextSpider',
	'Googlebot/1.0 (googlebot@googlebot.com http://googlebot.com/)',
	'Gulliver/1.2',
	'Infoseek Sidewinder/0.9',
	'Lycos_Spider_(T-Rex)/3.0',
	'Mozilla/3.01 (Win95; I)',
	'Scooter/1.0',
	'Scooter/1.0 scooter@pa.dec.com',
	'Scooter/1.1 (custom)',
	'Scooter/2.0 G.R.A.B. X2.0',
	'Scooter/2.0 G.R.A.B. V1.1.0',
	'Slurp/2.0 (slurp@inktomi.com; http://www.inktomi.com/slurp.html)',
	'Slurp.so/1.0 (slurp@inktomi.com; http://www.inktomi.com/slurp.html)',
	'Ultraseek',
	'Mozilla/5.0 (compatible; Yahoo! Slurp; http://help.yahoo.com/help/us/ysearch/slurp)',
	'msnbot/1.0 (+http://search.msn.com/msnbot.htm)',
	'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
	'Mozilla/5.0 (compatible; BecomeBot/2.3; MSIE 6.0 compatible; +http://www.become.com/site_owners.html)',
	'findlinks/1.1-a7 (+http://wortschatz.uni-leipzig.de/findlinks/)',
	'StackRambler/2.0 (MSIE incompatible)',
	'msnbot/0.9 (+http://search.msn.com/msnbot.htm)',
	'ia_archiver',
	'Findexa Crawler (http://www.findexa.no/gulesider/article26548.ece)',
	'Mozilla/3.0 (compatible; WebMon 1.0.10; Windows XP)',
	'Acoon Robot v1.01 (www.acoon.de)',
	'fido/1.0 Harvest/1.4.pl2',
	'GAIS Robot/1.0B2',
	'KIT_Fireball/2.0',
	'lwp-trivial/1.27',
	'Mozilla/2.0 (compatible; EZResult -- Internet Search Engine)',
	'Mozilla/2.0 (compatible; T-H-U-N-D-E-R-S-T-O-N-E)',
	'Mozilla/3.0 (compatible; MuscatFerret/1.4.1; olly@muscat.co.uk)',
	'Mozilla/3.0 (compatible; MuscatFerret/1.5.2; olly@muscat.co.uk)',
	'Mozilla/3.0 (compatible; MuscatFerret/1.5.3; olly@muscat.co.uk)',
	'Mozilla/4.04 [de] (Win95; I ;Kolibri gncwebbot)',
	'Mozilla/4.04 [de] (Win95; I ;Nav; Kolibri gncwebbot)',
	'search.at V1.2',
	'SwissSearch V1.2',
	'The Informant',
	'WebCrawler/3.0 Robot libwww/5.0a',
	'WebCrawler-AddURL/2.0'
	);

#
#---------[ 9. SAVE/UPLOAD ]-------------------------------------------------
#