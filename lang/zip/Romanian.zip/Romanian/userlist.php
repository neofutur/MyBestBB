<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Caută şi sortează utilizatori',
'User search info'		=>	'Introduceţi un nume utilizator pentru căutare şi/sau un grup de utilizatori pentru filtrare. Câmpul nume utilizator poate fi vid. Utilizaţi metacaracterul * pentru rezultate parţiale. Sortaţi utilizatorii după nume, data înregistrării sau numărul de mesaje în ordine ascendentă/descendentă.',
'User group'			=>	'Grup de utilizatori',
'No of posts'			=>	'Nr. mesaje',
'All users'				=>	'Toate'

);
