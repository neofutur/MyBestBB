<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'V�lasz k�ld�se',
'Topic closed'		=>	'Lez�rt t�ma',
'From'				=>	'K�ld�',				// User location
'Note'				=>	'Megjegyz�s',				// Admin note
'Website'			=>	'Weblap',
'Guest'				=>	'Vend�g',
'Online'			=>	'Bel�pett',
'Offline'			=>	'Kil�pett',
'Last edit'			=>	'Utolj�ra szerkesztette',
'Report'			=>	'Jelent�s',
'Delete'			=>	'T�rl�s',
'Edit'				=>	'Szerkeszt�s',
'Quote'				=>	'Id�zet',
'Is subscribed'		=>	'Jelenleg fel vagy iratkozva erre a t�m�ra',
'Unsubscribe'		=>	'Leiratkoz�s',
'Subscribe'			=>	'Feliratkoz�s a t�m�ra',
'Quick post'		=>	'Gyors�zen�',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Moder�tor eszk�z�k'

);
