<?php
// Language definitions used in viewforum.php
$lang_forum = array(
'Post topic' => 'Gửi bài mới',
'Views' => 'Xem',
'Moved' => 'Chuyển',
'Sticky' => 'Chú ý',
'Empty forum' => 'Không có phòng thảo luận nào.'
);
