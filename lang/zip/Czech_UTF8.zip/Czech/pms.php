<?php

// Language definitions used by the Private Message System-mod
$lang_pms = array(
	// Common
	'Messages'					=>		'Soukromé zprávy',
	'Message'					=>		'Zpráva',
	'Save message'				=>		'Uložit zprávu',
	'Send'						=>		'Odeslat',

	// Messages
	'Inbox'						=>		'Přijaté',
	'Outbox'					=>		'Odeslané',
	'Box0'						=>		'Odeslané',
	'Box1'						=>		'Přijaté',
	'Action'					=>		'Akce',
	'Reply'						=>		'Odpovědět',
	'Delete'					=>		'Smazat',
	'Quote'						=>		'Citovat',
	'Date'						=>		'Datum',
	'Status'					=>		'Stav zprávy:',
	'Subject'					=>		'Předmět',
	'Sender'					=>		'Odesílatel',
	'Receiver'					=>		'Příjemce',
	'Private Messages'			=> 		'Soukromé zprávy',
	'New message'				=>		'Poslat novou zprávu',
	'Multidelete'				=>		'Smazat více zpráv',
	'Delete messages comply'	=> 		'Chceš opravdu smazat vybrané zprávy?',
	'Deleted redirect'			=> 		'Zprávy smazány. Přesměrovávám&hellip',
	'Read redirect'				=> 		'Všechny zprávy byly označeny jako přectené. Přesměrovávám&hellip',
	'Mark all'					=>		'Označit všechny zprávy jako přečtené',

	// Viewtopic
	'PM'						=>		'PM',

	// Profile
	'Quick message'				=> 		'Poslat soukromou zprávu',
	'Show smilies'				=>		'Zobrazit smajlíky',

	// Send or delete message
	'Send to'					=>		'Komu',
	'Send a message'			=>		'Poslat zprávu',
	'Delete message'			=>		'Vymazat zprávu',
	'Del redirect'				=>		'Zpráva smazána, přesměrovávám&hellip',
	'Sent redirect'				=>		'Zpráva poslána uživateli, přesměrovávám&hellip',

	// Errors and messages
	'No messages'				=>		'Žádné zprávy',
	'New messages'				=>		'Máte nové zprávy',
	'No user'					=>		'Není zde uživatel s takovým jménem/nickem.',
	'Full inbox'				=>		'Složka pro přijaté zprávy je plná!',
	'Inbox full'				=>		'Uživatel má plno ve složce pro zprávy, nemůžete mu zaslat zprávu.',
	'Sent full'					=>		'Nelze uložit zprávu, složka je plná.',
	'Flood start'				=>		'Nejméně',
	'Flood end'					=>		'vteřin do odeslání další zprávy. Prosím vyčkejte chvíli a odešlete zprávu znovu.'
);

