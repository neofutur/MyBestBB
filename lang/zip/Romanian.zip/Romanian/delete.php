<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Şterge mesajul',
'Warning'				=>	'Atenţie! Dacă acesta este primul mesaj din subiect, întregul subiect va fi şters.',
'Delete'				=>	'Şterge',	// The submit button
'Post del redirect'		=>	'Mesaj şters. Redirectez către &hellip;',
'Topic del redirect'	=>	'Subiect şters. Redirectez către &hellip;'

);
