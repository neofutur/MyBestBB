<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Teme',
'Moderators'			=>  'Moderatorji',
'Link to'				=>	'Povezava',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Deska je prazna.',
'Newest user'			=>	'Novi registrirani uporabniki',
'Users online'			=>	'Prisotni  registrirani uporabniki',
'Guests online'			=>	'Prisotni gosti',
'No of users'			=>	'�tevilo registriranih uporabnikov.',
'No of topics'			=>	'�tevilo tem',
'No of posts'			=>	'�tevilo objav',
'Online'				=>	'Prisotni',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informacije o deski',
'Board stats'			=>	'Statistika deske',
'User info'				=>	'Informacija o uporabniku'

);
