<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Kirim balasan',
'Topic closed'		=>	'Topik ditutup',
'From'				=>	'Dari',				// User location
'Note'				=>	'Catatan',				// Admin note
'Website'			=>	'Situs Web',
'Guest'				=>	'Pengunjung',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Terakhir di-edit oleh',
'Report'			=>	'Laporan',
'Delete'			=>	'Hapus',
'Edit'				=>	'Edit',
'Quote'				=>	'Kutipan',
'Is subscribed'		=>	'Saat ini anda sedang berlangganan topik ini',
'Unsubscribe'		=>	'Berhenti langganan',
'Subscribe'			=>	'Langganan topik ini',
'Quick post'		=>	'Posting cepat',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Kontrol moderator'

);
