<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'                        =>        'Usuń post',
'Warning'                                =>        'Uwaga! Jeżeli to jest pierwszy post to cały wątek zostanie usunięty .',
'Delete'                                =>        'Usuń',        // The submit button
'Post del redirect'                =>        'Post usunięty. Przekierowywanie &hellip;',
'Topic del redirect'        =>        'Wątek usunięty. Przekierowywanie &hellip;'

);
