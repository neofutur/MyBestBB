<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'                =>        'Wyszukaj u�ytkownik�w',
'User search info'                =>        'Wpisz  u�ytkownika lub wybierz grup�, kt�rej cz�onk�w chcesz zobaczy�. Pole u�ytkownika mo�e by� puste. U�ywaj znaku * dla cz�ciowych wynik�w. Sortuj u�ytkownik�w nazwami, dat� rejestracji lub liczb� post�w oraz w rosn�cej/malej�cej kolejno�ci.',
'User group'                        =>        'Grupa u�ytkownika',
'No of posts'                        =>        'Liczba post�w',
'All users'                                =>        'Wszystkie'

);
