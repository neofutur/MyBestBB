<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Novo tema',
'Views'			=>	'Vistas',
'Moved'			=>	'Movido',
'Sticky'		=>	'Permanente',
'Empty forum'	=>	'O foro est� baleiro.'

);
