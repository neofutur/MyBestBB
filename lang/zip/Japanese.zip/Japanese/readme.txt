Japanese Translation
------------------------
Author: Mitsuhiro Yoshida (mits@mitstek.com)
http://mitstek.com/


All files are written in UTF-8.
Any suggestion for Japanese version, feel free to contact me.

すべてのファイルはUTF-8で記述されています。
誤訳・訂正等ございましたらお気軽にご連絡ください。
