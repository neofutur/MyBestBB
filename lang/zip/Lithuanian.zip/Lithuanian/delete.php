<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Trinti �inut�',
'Warning'				=>	'�sp�jimas! Jei tai pirma �inut� temoje, bus i�trinta visa tema.',
'Delete'				=>	'Trinti',	// The submit button
'Post del redirect'		=>	'�inut� i�trinta. Perkeliama &hellip;',
'Topic del redirect'	=>	'Tema i�trinta. Perkeliama &hellip;'

);
