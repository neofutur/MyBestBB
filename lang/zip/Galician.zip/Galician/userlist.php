<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Encontra e ordea usuarios',
'User search info'		=>	'Introduce un nome de usuario para Buscar, e/ou un grupo de usuarios para filtra-la busca. O campo nome de usuario podes deixalo en branco. Usa o caracter asterisco * para coincidencias parciais. Ordea os usuarios por nome, data de rexistro ou n�mero de mensaxes e en orde ascendente/descendente.',
'User group'			=>	'Grupo de usuarios',
'No of posts'			=>	'N�m. de mensaxes',
'All users'				=>	'Todos'

);
