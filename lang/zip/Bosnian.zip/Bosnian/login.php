<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Pogre�no korisni�ko ime ili lozinka.',
'Forgotten pass'		=>	'Zaboravili ste lozinku?',
'Login redirect'		=>	'Uspje�no ste prijavljeni. Preusmjeravanje &hellip;',
'Logout redirect'		=>	'Odjavljeni ste. Preusmjeravanje &hellip;',
'No e-mail match'		=>	'Nijedan korisnik nije registrovan sa unesenom e-mail adresom',
'Request pass'			=>	'Tra�i lozinku',
'Request pass legend'	=>	'Unesite e-mail adresu s kojom ste se registrovali',
'Request pass info'		=>	'Nova lozinka zajedno sa linkom za aktiviranje �e biti poslana na navedenu e-mail adresu.',
'Not registered'		=>	'�elite se registrovati?',
'Login legend'			=>	'Unesite Va�e podatke za prijavu',
'Login info'			=>	'Ukoliko se �elite registrovati ili ste zaboravili lozinku odaberite opciju ispod.',

// Forget password mail stuff
'Forget mail'			=>	'Na nazna�enu e-mail adresu je poslano uputstvo za mjenjanje lozinke ukoliko ste ju zaboravili. Ukoliko do�e do gre�ke, kontaktirajte administratora na'

);
