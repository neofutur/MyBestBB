<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Finn og sorter brukere',
'User search info'		=>	'Skriv inn et brukernavn og s�ke etter og/eller en brukergruppe � sortere etter. Brukernavn-feltet kan st� tomt. Bruk wildcard-tegnet * for delvis match. Sorter brukere etter navn, dato registrert eller antall poster og i stigende/synkende rekkef�lge.',
'User group'			=>	'Brukergruppe',
'No of posts'			=>	'Antall poster',
'All users'				=>	'Alle'

);
