<?php

// SPRACHDEFINITIONEN DIE IN "delete.php" GEBRAUCHT WERDEN
$lang_delete = array(

'Delete post'			=>	'Beitrag l&ouml;schen',
'Warning'				=>	'<font style="color:#FF0000"><b>Achtung!</b></font> Wenn dies der erste Beitrag in einem Thema ist, werden automatisch alle Folgebeitr&auml;ge gel&ouml;scht',
'Delete'				=>	'L&ouml;schen',	// DER VORSCHLAGTASTER
'Post del redirect'		=>	'Beitrag gel&ouml;scht. Leite weiter &hellip;',
'Topic del redirect'	=>	'Thema gel&ouml;scht. Leite weiter &hellip;'

);
