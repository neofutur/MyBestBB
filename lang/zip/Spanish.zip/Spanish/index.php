<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Temas',
'Moderators'			=>  'Moderadores',
'Link to'				=>	'Enlace a',	// As in "Link to http://www.punbb.org/"
'Empty board'		=>	'El foro est� vac�o.',
'Newest user'			=>	'Ultimo usuario registrado',
'Users online'			=>	'Usuarios registrados conectados',
'Guests online'			=>	'Invitados conectados',
'No of users'			=>	'N�mero total de usuarios registrados',
'No of topics'			=>	'N�mero total de temas',
'No of posts'			=>	'N�mero total de mensajes',
'Online'				=>	'Conectados',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informaci�n del foro',
'Board stats'			=>	'Estad�sticas del foro',
'User info'				=>	'Informaci�n del usuario'

);
