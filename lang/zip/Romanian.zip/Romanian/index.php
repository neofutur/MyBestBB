<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Subiecte',
'Moderators'			=>  'Moderatori',
'Link to'				=>	'Legătură către',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Forumul este gol.',
'Newest user'			=>	'Cel mai recent utilizator înregistrat',
'Users online'			=>	'Utilizatori înregistraţi online',
'Guests online'			=>	'Oaspeţi online',
'No of users'			=>	'Număr total de utilizatori înregistraţi',
'No of topics'			=>	'Număr total de subiecte',
'No of posts'			=>	'Număr total de mesaje',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informaţii despre forum',
'Board stats'			=>	'Statistici despre forum',
'User info'				=>	'Informaţii utilizator'

);
