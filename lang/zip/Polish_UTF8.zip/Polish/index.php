<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'                                =>  'Wątki',
'Moderators'                        =>  'Moderatorzy',
'Link to'                                =>        'Link do',        // As in "Link to http://www.punbb.org/"
'Empty board'                        =>        'Forum jest puste.',
'Newest user'                        =>        'Ostatnio zarejestrowany',
'Users online'                        =>        'Użytkownicy online',
'Guests online'                        =>        'Goście online',
'No of users'                        =>        'Wszyscy użytkownicy',
'No of topics'                        =>        'Wszystkie wątki',
'No of posts'                        =>        'Wszystkie posty',
'Online'                                =>        'Online',        // As in "Online: User A, User B etc."
'Board info'                        =>        'Informacje o forum',
'Board stats'                        =>        'Statystyki forum',
'User info'                                =>        'Informacje o użytkowniku'

);
