<?php


// Determine what locale to use
switch (PHP_OS)
{
	case 'WINNT':
	case 'WIN32':
		$locale = 'dutch';
		break;

	case 'FreeBSD':
	case 'NetBSD':
	case 'OpenBSD':
		$locale = 'nl_NL.ISO8859-1';
		break;

	default:
		$locale = 'nl_NL';
		break;
}

// Attempt to set the locale
setlocale(LC_CTYPE, $locale);


// Language definitions for frequently used strings
$lang_common = array(

// Text orientation and encoding
'lang_direction'		=>	'ltr',	// ltr (Left-To-Right) or rtl (Right-To-Left)
'lang_encoding'			=>	'iso-8859-1',
'lang_multibyte'		=>	false,

// Notices
'Bad request'			=>	'Ongeldige versoek. Die skakel wat jy probeer oopmaak het is ongeldig of verouderd.',
'No view'			=>	'Jy het nie toestemming om die forum te bekyk nie.',
'No permission'			=>	'Jy het nie toestemming om die bladsy oop te maak nie.',
'Bad referrer'			=>	'Verkeerde HTTP_REFERER. Jy was verwys na die blad van `n ongemagtigde bron. As die probleem aan hou, maak asb seker dat die \'Base URL\' juis is en reg gestel in Beheer/Opsies en dat jy toegang vereis van daar die URL af. Vir meer verwitteging oor die \'referrer\' kan jy die PunBB dokumentasie lees.',

// Topic/forum indicators
'New icon'			=>	'Daar is nuwe bydrae',
'Normal icon'			=>	'<!-- -->',
'Closed icon'			=>	'Die onderwerp is gesluit',
'Redirect icon'			=>	'Nagestuurde forum',

// Miscellaneous
'Announcement'			=>	'Aankondiging',
'Options'			=>	'Opsies',
'Actions'			=>	'Aksies',
'Submit'			=>	'Stuur',	//"name" of submit buttons
'Ban message'			=>	'Jy is verban van die forum af',
'Ban message 2'			=>	'Jy is verban tot die einde van',
'Ban message 3'			=>	'Die moderator of beheerder wat jou verban het, het die volgende boodskap gelos',
'Ban message 4'			=>	'Stuur asb enige vrae na die beheerder van die forum',
'Never'				=>	'Nooit',
'Today'				=>	'Vandag',
'Yesterday'			=>	'Gister',
'Info'				=>	'Info',		//a common table header
'Go back'			=>	'Gaan terug',
'Maintenance'			=>	'Onderhoud',
'Redirecting'			=>	'Besig met nastuuring',
'Click redirect'		=>	'Klik hier as jy nie langer wil wag (of as jou browser jou nie outomaties nastuur nie.)',
'on'				=>	'aan',		//as in "BBCode is on"
'off'				=>	'af',
'Invalid e-mail'		=>	'Die e-pos adress wat jy verskaf het is ongeldig.',
'required field'		=>	'Dis `n verpligte veld in die vorm.',	//for javascript for validation
'Last post'			=>	'Nuutste bydrae',
'by'				=>	'Deur',		//as in last post by someuser
'New posts'			=>	'Nuwe&nbsp;bydrae',	//the link that leads to the first new post (use &nbsp; for spaces)
'New posts info'		=>	'Gaan na die nuutste bydrae in die onderwerp',		//the popup text for new posts links
'Password'			=>	'Wagwoord',
'E-mail'			=>	'E-pos',
'Send e-mail'			=>	'Stuur e-pos',
'Moderated by'			=>	'Gemodereer deur',
'Registered'			=>	'Geregistreerd',
'Subject'			=>	'Onderwerp',
'Message'			=>	'Boodskap',
'Topic'				=>	'Onderwerp',
'Forum'				=>	'Forum',
'Posts'				=>	'Bydrae',
'Replies'			=>	'Antwoorde',
'Author'			=>	'Skrywer',
'Pages'				=>	'Bladsy(e)',
'BBCode'			=>	'BBCode',	// You probably shouldn't change this
'img tag'			=>	'[img] tag',
'Smilies'			=>	'Smilies',
'and'				=>	'en',
'Image link'			=>	'Prentjie',	// This is displayed (i.e <image>) instead of images when "Show images is disabled in the profile
'wrote'				=>	'het geskryf',	// For [quote]'s
'Code'				=>	'Kode',		// For [code]'s
'Mailer'			=>	'Pos stuurder',	// As in "MyForums Mailer" in the signature of out going e-mails
'Important information'		=>	'Belangrike informasie',
'Write message legend'		=>	'Skryf jou berig en stuur',

// Title

'Title'				=>	'Titel',
'Member'			=>	'Lid',		// Default title
'Moderator'			=>	'Moderator',
'Administrator'			=>	'Beheerder',
'Banned'			=>	'Verban',
'Guest'				=>	'Gas',

// Stuff for include/parser.php

'BBCode error'			=>	'Die sintaks in die berig is onjuis.',
'BBCode error 1'		=>	'Die oopenhakie vir [/quote] ontbreek.',
'BBCode error 2'		=>	'Die sluit etiket vir [code] ontbreek.',
'BBCode error 3'		=>	'Die oopen etiket vir [/code] ontbreek.',
'BBCode error 4'		=>	'Daar is een of meer sluit etikette vir [quote].',
'BBCode error 5'		=>	'Daar is een of meer oopen etikette vir [/quote].',

// Stuff for the navigator (top of every page)


'Index'				=>	'Indeks',
'User list'			=>	'Gebruikers lys',
'Rules'				=>	'Voorskrif',
'Search'			=>	'Soek',
'Register'			=>	'Registreer',
'Login'				=>	'Login',
'Not logged in'			=>	'Jy is nie ingelog nie.',
'Profile'			=>	'Profiel',
'Logout'			=>	'Log uit',
'Logged in as'			=>	'Ingelog as',
'Admin'				=>	'Beheer',
'Last visit'			=>	'Vorige besoek',
'Show new posts'		=>	'Wys nuwe bydrae van laaste inlog af',
'Mark all as read'		=>	'Merk alle onderwerpe as gelees',
'Link separator'		=>	'',	//The text that separates links in the navigator

// Stuff for the page footer
'Board footer'			=>	'Bord voetstuk',
'Search links'			=>	'Soek skakels',
'Show recent posts'		=>	'Wys onlangse bydrae',
'Show unanswered posts'		=>	'Wys onbeantwoorde bydrae',
'Show your posts'		=>	'Wys jou bydrae',
'Show subscriptions'		=>	'Way onderwerpe waar by jy aangeteken is',
'Jump to'			=>	'Gaan na',
'Go'				=>	'Gaan',		// submit button in forum jump
'Move topic'			=>	'Verplaas onderwerp',
'Open topic'			=>	'Begin onderwerp',
'Close topic'			=>	'Sluit onderwerp',
'Unstick topic'			=>	'Unstick onderwerp',
'Stick topic'			=>	'Sticky onderwerp',
'Moderate forum'		=>	'Modereer forum',
'Delete posts'			=>	'Verwyder meerfoudige bydrae',
'Debug table'			=>	'Debug informasie',

// For extern.php RSS feed
'RSS Desc Active'		=>	'Mees onlangse aktiewe onderwerp op',	// board_title will be appended to this string
'RSS Desc New'			=>	'Die nuutste onderwerpe op',					// board_title will be appended to this string
'Posted'			=>	'Gepos'	// The date/time a topic was started

);
