﻿<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'نیا موضوع شروع کریں',
'Views'			=>	'مناظر',
'Moved'			=>	'منتقل شدہ',
'Sticky'		=>	'چپکا ہوا',
'Empty forum'	=>	'فورم خالی ہے۔'

);
