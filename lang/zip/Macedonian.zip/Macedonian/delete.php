<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Избриши порака',
'Warning'				=>	'Предупредување! Ако ова е првата порака во темата, цела тема ќе биде избришана.',
'Delete'				=>	'Избриши',	// The submit button
'Post del redirect'		=>	'Пораката е избришана. Пренасочување &hellip;',
'Topic del redirect'	=>	'Темата е избришана. Пренасочување &hellip;'

);
