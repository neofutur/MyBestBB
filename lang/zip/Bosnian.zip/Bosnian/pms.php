<?php

// Language definitions used by the Private Message System-mod
$lang_pms = array(
	// Common
	'Messages'			=>		'Poruke',
	'Message'			=>		'Poruka',
	'Save message'		=>		'Snimi poruku',
	'Send'				=>		'Po�alji',

	// Messages
	'Inbox'				=>		'Pretinac',
	'Outbox'				=>		'Slanje',
	'Box0'				=>		'Otvori slanje',
	'Box1'				=>		'Otvori pretinac',
	'Action'				=>		'Akcija',
	'Reply'				=>		'Proslijedi',
	'Delete'				=>		'Obri�i',
	'Quote'				=>		'Citiraj',
	'Date'				=>		'Datum',
	'Status'				=>		'Status poruka:',
	'Subject'			=>		'Naslov',
	'Sender'				=>		'Po�aljilac',
	'Receiver'			=>		'Primalac',
	'Private Messages'=> 	'Privatne poruke',
	'New message'		=>		'Po�alji novu poruku',
	'Multidelete'		=>		'Obri�i vi�e poruka',
	'Delete messages comply'	=> 'Da li si siguran da �eli� obrisati naznacene poruke?',
	'Deleted redirect'			=> 'Poruke obrisane. Preusmjeravam ...',
	'Read redirect'				=> 'Sve poruke su obilje�ene kao procitane. Preusmjeravam...',
	'Mark all'			=>		'Obilje�i sve poruke kao procitane',

	// Viewtopic
	'PM'					=>		'PP',

	// Profile
	'Quick message'	=> 	'Po�alji privatnu poruku',
	'Show smilies'		=>		'Prika�i emocije',

	// Send or delete message
	'Send to'			=> 	'Po�alji za',
	'Send a message'	=>		'Po�alji poruku',
	'Delete message'	=>		'Obri�i poruku',
	'Del redirect'		=>		'Poruka obrisana, preusmjeravam...',
	'Sent redirect'	=>		'Poruka poslana korisniku, preusmjeravam...',

	// Errors and messages
	'No messages'		=>		'Nema poruka',
	'New messages'		=>		'Ima� novu poruku',
	'No user'			=>		'Ne postoji korisnik s tim imenom',
	'Full inbox'		=>		'Va� pretinac je pun!',
	'Inbox full'		=>		'Korisnicki pretinac pun, nemoguce poslati poruku korisniku.',
	'Sent full'			=>		'Nemo�e� snimiti poruku, Va� pretinac je pun.',
	'Flood start'		=>		'Posljednje',
	'Flood end'			=>		'sekundi sacekaj da po�aljes. Pricekajte malo pa po�aljite privatnu poruku.'
);
