<?php
// Language file for the editalert mod

$lang_editalert = array(
// Main file lang
"Subj Edit Alert"		=> "Message from forum",
"Message Edit Alert beg"	=>	"Your message",
"Message Edit Alert mid"	=>	"in topic",
"Message Edit Alert end"	=>	"was edited by moderator"
);
?>