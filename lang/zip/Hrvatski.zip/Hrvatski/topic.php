<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Odgovor',
'Topic closed'		=>	'Zatvorena tema',
'From'				=>	'Lokacija',				// User location
'Note'				=>	'Obavijest',				// Admin note
'Website'			=>	'Web',
'Guest'				=>	'Gost',
'Online'			=>	'Nazocan',
'Offline'			=>	'Odsutan',
'Last edit'			=>	'Zadnja izmjena od',
'Report'			=>	'Izvjestaj',
'Delete'			=>	'Obri�i',
'Edit'				=>	'Izmjeni',
'Quote'				=>	'Citiraj',
'Is subscribed'		=>	'Trenutno si prijavljen za ovu temu',
'Unsubscribe'		=>	'Odjavi se',
'Subscribe'			=>	'Prijavi se za temu',
'Quick post'		=>	'Brzi komentar',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Kontrola urednika'

);
