<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Nieuw onderwerp beginnen',
'Views'			=>	'Bekeken',
'Moved'			=>	'Verplaatst',
'Sticky'		=>	'Vastgezet',
'Empty forum'	=>	'Forum bevat geen bijdragen.'

);
