<?php
/***********************************************************************

  Caleb Champlin (med_mediator@hotmail.com)

************************************************************************/

// Language definitions used in viewforum.php
$lang_polls = array(
'Poll'				=>	'Anketa',
'New poll'				=>	'Vytvo�it novou anketu',
'New poll legend multiselect'	=>	'Zadejte informace o anket� (V�cev�b�rov� anketa)',
'New poll legend yesno'		=>	'Zadejte informace o anket� (V�cev�b�rov� ano/ne anketa)',
'New poll legend'			=>	'Zadejte informace o anket�',
'Multiselect'			=>	'V�cev�b�rov� anketa',
'Yesno'				=>	'V�cev�b�rov� ano/ne anketa',
'Regular'				=>	'Norm�ln� anketa',
'Question'				=>	'Ot�zka',
'Option'				=>	'Mo�nost',
'Optional'				=>	'(Voliteln�)',
'Yes'					=>	'Mo�nost ano (pravda/souhlas�m/apod.)',
'Null vote'				=>	'Pr�zdn� hlas',
'Poll preview'			=>	'N�hled ankety',
'No'					=>	'Mo�nost ne (le�/nesouhlas�m/apod.)',
'Create new poll' 		=> 	'Vytvo�it novou anketu',
'Poll select'			=>	'Vyberte typ ankety',
'Already voted'			=>	'V t�to anket� jste u� hlasoval',
'Vote success'			=>	'V� hlas byl zapo��t�n',
'Empty option'			=>	'Anketa m� pr�zdnou mo�nost.',
'No options'			=>	'Ankety mus� obsahovat mo�nosti.',
'Low options'			=>	'Ankety mus� obsahovat 2 nebo v�ce mo�nost�.',
'No question'			=>	'Ankety mus� m�t ot�zku.',
'Too long question'		=>	'Ot�zka nesm� b�t del�� ne� 70 znak�.',
'No yes'				=>	'Tato anketa mus� obsahovat mo�nost Ano.',
'Too long yes'			=>	'Mo�nost Ano nesm� b�t del�� ne� 35 znak�.',
'No no'				=>	'Tato anketa mus� obsahovat mo�nost Ne.',
'Too long no'			=>	'Mo�nost Ne nesm� b�t del�� ne� 35 znak�.',
'No message'			=>	'Mus�te zadat zpr�vu.',
'Too long message'		=>	'P��sp�vky nesm� b�t del�� ne� 65535 znak� (64 KB).'
);
