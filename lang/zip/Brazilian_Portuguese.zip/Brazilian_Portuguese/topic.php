<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Responder',
'Topic closed'		=>	'T�pico fechado',
'From'				=>	'De',				// User location
'Note'				=>	'Nota',				// Admin note
'Website'			=>	'Website',
'Guest'				=>	'Visitante',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'�ltima altera��o por',
'Report'			=>	'Reportar',
'Delete'			=>	'Excluir',
'Edit'				=>	'Alterar',
'Quote'				=>	'Citar',
'Is subscribed'		=>	'Voc� est� inscrito neste t�pico',
'Unsubscribe'		=>	'Cancelar inscri��o',
'Subscribe'			=>	'Increva-se neste t�pico',
'Quick post'		=>	'Post r�pido',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Controles do moderador'

);
