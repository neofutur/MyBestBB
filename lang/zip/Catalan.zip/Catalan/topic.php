<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Respondre',
'Topic closed'		=>	'Tema tancat',
'From'				=>	'Ubicaci�',				// User location
'Note'				=>	'Nota',				// Admin note
'Website'			=>	'Web',
'Guest'				=>	'Visitant',
'Last edit'			=>	'�ltima edici� per',
'Report'			=>	'Denuncia',
'Delete'			=>	'Esborra',
'Edit'				=>	'Edita',
'Quote'				=>	'Cita',
'Is subscribed'		=>	'Actualment esteu subscrit a aquest tema',
'Unsubscribe'		=>	'Cancel�la subscripci�',
'Subscribe'			=>	'Subscriure\'s a aquest tema',
'Quick post'		=>	'Missatge r�pid',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Controls de moderador',

'Online'		=>	'Connectat',
'Offline'		=>	'Desconnectat',

);
