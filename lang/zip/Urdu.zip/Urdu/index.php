﻿<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'موضوعات',
'Moderators'			=>  'ماڈریٹرز',
'Link to'				=>	'ربط برائے',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'بورڈ خالی ہے۔',
'Newest user'			=>	'جدید ترین رجسٹر کرنے والے یوزر',
'Users online'			=>	'رجسٹرڈ یوزر آن لائن',
'Guests online'			=>	'مہمان آن لائن',
'No of users'			=>	'رجسٹرڈ یوزرز کی کُل تعداد',
'No of topics'			=>	'موضوعات کی کُل تعداد',
'No of posts'			=>	'مراسلات کی کُل تعداد',
'Online'				=>	'آن لائن',	// As in "Online: User A, User B etc."
'Board info'			=>	'بورڈ کی معلومات',
'Board stats'			=>	'بورڈ کے اعداد و شمار',
'User info'				=>	'یوزر کی معلومات'

);
