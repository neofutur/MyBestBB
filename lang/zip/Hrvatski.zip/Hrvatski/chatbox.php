<?php

// Language definitions used in chatbox.php
$lang_chatbox = array(

'Chatbox'				=>	'Chat',
'Messages'				=>	'Poruke',
'Anti flood'            =>  'Flood zastita, pricekajte trenutak.',
'Anti blank'            =>  'Flood zastita, ne moze upisati praznu poruku.',
'Btn Send'				=>	'Posalji',
'Btn Refresh'			=>	'Osvjezi',

);
