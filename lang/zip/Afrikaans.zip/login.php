<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'Verkeerde gebruikersnaam en/of wagwoord.',
'Forgotten pass'		=>	'Wagwoord vergeet?',
'Login redirect'		=>	'Login is juis. Besig met nastuuring &hellip;',
'Logout redirect'		=>	'Uit gelog. Besig met nastuuring &hellip;',
'No e-mail match'		=>	'Daar is geen verbruiker met die e-pos nie',
'Request pass'			=>	'Wagwoord asb',
'Request pass legend'		=>	'Voer die e-pos adres in waarme jy geregistreer het',
'Request pass info'		=>	'`n Nuwe wagwoord saam met `n skakel om die wagwoord te aktiveer sal na die adres toe gestuur word.',
'Not registered'		=>	'Nog nie geregistreer?',
'Login legend'			=>	'Voer jou gebruikersnaam en wagwoord hieronder in',
'Login info'			=>	'As jy jou nie geregistreer het nie, of as jy jou wagwoord vergeet het, klik dan op die ooreenstaande skakel hier onder.',

// Forget password mail stuff
'Forget mail'			=>	'`n E-pos is gestuur na die gespesifiseerde adres met instruksies oor hoe om jou wagwoord te verander. As dit nie by jou uit kom nie, kontak die forum beheerder by'

);
