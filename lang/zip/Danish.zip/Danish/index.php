<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'Emner',
'Moderators'			=>  'Moderatorer',
'Link to'				=>	'Link til',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Forummet er tomt.',
'Newest user'			=>	'Nyest registrerede bruger',
'Users online'			=>	'Registrerede brugere online',
'Guests online'			=>	'G�ster online',
'No of users'			=>	'Totale antal registrerede brugere',
'No of topics'			=>	'Totale antal emner',
'No of posts'			=>	'Totale antal indl�g',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Foruminformation',
'Board stats'			=>	'Forumstatistik',
'User info'				=>	'Brugerinformation'

);
