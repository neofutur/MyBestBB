<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'ユーザの検索およびソート',
'User search info'		=>	'ユーザ名および/またはユーザグループを入力してください。ユーザ名フィールドは空白のままにすることができます。Use the wildcard character * for partial matches. Sort users by name, date registered or number of posts and in ascending/descending order.',
'User group'			=>	'ユーザグループ',
'No of posts'			=>	'投稿No.',
'All users'				=>	'すべて'

);
