<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Encuentra y ordena usuarios',
'User search info'		=>	'Introduce un nombre de usuario para buscarI, y/o un grupo de usuarios para filtrar la b�squeda. El campo nombre de usuario puedes dejarlo en blanco. Usa el caracter asterisco * para coincidencias parciales. Ordena los usuarios por nombre, fecha de registro o n�mero de mensajes y en orden ascendente/descendente.',
'User group'			=>	'Grupo de usuarios',
'No of posts'			=>	'N�. de mensajes',
'All users'				=>	'Todos'

);
