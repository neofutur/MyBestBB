<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Izbri�i objavo',
'Warning'				=>	'Opozorilo! �e je to prva objava v tej temi bo zbrisana celotna tema.',
'Delete'				=>	'Izbri�i',	// The submit button
'Post del redirect'		=>	'Objava zbrisana. Preusmerjanje &hellip;',
'Topic del redirect'	=>	'Tema zbrisana. Preusmerjanje &hellip;'

);
