<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Apri una nuova discussione',
'Views'			=>	'Visite',
'Moved'			=>	'Spostato',
'Sticky'		=>	'In rilievo',
'Empty forum'	=>	'Forum vuoto.'

);
