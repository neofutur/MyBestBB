<?php

// Language definitions used in delete.php
$lang_delete = array(
 
'Delete post'			=>	'Supprimer le message',
'Warning'				=>	'Attention&#160;: S\'il s\'agit du premier message de la discussion, celle-ci sera enti�rement supprim�e&#160;!',
'Delete'				=>	'Supprimer',	// The submit button
'Post del redirect'		=>	'Message supprim�. Redirection ...',
'Topic del redirect'	=>	'Discussion supprim�e. Redirection ...'
 
);