<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'P�sta n�jum �r��i',
'Views'			=>	'S�nir',
'Moved'			=>	'F�rt',
'Sticky'		=>	'Kl�stra�',
'Empty forum'	=>	'Spjallbor� er t�mt'

);
