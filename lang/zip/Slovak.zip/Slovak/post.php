<?php

// Language definitions used in post.php and edit.php
$lang_post = array(

// Post validation stuff (many are similiar to those in edit.php)
'No subject'			=>	'T�my musia obsahova� predmet.',
'Too long subject'		=>	'Predmet nesmie by� dlh�� ako 70 znakov.',
'No message'			=>	'Mus�te nap�sa� spr�vu.',
'Too long message'		=>	'Pr�spevky nesm� by� dlh�ie ako 65535 znakov (64 KB).',

// Posting
'Post errors'			=>	'Chyby v pr�spevku',
'Post errors info'		=>	'Nasleduj�ce chyby treba opravi� pred odoslan�m spr�vy:',
'Post preview'			=>	'N�h�ad pr�spevku',
'Guest name'			=>	'Meno',	// For guests (instead of Username)
'Post redirect'			=>	'Pr�spevok vlo�en�. Presmeruv�vam &hellip;',
'Post a reply'			=>	'Odpoveda�',
'Post new topic'		=>	'Nov� t�ma',
'Hide smilies'			=>	'Nikdy nezobrazova� smajl�kov ako obr�zky v tomto pr�spevku',
'Subscribe'				=>	'Odobera� pr�spevky tejto t�my',
'Topic review'			=>	'Zhodnoten� t�ma (najnov�ia prv�)',
'Flood start'			=>	'Najmenej',
'flood end'				=>	'sek�nd mus� prejs� medzi pr�spevkami. Po�kajte kr�tku dobu a sk�ste odosla� znova.',
'Preview'				=>	'N�h�ad',	// submit button to preview message

// Edit post
'Edit post legend'		=>	'Editova� pr�spevok a ulo�i� zmeny',
'Silent edit'			=>	'Tich� edit�cia (nezobraz� "Upraven� ..." v zobrazen� t�my)',
'Edit post'				=>	'Upravi� pr�spevok',
'Edit redirect'			=>	'Pr�spevok aktualizovan�. Presmerov�vam &hellip;'

);
