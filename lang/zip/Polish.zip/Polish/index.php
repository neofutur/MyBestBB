<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'                                =>  'W�tki',
'Moderators'                        =>  'Moderatorzy',
'Link to'                                =>        'Link do',        // As in "Link to http://www.punbb.org/"
'Empty board'                        =>        'Forum jest puste.',
'Newest user'                        =>        'Ostatnio zarejestrowany',
'Users online'                        =>        'U�ytkownicy online',
'Guests online'                        =>        'Go�cie online',
'No of users'                        =>        'Wszyscy u�ytkownicy',
'No of topics'                        =>        'Wszystkie w�tki',
'No of posts'                        =>        'Wszystkie posty',
'Online'                                =>        'Online',        // As in "Online: User A, User B etc."
'Board info'                        =>        'Informacje o forum',
'Board stats'                        =>        'Statystyki forum',
'User info'                                =>        'Informacje o u�ytkowniku'

);
