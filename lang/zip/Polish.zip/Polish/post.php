<?php

// Language definitions used in post.php and edit.php
$lang_post = array(

// Post validation stuff (many are similiar to those in edit.php)
'No subject'                        =>        'W�tki musz� mie� tematy.',
'Too long subject'                =>        'Tematy nie mog� by� d�u�sze ni� 70 znak�w.',
'No message'                        =>        'Musisz wpisa� wiadomo��.',
'Too long message'                =>        'Post nie mo�e mie� wi�cej ni� 65535 znak�w (64 KB).',

// Posting
'Post errors'                        =>        'B��d wysy�ania',
'Post errors info'                =>        'Nast�puj�ce b��dy musz� zosta� poprawione przed wys�aniem posta:',
'Post preview'                        =>        'Podgl�d postu',
'Guest name'                        =>        'Nazwa',        // For guests (instead of Username)
'Post redirect'                        =>        'Post dodany. Przekierowywanie &hellip;',
'Post a reply'                        =>        'Napisz odpowied�',
'Post new topic'                =>        'Za�� w�tek',
'Hide smilies'                        =>        'Nie pokazuj emot�w jako ikon w�tk�w',
'Subscribe'                                =>        'Subskrybuj ten w�tek',
'Topic review'                        =>        'Podgl�d w�tku (najnowsze pierwsze)',
'Flood start'                        =>        'Musi min��',
'flood end'                                =>        'sekund pomi�dzy dodawaniem post�w. Poczekaj troch� d�u�ej, a nast�pnie napisz posta.',
'Preview'                                =>        'Podgl�d',        // submit button to preview message

// Edit post
'Edit post legend'                =>        'Edytuje post i zapisuje zmiany',
'Silent edit'                        =>        'Ukryta edycja (nie pokazuj "Edytowane przez ...")',
'Edit post'                                =>        'Edytuj posta',
'Edit redirect'                        =>        'Post zaktualizowany. Przekierowywanie &hellip;'

);
