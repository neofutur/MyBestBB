<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Odpoveda�',
'Topic closed'		=>	'T�ma zatvoren�',
'From'				=>	'Lok�cia',				// User location
'Note'				=>	'Pozn�mka',				// Admin note
'Website'			=>	'Webstr�nka',
'Guest'				=>	'N�v�tevn�k',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Naposledy upravil',
'Report'			=>	'Ozn�menie',
'Delete'			=>	'Vymaza�',
'Edit'				=>	'Editova�',
'Quote'				=>	'Citova�',
'Is subscribed'		=>	'Pr�ve ste prihl�sen� k odberu pr�spevkov pre t�to t�mu',
'Unsubscribe'		=>	'Zru�i� odber',
'Subscribe'			=>	'Odobera� pr�spevky v tejto t�me',
'Quick post'		=>	'R�chla odpove�',

'Link separator'	=>	' | ',	// The text that separates links in posts (website, e-mail, report, edit etc.)
'Mod controls'		=>	'Ovl�danie moder�tora'

);
