<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'Cari dan sortir pengguna',
'User search info'		=>	'Masukkan sebuah nama pengguna yang akan dicari dan/atau grup pengguna sebagai filter-nya. Kolom nama pengguna dapat dibiarkan kosong. Gunakan karakter wildcard * untuk mencari kecocokkan. Sortir pengguna dengan nama, tanggal pendaftaran atau jumlah posting dan dalam pengaturan waktu.',
'User group'			=>	'Grup pengguna',
'No of posts'			=>	'Jumlah posting',
'All users'				=>	'Semua'

);
