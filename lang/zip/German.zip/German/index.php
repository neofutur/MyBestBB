<?php

// SPRACHDEFINITIONEN DIE IN "index.php" GEBRAUCHT WERDEN
$lang_index = array(

'Topics'				=>  'Themen',
'Moderators'			=>  'Moderatoren',
'Link to'				=>	'Link zu',	// As in "Link to http://www.punbb.org/"
'Empty board'		    =>	'Das Brett ist leer.',
'Newest user'			=>	'Das neueste Mitglied ist',
'Users online'			=>	'Registrierte Mitglieder online',
'Guests online'			=>	'G&auml;ste online',
'No of users'			=>	'Anzahl registrierter Mitglieder',
'No of topics'			=>	'Anzahl der Themen',
'No of posts'			=>	'Anzahl der Beitr&auml;ge',
'Online'				=>	'Online',	// As in "Online: User A, User B etc."
'Board info'			=>	'Brett-Informationen',
'Board stats'			=>	'Brett-Statistik',
'User info'				=>	'Mitgliederinformationen'

);
