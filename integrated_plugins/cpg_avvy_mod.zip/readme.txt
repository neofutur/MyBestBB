##
##        Mod title:  CPG avatar gallery
##
##   Works on PunBB:  1.2 + CPG 1.3 - 1.4 both running on MySQL
##     Release date:  2005-01-12
##           Author:  Nibbler (nibbler999@users.sourceforge.net)
##
##      Description:  Alllows an avatar to be selected by browsing an existing Coppermine gallery, bridged or not.
##
##   Affected files:  profile.php
##
##       Affects DB:  No
##
##       DISCLAIMER:  Please note that "mods" are not officially supported by
##                    PunBB or by the Coppermine Dev Team. Installation of this modification is done at your
##                    own risk. Backup your forum database and any and all
##                    applicable files before proceeding.
##

Instructions: (or use included pre-modified profile.php, but still see step 2):

1) Find:

else if ($action == 'delete_avatar')
{

replace with all this:


else if ($action == 'cpg_picker')
{
	// changeme
	define('CPG_PATH', '../devel/');
	//define('UDB_INTEGRATION', 1);
	
	// ----- nothing to change below this line -----
	define('FIRST_USER_CAT', 10000);
	define('GALLERY_ADMIN_MODE', $pun_user['g_id'] == PUN_ADMIN);
	define('USER_ID', $pun_user['id']);
	define('USER_GROUP_SET', '(3)'); // oh, except this if you are feeling clever ;) 

	if ($pun_config['o_avatars'] == '0')
		message($lang_profile['Avatars disabled']);

	if ($pun_user['id'] != $id && $pun_user['g_id'] > PUN_MOD)
		message($lang_common['No permission']);

	$CONFIG = array();
	require CPG_PATH . 'include/config.inc.php';
	$CONFIG['TABLE_PICTURES']        = $CONFIG['TABLE_PREFIX']."pictures";
	$CONFIG['TABLE_ALBUMS']                = $CONFIG['TABLE_PREFIX']."albums";
	$CONFIG['TABLE_CATEGORIES']        = $CONFIG['TABLE_PREFIX']."categories";
	$CONFIG['TABLE_USERS']                = $CONFIG['TABLE_PREFIX']."users";
	$CONFIG['TABLE_CONFIG']                = $CONFIG['TABLE_PREFIX']."config";
	$CONFIG['TABLE_FILETYPES']          = $CONFIG['TABLE_PREFIX']."filetypes";
	
	function array_csort() {
	   $args = func_get_args();
	   $marray = array_shift($args);
		$i = 0;   
	
	   $msortline = "return(array_multisort(";
	   foreach ($args as $arg) {
		   $i++;
		   if (is_string($arg)) {
			   foreach ($marray as $row) {
				   $sortarr[$i][] = $row[$arg];
			   }
		   } else {
			   $sortarr[$i] = $arg;
		   }
		   $msortline .= "\$sortarr[".$i."],";
	   }
	   $msortline .= "\$marray));";
	
	   eval($msortline);
	   return $marray;
	}
	
	function cpg_db_connect()
	{
			global $CONFIG;
			$result = mysql_connect($CONFIG['dbserver'], $CONFIG['dbuser'], $CONFIG['dbpass']);
			if (!$result)
					return false;
			if (!mysql_select_db($CONFIG['dbname']))
					return false;
			return $result;
	}
	
	function cpg_db_query($query, $link_id = 0)
	{
			global $CONFIG;
	
			if (($link_id)) {
				$result = mysql_query($query, $link_id);
			} else {
				$result = mysql_query($query, $CONFIG['LINK_ID']);
			}
			if (!$result) die("Error while executing query \"$query\" on $link_id");
	
			return $result;
	}
	
	$CONFIG['LINK_ID'] = cpg_db_connect();
	
	$results = cpg_db_query("SELECT * FROM {$CONFIG['TABLE_CONFIG']}");
	
	while ($row = mysql_fetch_array($results)) {
		$CONFIG[$row['name']] = $row['value'];
	} 
	
	$CONFIG['site_url'] =& $CONFIG['ecards_more_pic_target'];
	
	mysql_free_result($results);

	$result = cpg_db_query("SELECT extension FROM {$CONFIG['TABLE_FILETYPES']} WHERE content = 'image'");
	$FILE_TYPES = array();
	
	while ($row = mysql_fetch_array($result)) {
		$FILE_TYPES[] = $row['extension'];
	}
	
	mysql_free_result($result);
	
	function get_private_album_set($aid_str="")
	{
		if (GALLERY_ADMIN_MODE) return;

        global $CONFIG, $ALBUM_SET, $USER_DATA, $FORBIDDEN_SET, $FORBIDDEN_SET_DATA;

        if ($USER_DATA['can_see_all_albums']) return;

        $sql = "SELECT aid FROM {$CONFIG['TABLE_ALBUMS']} WHERE visibility != '0' AND visibility !='".(FIRST_USER_CAT + USER_ID)."' AND visibility NOT IN ".USER_GROUP_SET;
        if (!empty($aid_str)) {
          $sql .= " AND aid NOT IN ($aid_str)";
		}

         $result = cpg_db_query($sql);
        if ((mysql_num_rows($result))) {
                $set ='';
            while($album=mysql_fetch_array($result)){
                    $set .= $album['aid'].',';
                    $FORBIDDEN_SET_DATA[] = $album['aid'];
            } // while
                $FORBIDDEN_SET = "p.aid NOT IN (".substr($set, 0, -1).') ';
                $ALBUM_SET = 'AND aid NOT IN ('.substr($set, 0, -1).') ';
        }else{
                  $FORBIDDEN_SET_DATA = array();
                  $FORBIDDEN_SET = "";
                  $ALBUM_SET = "";
        }
        mysql_free_result($result);
	}	
	
	$ALBUM_SET = '';
	get_private_album_set();

	if (isset($_POST['file']))
	{
		if (file_exists($filename = CPG_PATH . $_POST['file']))
		{
			if (!in_array(strtolower(array_pop(explode('.', $filename))), $FILE_TYPES))
				message($lang_profile['Bad type']);

			// Make sure the file isn't too big
			if (filesize($filename) > $pun_config['o_avatars_size'])
				message($lang_profile['Too large'].' '.$pun_config['o_avatars_size'].' '.$lang_profile['bytes'].'.');
			
			$split = explode('.', $filename);
			$extensions = array_unique(array('.' . strtolower(array_pop($split)), '.png', '.gif', '.jpg'));

			// <<copy>> the file to the avatar directory. We do this before checking the width/height to circumvent open_basedir restrictions.
			if (!@copy($filename, $pun_config['o_avatars_dir'].'/'.$id.'.tmp'))
				message($lang_profile['Move failed'].' <a href="mailto:'.$pun_config['o_admin_email'].'">'.$pun_config['o_admin_email'].'</a>.');

			// Now check the width/height
			list($width, $height, ,) = getimagesize($pun_config['o_avatars_dir'].'/'.$id.'.tmp');
			if ($width > $pun_config['o_avatars_width'] || $height > $pun_config['o_avatars_height'])
			{
				@unlink($pun_config['o_avatars_dir'].'/'.$id.'.tmp');
				message($lang_profile['Too wide or high'].' '.$pun_config['o_avatars_width'].'x'.$pun_config['o_avatars_height'].' '.$lang_profile['pixels'].'.');
			}

			// Delete any old avatars and put the new one in place
			@unlink($pun_config['o_avatars_dir'].'/'.$id.$extensions[0]);
			@unlink($pun_config['o_avatars_dir'].'/'.$id.$extensions[1]);
			@unlink($pun_config['o_avatars_dir'].'/'.$id.$extensions[2]);
			@rename($pun_config['o_avatars_dir'].'/'.$id.'.tmp', $pun_config['o_avatars_dir'].'/'.$id.$extensions[0]);
			@chmod($pun_config['o_avatars_dir'].'/'.$id.$extensions[0], 0644);
		}
		else
			message($lang_profile['Unknown failure']);

		// Enable use_avatar (seems sane since the user just uploaded an avatar)
		$db->query('UPDATE '.$db->prefix.'users SET use_avatar=1 WHERE id='.$id) or error('Unable to update avatar state', __FILE__, __LINE__, $db->error());

		redirect('profile.php?section=personality&amp;id='.$id, $lang_profile['Avatar upload redirect']);
	}

	$page_title = pun_htmlspecialchars($pun_config['o_board_title']).' / '.$lang_common['Profile'];
	require PUN_ROOT.'header.php';

?>
<div class="blockform">
	<h2><span>Pick avatar from photo gallery</span></h2>
	<div class="box">
		<form id="upload_avatar" method="post" enctype="multipart/form-data" action="profile.php?action=cpg_picker&amp;id=<?php echo $id ?>" onsubmit="return process_form(this)">
			<div class="inform">
				<fieldset>
					<legend>Select album then file</legend>
					<div class="infldset">
<?

function get_album_data()
{
    global $CONFIG, $ALBUM_LIST, $ALBUM_SET;

   $result = cpg_db_query("SELECT aid, title FROM {$CONFIG['TABLE_ALBUMS']} WHERE 1 $ALBUM_SET ORDER BY title");
   if (mysql_num_rows($result) > 0){
      $rowset = cpg_db_fetch_rowset($result);
      foreach ($rowset as $alb){
         $ALBUM_LIST[]=array($alb['aid'], $alb['title']);
      }
   }
}

function albumselect($id = "album") {
// originally by frogfoot

    global $CONFIG, $lang_picmgr_php, $aid, $ALBUM_SET;
    static $select = "";

    // Reset counter
    $list_count = 0;

    if ($select == "") {
        // albums in root category
        //if (GALLERY_ADMIN_MODE) {
            $result = cpg_db_query("SELECT aid, title FROM {$CONFIG['TABLE_ALBUMS']} WHERE category = 0");
            while ($row = mysql_fetch_array($result)) {
                // Add to multi-dim array for later sorting
                $listArray[$list_count]['cat'] = 'Albums in no category';
                $listArray[$list_count]['aid'] = $row['aid'];
                $listArray[$list_count]['title'] = $row['title'];
                $list_count++;
            }
            mysql_free_result($result);
        //}

        // albums in public categories
      //  if (GALLERY_ADMIN_MODE) {
            $result = cpg_db_query("SELECT DISTINCT a.aid AS aid, a.title AS title, c.name AS cname FROM {$CONFIG['TABLE_ALBUMS']} AS a, {$CONFIG['TABLE_CATEGORIES']} AS c WHERE a.category = c.cid $ALBUM_SET AND a.category < '" . FIRST_USER_CAT . "'");
            while ($row = mysql_fetch_array($result)) {
                // Add to multi-dim array for later sorting
                $listArray[$list_count]['cat'] = $row['cname'];
                $listArray[$list_count]['aid'] = $row['aid'];
                $listArray[$list_count]['title'] = $row['title'];
                $list_count++;
            }
	        mysql_free_result($result);
     //   }

        // albums in user's personal galleries
        if (defined('UDB_INTEGRATION')) {
//              		$sql = "SELECT aid, IF(category > " . FIRST_USER_CAT . ", CONCAT('* ', title), CONCAT(' ', title)) AS title " . "FROM {$CONFIG['TABLE_ALBUMS']} " . "WHERE 1 $ALBUM_SET ORDER BY title";

            if (GALLERY_ADMIN_MODE) {
                $sql = "SELECT aid, CONCAT('(', user_name, ') ', title) AS title " . "FROM {$CONFIG['TABLE_ALBUMS']} AS a " . "INNER JOIN {$CONFIG['TABLE_USERS']} AS u ON category = (" . FIRST_USER_CAT . " + user_id)";
            } else {
                $sql = "SELECT aid, title AS title FROM {$CONFIG['TABLE_ALBUMS']}  WHERE category = " . (FIRST_USER_CAT + USER_ID);
            }

        $result = cpg_db_query($sql);
		
        while ($row = mysql_fetch_array($result)) {
            // Add to multi-dim array for later sorting
            $listArray[$list_count]['cat'] = 'Personal albums';
            $listArray[$list_count]['aid'] = $row['aid'];
            $listArray[$list_count]['title'] = $row['title'];
            $list_count++;
        }

        mysql_free_result($result);
		}
        // Sort the pulldown options by category and album name
        $listArray = array_csort($listArray,'cat','title');

        // Create the nicely sorted and formatted drop down list
        $alb_cat = '';
        
        foreach ($listArray as $val) {
            if ($val['cat'] != $alb_cat) {
          if ($alb_cat) $select .= "</optgroup>\n";
                $select .= '<optgroup label="' . $val['cat'] . '">' . "\n";
                $alb_cat = $val['cat'];
            }
            $select .= '<option value="' . $val['aid'] . '"' . ($val['aid'] == $_GET['aid'] ? ' selected="selected"' : '') . '>   ' . $val['title'] . "</option>\n";
        }
        if ($alb_cat) $select .= "</optgroup>\n";
    }

    echo "\n<select name=\"cat\" id=\"cat\" size=\"10\" onChange=\"if(this.options[this.selectedIndex].value) window.location.href='{$_SERVER['PHP_SELF']}?section=personality&id=".USER_ID."&action=cpg_picker&aid='+this.options[this.selectedIndex].value;\" style=\"width: 300px\">\n$select</select>\n";
}

function cpg_db_fetch_rowset($result)
{
        $rowset = array();
        while ($row = mysql_fetch_array($result)) $rowset[] = $row;
        return $rowset;
}

function filelist()
{
	global $CONFIG, $FILE_TYPES;
	
	$aid = isset($_GET['aid']) ? ($_GET['aid']) : 0;

	$result = cpg_db_query("SELECT filepath, filename, IF(title <> '', title, filename) AS title FROM {$CONFIG['TABLE_PICTURES']} WHERE aid = $aid ORDER BY title ASC, pid");
	
   $rowset = cpg_db_fetch_rowset($result);
   
	$ALBUM_LIST = array();

	get_album_data(FIRST_USER_CAT + USER_ID,'');
	
	$lb = '<select id="file" name="file" size="10" onchange="showAvatar()" style="width: 300px">';
   
	if (count ($rowset) > 0) foreach ($rowset as $picture){
		if (in_array(strtolower(array_pop(explode('.', $picture['filename']))), $FILE_TYPES)){
			$name = $CONFIG['fullpath'] . $picture['filepath'] . $CONFIG['thumb_pfx'] . $picture['filename'];
			$lb .= '               <option value="'.$name.'">' . stripslashes($picture['title']) . "</option>\n";
		}
   }
   
	$lb .= '</select>';   
	echo $lb;
}
echo '<table><tr><td width="40%" align="center">';
albumselect();
echo '</td><td width="40%" align="center">';
filelist();
?>
</td><td width="20%" align="center"><img name="avatar" id="avatar" src="" alt="None selected" /></td></tr></table>
<script language="JavaScript1.2" type="text/javascript"><!--
	var avatar = document.getElementById("avatar");
	var baseurl = "<? echo $CONFIG['site_url'] ?>";
	var file = document.getElementById("file");
				
	function showAvatar()
	{
		if (file.selectedIndex == -1)
			return;

		avatar.src = baseurl + file.options[file.selectedIndex].value;
		avatar.alt = file.options[file.selectedIndex].text;
	}
	
	showAvatar();
	// --></script>
	
					</div>
				</fieldset>
			</div>
			<p><input type="submit" name="upload" value="Select" /><a href="<? echo $_SERVER['PHP_SELF'] . '?section=personality&id='. USER_ID ?>"><?php echo $lang_common['Go back'] ?></a></p>
		</form>
	</div>
</div>
<?php

	require PUN_ROOT.'footer.php';
}

else if ($action == 'delete_avatar')
{












2) In the code you just added, find:

	// changeme
	define('CPG_PATH', '../coppermine/');

and fill in the local or full path to your coppermine directory - not an url !

3) finally, find:


		// Display the delete avatar link?
		if ($img_size)
			$avatar_field .= '&nbsp;&nbsp;&nbsp;<a href="profile.php?action=delete_avatar&amp;id='.$id.'">'.$lang_profile['Delete avatar'].'</a>';


and add underneath, or to taste:

$avatar_field .= '&nbsp;&nbsp;&nbsp;<a href="profile.php?action=cpg_picker&amp;id='.$id.'">Pick avatar from gallery</a>';