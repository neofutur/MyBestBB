<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Знищити повідомлення',
'Warning'				=>	'Попередження! Якщо це перше повідомлення в темі, то й тема також буде знищена.',
'Delete'				=>	'Знищити',	// The submit button
'Post del redirect'		=>	'Повідомлення знищене. Переадресація&hellip;',
'Topic del redirect'	=>	'Тема знищена. Переадресація&hellip;'

);
