<?php

// Language definitions used in index.php
$lang_index = array(
 
'Topics'				=>  'Discussions',
'Moderators'			=>  'Mod�rateurs',
'Link to'				=>	'Lien vers',	// As in "Link to http://www.punbb.org/"
'Empty board'			=>	'Les forums sont vides.',
'Newest user'			=>	'Dernier utilisateur inscrit',
'Users online'			=>	'Membres en ligne',
'Guests online'			=>	'Invit�s en ligne',
'No of users'			=>	'Nombre total de membres',
'No of topics'			=>	'Nombre total de discussions',
'No of posts'			=>	'Nombre total de messages',
'Online'				=>	'Actuellement en ligne',	// As in "Online: User A, User B etc."
'Board info'			=>	'Informations Forums',
'Board stats'			=>	'Statistiques Forums',
'User info'				=>	'Informations utilisateurs'
 
);