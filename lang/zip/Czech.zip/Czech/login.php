<?php

// Language definitions used in delete.php
$lang_login = array(

// Miscellaneous
'Wrong user/pass'		=>	'�patn� u�ivatelsk� jm�no nebo heslo',
'Forgotten pass'		=>	'Zapomn�l(a) jste heslo?',
'Login redirect'		=>	'P�ihl�en� prob�hlo �sp�n�. P�esm�rov�v�m&hellip;',
'Logout redirect'		=>	'Byl(a) jste odhl�en(a). P�esm�rov�v�m&hellip;',
'No e-mail match'		=>	'U�ivatel s t�mto e-mailem zde nen� zaregistrov�n',
'Request pass'		=>	'��dost o heslo',
'Request pass legend'	=>	'Zadejte e-mailovou adresu, pod kterou jste se zde registrovali.',
'Request pass info'	=>	'Nov� heslo a odkaz na aktivaci hesla V�m budou zasl�ny na zadanou emailovou adresu.',
'Not registered'		=>	'Nejste je�t� registrov�n(a)?',
'Login legend'		=>	'Zadejte u�ivatelsk� jm�no a heslo',
'Login info'		=>	'Pokud nejste zaregistrov�n(a) nebo jste zapomn�l(a) heslo, klikn�te n�e.',

// Forget password mail stuff
'Forget mail'		=>	'Na zadan� e-mail byly zasl�ny instrukce, jak zm�nit heslo. Pokud V�m nic nep�i�lo, kontaktujte pros�m administr�tora'

);
